/**
 * Gestionar Empresa v1.1 — Modales generados dinámicamente por JS
 */
(function ($) {
    'use strict';

    var searchTimer  = null;
    var editMode     = false;
    var openDropdown = null;

    // Estado de paginación (client-side, sobre el listado ya cargado)
    var geAllUsers      = [];
    var gePage          = 1;
    var gePerPage       = 25;
    var geProgramFilter = '';

    // Estado del tab "Usuarios" (subscriber)
    var geAllSubscribers   = [];
    var geSubPage          = 1;
    var geSubPerPage       = 25;
    var geSubProgramFilter = '';
    var geSubEmpresaFilter = '';
    var geSubAreaFilter    = '';
    var geSubTestFilter    = '';
    var geSelectedSubscribers = {};
    var geSubSearchTimer   = null;
    var geSubscribersLoaded = false;
    var geEmpresaOptionsLoaded = false;

    // Restauración del listado al volver desde "Entrar como usuario"
    var geRestorePage       = null; // { tab, page } — se aplica al terminar de cargar el listado
    var geRestoreSubFilters = null; // { emp, area } — se aplica al cargar las opciones de empresa

    // Estado del wizard de importación masiva de usuarios
    var geImport = { step: 1, empresaId: '', areaId: '', area: null, file: null, headers: [], rows: [], mapping: {}, mappedRows: [], validated: null, results: { creados: [], fallidos: [] } };
    var GE_IMPORT_BATCH_SIZE = 5;
    var GE_IMPORT_SYSTEM_FIELDS = [
        { key: 'correo',        label: 'Correo',   required: true  },
        { key: 'first_name',    label: 'Nombre',   required: false },
        { key: 'last_name',     label: 'Apellido', required: false },
        { key: 'user_age',      label: 'Edad',     required: false },
        { key: 'user_gender',   label: 'Género',   required: false },
        { key: 'country',       label: 'País',     required: false },
        { key: 'phone_number',  label: 'Teléfono', required: false },
        { key: 'user_position', label: 'Cargo',    required: false }
    ];

    /* ══════════════════════════════════
       ICONOS
       Mismo set y mismo trazo que ge_icon() en PHP. Tenerlos en un mapa evita
       repetir el <svg> completo en cada fila y que se cuelen emojis sueltos
       donde el resto del panel usa SVG.
       ══════════════════════════════════ */
    var GE_ICON_PATHS = {
        user:     '<path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/>',
        edit:     '<path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/>',
        grid:     '<path d="M3 3h18v18H3z"/><path d="M3 9h18M3 15h18M9 3v18"/>',
        lock:     '<rect x="3" y="11" width="18" height="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/>',
        mail:     '<path d="M4 4h16v16H4z"/><path d="m22 6-10 7L2 6"/>',
        refresh:  '<path d="M23 4v6h-6"/><path d="M1 20v-6h6"/><path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15"/>',
        database: '<ellipse cx="12" cy="5" rx="9" ry="3"/><path d="M3 5v14c0 1.66 4 3 9 3s9-1.34 9-3V5"/><path d="M3 12c0 1.66 4 3 9 3s9-1.34 9-3"/>',
        trash:    '<polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/><path d="M10 11v6"/><path d="M14 11v6"/><path d="M9 6V4a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2"/>',
        dots:     '<circle cx="12" cy="5" r="1"/><circle cx="12" cy="12" r="1"/><circle cx="12" cy="19" r="1"/>',
        check:    '<polyline points="20 6 9 17 4 12"/>',
        circle:   '<circle cx="12" cy="12" r="9"/>',
        chevron:  '<polyline points="9 18 15 12 9 6"/>',
        caret:    '<polyline points="6 9 12 15 18 9"/>',
        folder:   '<path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"/>',
        search:   '<circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/>',
        building: '<path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/>',
        users:    '<path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/>',
        inbox:    '<polyline points="22 12 16 12 14 15 10 15 8 12 2 12"/><path d="M5.45 5.11 2 12v6a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-6l-3.45-6.89A2 2 0 0 0 16.76 4H7.24a2 2 0 0 0-1.79 1.11z"/>',
        alert:    '<circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/>'
    };

    function icon(nombre, tamano) {
        var d = GE_ICON_PATHS[nombre];
        if (!d) return '';
        tamano = tamano || 14;
        return '<svg xmlns="http://www.w3.org/2000/svg" width="' + tamano + '" height="' + tamano + '"'
            + ' viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"'
            + ' stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">' + d + '</svg>';
    }

    /* ══════════════════════════════════
       HTML DE LOS MODALES (generado JS)
       ══════════════════════════════════ */
    var MODAL_EMPRESA_HTML = [
        '<div id="ge-modal-overlay" class="ge-modal-overlay" style="display:none;">',
        '<div class="ge-modal">',
          '<div class="ge-modal-header">',
            '<div class="ge-modal-header-icon">',
              '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">',
                '<path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/>',
                '<polyline points="9 22 9 12 15 12 15 22"/>',
              '</svg>',
            '</div>',
            '<div>',
              '<h2 id="ge-modal-title" class="ge-modal-title">Crear Empresa</h2>',
              '<p class="ge-modal-desc">Completa todos los campos para registrar la empresa</p>',
            '</div>',
            '<button id="ge-modal-close" class="ge-modal-close" type="button">&times;</button>',
          '</div>',
          '<form id="ge-form" novalidate>',
            '<input type="hidden" id="ge-edit-user-id" name="user_id" value="">',
            '<div class="ge-form-grid">',
              '<div class="ge-field ge-field-full">',
                '<label>Nombre del grupo <span class="ge-required">*</span></label>',
                '<input type="text" id="nombre_empresa" name="nombre_empresa" placeholder="Ej: Empresa ABC" required>',
              '</div>',
              '<div class="ge-field">',
                '<label>Nombres <span class="ge-required">*</span></label>',
                '<input type="text" id="nombre_encargado" name="nombre_encargado" placeholder="Nombres del encargado" required>',
              '</div>',
              '<div class="ge-field">',
                '<label>Apellidos <span class="ge-required">*</span></label>',
                '<input type="text" id="last_name" name="last_name" placeholder="Apellidos del encargado" required>',
              '</div>',
              '<div class="ge-field">',
                '<label>Número de contacto <span class="ge-required">*</span></label>',
                '<input type="tel" id="phone_number" name="phone_number" placeholder="+57 300 000 0000" required>',
              '</div>',
              '<div class="ge-field">',
                '<label>Ocupación / Cargo <span class="ge-required">*</span></label>',
                '<input type="text" id="ocupacion" name="ocupacion" placeholder="Ej: Gerente, Director…" required>',
              '</div>',
              '<div class="ge-field ge-field-full" id="ge-email-wrap">',
                '<label>Correo electrónico <span class="ge-required">*</span></label>',
                '<input type="email" id="email" name="email" placeholder="correo@empresa.com" required>',
              '</div>',
            '</div>',
            '<div id="ge-form-notice" class="ge-notice" style="display:none;margin-bottom:16px;"></div>',
            '<div class="ge-modal-footer">',
              '<button type="button" id="ge-btn-cancel" class="ge-btn-secondary">Cancelar</button>',
              '<button type="submit" id="ge-btn-submit" class="ge-btn-primary">',
                '<span class="ge-btn-text">Guardar Empresa</span>',
                '<span class="ge-btn-spinner" style="display:none;"><span class="ge-spinner-sm"></span> Guardando…</span>',
              '</button>',
            '</div>',
          '</form>',
        '</div>',
        '</div>'
    ].join('');

    var MODAL_PASS_HTML = [
        '<div id="ge-modal-pass-overlay" class="ge-modal-overlay ge-z-1" style="display:none;">',
        '<div class="ge-modal ge-modal-sm">',
          '<div class="ge-modal-header">',
            '<div class="ge-modal-header-icon">',
              '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">',
                '<rect x="3" y="11" width="18" height="11" rx="2" ry="2"/>',
                '<path d="M7 11V7a5 5 0 0 1 10 0v4"/>',
              '</svg>',
            '</div>',
            '<div>',
              '<h2 class="ge-modal-title">Editar Contraseña</h2>',
              '<p class="ge-modal-desc">Escribe la nueva contraseña para este usuario</p>',
            '</div>',
            '<button id="ge-pass-close" class="ge-modal-close" type="button">&times;</button>',
          '</div>',
          '<form id="ge-pass-form" novalidate>',
            '<input type="hidden" id="ge-pass-user-id" name="user_id" value="">',
            '<div class="ge-form-grid">',
              '<div class="ge-field ge-field-full">',
                '<label>Nueva contraseña <span class="ge-required">*</span></label>',
                '<div class="ge-pass-wrap">',
                  '<input type="text" id="ge-new-pass" name="new_password" placeholder="Mínimo 8 caracteres" required>',
                  '<button type="button" id="ge-gen-pass" class="ge-btn-ghost">',
                    '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="14">',
                      '<path d="M23 4v6h-6"/><path d="M1 20v-6h6"/>',
                      '<path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15"/>',
                    '</svg> Generar',
                  '</button>',
                '</div>',
              '</div>',
            '</div>',
            '<div id="ge-pass-notice" class="ge-notice" style="display:none;margin-bottom:16px;"></div>',
            '<div class="ge-modal-footer">',
              '<button type="button" id="ge-pass-cancel" class="ge-btn-secondary">Cancelar</button>',
              '<button type="submit" id="ge-pass-submit" class="ge-btn-primary">',
                '<span class="ge-btn-text">Actualizar contraseña</span>',
                '<span class="ge-btn-spinner" style="display:none;"><span class="ge-spinner-sm"></span> Guardando…</span>',
              '</button>',
            '</div>',
          '</form>',
        '</div>',
        '</div>'
    ].join('');

    var MODAL_EMAIL_HTML = [
        '<div id="ge-modal-email-overlay" class="ge-modal-overlay ge-z-1" style="display:none;">',
        '<div class="ge-modal ge-modal-sm">',
          '<div class="ge-modal-header">',
            '<div class="ge-modal-header-icon">',
              '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">',
                '<path d="M4 4h16v16H4z"/><path d="m22 6-10 7L2 6"/>',
              '</svg>',
            '</div>',
            '<div>',
              '<h2 class="ge-modal-title">Cambiar correo</h2>',
              '<p class="ge-modal-desc" id="ge-email-modal-desc">Escribe el nuevo correo para este usuario</p>',
            '</div>',
            '<button id="ge-email-close" class="ge-modal-close" type="button">&times;</button>',
          '</div>',
          '<form id="ge-email-form" novalidate>',
            '<input type="hidden" id="ge-email-user-id" name="user_id" value="">',
            '<div class="ge-form-grid">',
              '<div class="ge-field ge-field-full">',
                '<label>Correo actual</label>',
                '<input type="email" id="ge-email-actual" disabled>',
              '</div>',
              '<div class="ge-field ge-field-full">',
                '<label>Nuevo correo <span class="ge-required">*</span></label>',
                '<input type="email" id="ge-email-nuevo" name="nuevo_correo" placeholder="nuevo@correo.com" required>',
              '</div>',
            '</div>',
            '<div id="ge-email-notice" class="ge-notice" style="display:none;margin-bottom:16px;"></div>',
            '<div class="ge-modal-footer">',
              '<button type="button" id="ge-email-cancel" class="ge-btn-secondary">Cancelar</button>',
              '<button type="submit" id="ge-email-submit" class="ge-btn-primary">',
                '<span class="ge-btn-text">Actualizar correo</span>',
                '<span class="ge-btn-spinner" style="display:none;"><span class="ge-spinner-sm"></span> Guardando…</span>',
              '</button>',
            '</div>',
          '</form>',
        '</div>',
        '</div>'
    ].join('');

    /* ══════════════════════════════════
       INIT
       ══════════════════════════════════ */
    // Modal \u00abCrear \u00e1reas\u00bb: tres pasos dentro del mismo di\u00e1logo (captura,
    // confirmaci\u00f3n y resultado). El paso 1 va dentro de un <form> para que
    // Enter siga enviando; los otros dos son hermanos con su propio relleno.
    var MODAL_AREA_HTML = [
        // ge-z-8: por encima del listado de áreas (ge-z-3), desde donde también
        // se abre este modal; así el listado se queda detrás en vez de cerrarse.
        '<div id="ge-modal-area-overlay" class="ge-modal-overlay ge-z-8" style="display:none;">',
        '<div class="ge-modal ge-modal-crear-areas"><div class="ge-modal-header"><div class="ge-modal-header-icon">',
        '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 3h18v18H3z"/><path d="M3 9h18M3 15h18M9 3v18"/></svg>',
        '</div><div><h2 class="ge-modal-title" id="ge-area-titulo">Crear \u00e1reas</h2>',
        '<p class="ge-modal-desc" id="ge-area-desc">Registra una o varias \u00e1reas para esta empresa</p></div>',
        '<button id="ge-area-close" class="ge-modal-close" type="button">&times;</button></div>',

        // \u2500\u2500 Paso 1: captura \u2500\u2500
        '<form id="ge-area-form" novalidate><input type="hidden" id="ge-area-grupo-id" name="grupo_id" value="">',
        '<div id="ge-area-filas" class="ge-area-filas"></div>',
        '<button type="button" id="ge-area-add" class="ge-btn-add-fila">',
        '<span class="ge-btn-add-icon" aria-hidden="true">+</span> Agregar otra \u00e1rea</button>',
        '<div id="ge-area-notice" class="ge-notice" style="display:none;margin-bottom:16px;"></div>',
        '<div class="ge-modal-footer"><button type="button" id="ge-area-cancel" class="ge-btn-secondary">Cancelar</button>',
        '<button type="submit" id="ge-area-submit" class="ge-btn-primary">Registrar \u00c1rea/s</button>',
        '</div></form>',

        // \u2500\u2500 Paso 2: confirmaci\u00f3n \u2500\u2500
        '<div id="ge-area-paso-2" class="ge-area-paso" hidden>',
        '<p class="ge-area-paso-intro" id="ge-area-confirmar-intro"></p>',
        '<div class="ge-area-tabla-scroll" id="ge-area-confirmar-tabla"></div>',
        '<div id="ge-area-notice-2" class="ge-notice error" style="display:none;margin-top:16px;"></div>',
        '<div class="ge-modal-footer"><button type="button" id="ge-area-volver" class="ge-btn-secondary">Volver</button>',
        '<button type="button" id="ge-area-crear" class="ge-btn-primary"><span class="ge-btn-text">Crear \u00e1reas</span>',
        '<span class="ge-btn-spinner" style="display:none;"><span class="ge-spinner-sm"></span> <span id="ge-area-progreso">Creando\u2026</span></span>',
        '</button></div></div>',

        // \u2500\u2500 Paso 3: resultado \u2500\u2500
        '<div id="ge-area-paso-3" class="ge-area-paso" hidden>',
        '<div id="ge-area-resultado"></div>',
        '<div class="ge-modal-footer">',
        '<button type="button" id="ge-area-reintentar" class="ge-btn-secondary" hidden>Reintentar pendientes</button>',
        '<button type="button" id="ge-area-cerrar" class="ge-btn-primary">Cerrar</button>',
        '</div></div>',

        '</div></div>'
    ].join('');

    var MODAL_AREAS_LIST_HTML = [
        '<div id="ge-modal-areas-overlay" class="ge-modal-overlay ge-z-3" style="display:none;">',
        '<div class="ge-modal ge-modal-areas"><div class="ge-modal-header"><div class="ge-modal-header-icon">',
        '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 3h18v18H3z"/><path d="M3 9h18M3 15h18M9 3v18"/></svg>',
        '</div><div><h2 id="ge-areas-list-title" class="ge-modal-title">\u00c1reas</h2>',
        '<p id="ge-areas-list-desc" class="ge-modal-desc">Listado de \u00e1reas creadas</p></div>',
        '<button type="button" id="ge-areas-crear" class="ge-btn-primary ge-modal-header-action">',
        '<span class="ge-btn-icon" aria-hidden="true">+</span> Crear Área/s</button>',
        '<button id="ge-areas-list-close" class="ge-modal-close" type="button">&times;</button></div>',
        '<div id="ge-areas-toolbar" class="ge-areas-toolbar" style="display:none;">',
        '<div class="ge-search-inner">',
        '<span class="ge-search-icon"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/></svg></span>',
        '<input type="text" id="ge-areas-search" class="ge-search-input" placeholder="Buscar \u00e1rea por nombre\u2026" autocomplete="off">',
        '</div>',
        '<span id="ge-areas-count" class="ge-areas-count"></span>',
        '</div>',
        '<div id="ge-areas-list-body" class="ge-areas-list-body">',
        '<div class="ge-spinner-wrap"><div class="ge-spinner"></div><span>Cargando \u00e1reas\u2026</span></div>',
        '</div></div></div>'
    ].join('');

    var MODAL_CURSOS_HTML = [
        '<div id="ge-modal-cursos-overlay" class="ge-modal-overlay ge-z-4" style="display:none;">',
        '<div class="ge-modal ge-modal-cursos"><div class="ge-modal-header"><div class="ge-modal-header-icon">',
        '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">',
        '<path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"/></svg>',
        '</div><div><h2 id="ge-cursos-title" class="ge-modal-title">Cursos asignados</h2>',
        '<p id="ge-cursos-desc" class="ge-modal-desc">Cursos de LearnDash y avance de cada uno</p></div>',
        '<button id="ge-cursos-close" class="ge-modal-close" type="button">&times;</button></div>',
        '<div id="ge-cursos-body" class="ge-cursos-body"></div>',
        '</div></div>'
    ].join('');

    var MODAL_EDIT_AREA_HTML = [
        '<div id="ge-modal-edit-area-overlay" class="ge-modal-overlay ge-z-4" style="display:none;">',
        '<div class="ge-modal ge-modal-sm"><div class="ge-modal-header"><div class="ge-modal-header-icon">',
        '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>',
        '</div><div><h2 class="ge-modal-title">Editar \u00c1rea</h2><p class="ge-modal-desc">Modifica los datos del \u00e1rea</p></div>',
        '<button id="ge-edit-area-close" class="ge-modal-close" type="button">&times;</button></div>',
        '<form id="ge-edit-area-form" novalidate>',
        '<input type="hidden" id="ge-edit-area-id" name="area_id" value="">',
        '<div class="ge-form-grid" style="grid-template-columns:1fr;">',
        '<div class="ge-field"><label>Nombre del \u00e1rea <span class="ge-required">*</span></label><input type="text" id="ge-edit-area-nombre" name="nombre" placeholder="Ej: \u00c1rea de Ventas" required></div>',
        '<div class="ge-field"><label>N\u00famero de cupos <span class="ge-required">*</span></label><input type="number" id="ge-edit-area-cupo" name="cupo" min="1" required></div>',
        '<div class="ge-field"><label>Fecha de expiraci\u00f3n <span class="ge-required">*</span></label><input type="date" id="ge-edit-area-fecha" name="fecha_expiracion" required></div>',
        '</div>',
        '<div id="ge-edit-area-notice" class="ge-notice" style="display:none;margin-bottom:16px;"></div>',
        '<div class="ge-modal-footer">',
        '<button type="button" id="ge-edit-area-cancel" class="ge-btn-secondary">Cancelar</button>',
        '<button type="submit" id="ge-edit-area-submit" class="ge-btn-primary">',
        '<span class="ge-btn-text">Guardar cambios</span>',
        '<span class="ge-btn-spinner" style="display:none;"><span class="ge-spinner-sm"></span> Guardando\u2026</span>',
        '</button></div></form></div></div>'
    ].join('');

    var MODAL_UPDATE_EMAILS_HTML = [
        '<div id="ge-modal-updemails-overlay" class="ge-modal-overlay ge-z-7" style="display:none;">',
        '<div class="ge-modal ge-modal-updemails"><div class="ge-modal-header"><div class="ge-modal-header-icon">',
        '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="2" y="4" width="20" height="16" rx="2"/><path d="m22 6-10 7L2 6"/></svg>',
        '</div><div><h2 class="ge-modal-title">Actualizar correos</h2><p class="ge-modal-desc">Actualización masiva de correos por archivo</p></div>',
        '<button id="ge-updemails-close" class="ge-modal-close" type="button">&times;</button></div>',
        '<div class="ge-import-stepper" id="ge-updemails-stepper"></div>',
        '<div class="ge-import-body" id="ge-updemails-body"></div>',
        '<div class="ge-modal-footer" id="ge-updemails-footer">',
        '<button type="button" id="ge-updemails-cancel" class="ge-btn-secondary">Cancelar</button>',
        '<button type="button" id="ge-updemails-back" class="ge-btn-secondary" style="display:none;">Atrás</button>',
        '<button type="button" id="ge-updemails-next" class="ge-btn-primary"><span class="ge-btn-text">Siguiente</span>',
        '<span class="ge-btn-spinner" style="display:none;"><span class="ge-spinner-sm"></span> Procesando…</span></button>',
        '</div></div></div>'
    ].join('');

    var MODAL_USERMETA_HTML = [
        '<div id="ge-modal-usermeta-overlay" class="ge-modal-overlay ge-z-6" style="display:none;">',
        '<div class="ge-modal ge-modal-usermeta"><div class="ge-modal-header"><div class="ge-modal-header-icon">',
        '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 4h16v16H4z"/><path d="M4 9h16M9 9v11"/></svg>',
        '</div><div><h2 class="ge-modal-title">WP_USERMETA</h2><p class="ge-modal-desc" id="ge-usermeta-subtitle">Registros de metadatos del usuario</p></div>',
        '<button id="ge-usermeta-close" class="ge-modal-close" type="button">&times;</button></div>',

        '<div class="ge-usermeta-toolbar">',
        '<div class="ge-search-inner ge-usermeta-search-inner">',
        '<svg class="ge-search-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/></svg>',
        '<input type="text" id="ge-usermeta-search" class="ge-search-input" placeholder="Buscar por meta_key o meta_value…">',
        '</div>',
        '<button type="button" id="ge-usermeta-add-btn" class="ge-btn-primary"><span class="ge-btn-icon">+</span>Agregar nuevo registro</button>',
        '</div>',

        '<div class="ge-usermeta-body" id="ge-usermeta-list-view">',
        '<div class="ge-table-wrap ge-usermeta-table-wrap">',
        '<table class="ge-table"><thead><tr><th>Meta Key</th><th>Meta Value</th><th style="width:110px;text-align:center;">Acciones</th></tr></thead>',
        '<tbody id="ge-usermeta-tbody"><tr class="ge-loading-row"><td colspan="3"><div class="ge-spinner-wrap"><div class="ge-spinner"></div><span>Cargando registros…</span></div></td></tr></tbody>',
        '</table>',
        '<div class="ge-pagination-bar">',
        '<div class="ge-per-page"><label for="ge-usermeta-per-page">Mostrar</label>',
        '<select id="ge-usermeta-per-page"><option value="10">10</option><option value="25" selected>25</option><option value="50">50</option><option value="100">100</option></select>',
        '<span>por página</span></div>',
        '<div class="ge-pagination-info" id="ge-usermeta-pagination-info">—</div>',
        '<div class="ge-pagination-controls" id="ge-usermeta-pagination-controls"></div>',
        '</div></div></div>',

        '<div class="ge-usermeta-body" id="ge-usermeta-form-view" style="display:none;">',
        '<form id="ge-usermeta-form" novalidate>',
        '<input type="hidden" id="ge-usermeta-form-meta-id" value="">',
        '<div class="ge-import-field"><span class="ge-import-label">Meta Key <span class="ge-required">*</span></span>',
        '<input type="text" id="ge-usermeta-form-key" placeholder="Ej: phone_number" required></div>',
        '<div class="ge-import-field"><span class="ge-import-label">Meta Value</span>',
        '<textarea id="ge-usermeta-form-value" rows="6" placeholder="Valor del meta…" class="ge-textarea"></textarea></div>',
        '<div id="ge-usermeta-form-notice" class="ge-notice error" style="display:none;margin-bottom:0;"></div>',
        '</form></div>',

        '<div class="ge-modal-footer" id="ge-usermeta-footer-list">',
        '<button type="button" id="ge-usermeta-cancel" class="ge-btn-secondary">Cerrar</button>',
        '</div>',
        '<div class="ge-modal-footer" id="ge-usermeta-footer-form" style="display:none;">',
        '<button type="button" id="ge-usermeta-form-back" class="ge-btn-secondary">Cancelar</button>',
        '<button type="button" id="ge-usermeta-form-save" class="ge-btn-primary"><span class="ge-btn-text">Guardar</span>',
        '<span class="ge-btn-spinner" style="display:none;"><span class="ge-spinner-sm"></span> Guardando…</span></button>',
        '</div>',

        '</div></div>'
    ].join('');

    var MODAL_IMPORT_HTML = [
        '<div id="ge-modal-import-overlay" class="ge-modal-overlay ge-z-5" style="display:none;">',
        '<div class="ge-modal ge-modal-import"><div class="ge-modal-header"><div class="ge-modal-header-icon">',
        '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>',
        '</div><div><h2 class="ge-modal-title">Importar usuarios</h2><p class="ge-modal-desc" id="ge-import-desc">Carga masiva de usuarios por archivo</p></div>',
        '<button id="ge-import-close" class="ge-modal-close" type="button">&times;</button></div>',
        '<div class="ge-import-stepper" id="ge-import-stepper"></div>',
        '<div class="ge-import-body" id="ge-import-body"></div>',
        '<div class="ge-modal-footer" id="ge-import-footer">',
        '<button type="button" id="ge-import-cancel" class="ge-btn-secondary">Cancelar</button>',
        '<button type="button" id="ge-import-back" class="ge-btn-secondary" style="display:none;">Atrás</button>',
        '<button type="button" id="ge-import-next" class="ge-btn-primary"><span class="ge-btn-text">Siguiente</span>',
        '<span class="ge-btn-spinner" style="display:none;"><span class="ge-spinner-sm"></span> Procesando…</span></button>',
        '</div></div></div>'
    ].join('');



    $(function () {
        // Inyectar modales al final del body (ocultos, sin CSS que los muestre)
        $('body').append(MODAL_EMPRESA_HTML).append(MODAL_PASS_HTML).append(MODAL_EMAIL_HTML).append(MODAL_AREA_HTML).append(MODAL_AREAS_LIST_HTML).append(MODAL_EDIT_AREA_HTML).append(MODAL_IMPORT_HTML).append(MODAL_USERMETA_HTML).append(MODAL_UPDATE_EMAILS_HTML).append(MODAL_CURSOS_HTML);

        bindEvents();
        if (GE_DATA.restore) {
            applyRestoreState(GE_DATA.restore);
        } else {
            loadUsers();
        }
    });

    /* ══════════════════════════════════
       EVENTOS
       ══════════════════════════════════ */
    function bindEvents() {
        $('#ge-search').on('input', function () {
            clearTimeout(searchTimer);
            searchTimer = setTimeout(loadUsers, 350);
        });

        $('#ge-per-page').on('change', function () {
            gePerPage = parseInt($(this).val(), 10) || 25;
            gePage = 1;
            renderTable();
        });

        $('#ge-filter-programa').on('change', function () {
            geProgramFilter = $(this).val();
            gePage = 1;
            renderTable();
        });

        $('#ge-search-usuarios').on('input', function () {
            clearTimeout(geSubSearchTimer);
            geSubSearchTimer = setTimeout(loadSubscribers, 350);
        });

        $('#ge-per-page-usuarios').on('change', function () {
            geSubPerPage = parseInt($(this).val(), 10) || 25;
            geSubPage = 1;
            renderSubscribersTable();
        });

        $('#ge-filter-programa-usuarios').on('change', function () {
            geSubProgramFilter = $(this).val();
            geSubPage = 1;
            renderSubscribersTable();
        });

        $('#ge-filter-empresa-usuarios').on('change', function () {
            geSubEmpresaFilter = $(this).val();
            geSubAreaFilter = '';

            var $areaSelect = $('#ge-filter-area-usuarios');
            $areaSelect.html('<option value="">Todas las áreas</option>');

            if (!geSubEmpresaFilter) {
                $areaSelect.prop('disabled', true);
                geSubPage = 1;
                renderSubscribersTable();
                return;
            }

            $areaSelect.prop('disabled', true);
            $.post(GE_DATA.ajax_url, { action: 'ge_list_areas', nonce: GE_DATA.nonce, grupo_id: geSubEmpresaFilter }, function (res) {
                if (res && res.success && res.data.areas && res.data.areas.length) {
                    res.data.areas.forEach(function (a) {
                        $areaSelect.append('<option value="' + a.id + '">' + esc(a.nombre) + '</option>');
                    });
                }
                $areaSelect.prop('disabled', false);
            }).fail(function () {
                $areaSelect.prop('disabled', false);
            });

            geSubPage = 1;
            renderSubscribersTable();
        });

        $('#ge-filter-area-usuarios').on('change', function () {
            geSubAreaFilter = $(this).val();
            geSubPage = 1;
            renderSubscribersTable();
        });

        $('#ge-filter-test-usuarios').on('change', function () {
            geSubTestFilter = $(this).val();
            geSubPage = 1;
            renderSubscribersTable();
        });

        $('#ge-sub-select-all').on('change', function () {
            var checked = this.checked;
            var visible = getFilteredSubscribers();
            var startIdx = (geSubPage - 1) * geSubPerPage;
            var pageUsers = visible.slice(startIdx, startIdx + geSubPerPage);
            pageUsers.forEach(function (u) {
                if (checked) geSelectedSubscribers[u.id] = true;
                else delete geSelectedSubscribers[u.id];
            });
            renderSubscribersTable();
        });
        $('#ge-bulk-clear-usuarios').on('click', function () {
            geSelectedSubscribers = {};
            renderSubscribersTable();
        });
        $('#ge-bulk-delete-usuarios').on('click', handleBulkDeleteClick);

        $('#ge-btn-crear').on('click', openCreateModal);
        $('#ge-btn-importar').on('click', openImportModal);
        $('#ge-btn-update-emails').on('click', openUpdateEmailsModal);

        $('#ge-btn-refresh-empresas').on('click', function () {
            var $btn = $(this).addClass('is-spinning').prop('disabled', true);
            loadUsers(false);
            setTimeout(function () { $btn.removeClass('is-spinning').prop('disabled', false); }, 600);
        });
        $('#ge-btn-refresh-usuarios').on('click', function () {
            var $btn = $(this).addClass('is-spinning').prop('disabled', true);
            loadSubscribers(false);
            setTimeout(function () { $btn.removeClass('is-spinning').prop('disabled', false); }, 600);
        });

        // Panel de filtros plegable
        $('#ge-btn-filters-empresas').on('click', function () { toggleFilterPanel('empresas'); });
        $('#ge-btn-filters-usuarios').on('click', function () { toggleFilterPanel('usuarios'); });

        // Chips de filtros activos
        $(document).on('click', '.ge-chip-remove', function () {
            removeFilter($(this).data('filter-tab'), $(this).data('filter-type'), $(this).data('filter-target'));
        });
        $(document).on('click', '[data-clear-filters]', function () {
            clearFilters($(this).data('clear-filters'));
        });

        // Botones de los estados vacíos / de error dentro de la tabla
        $(document).on('click', '[data-state-action]', function () {
            switch ($(this).data('state-action')) {
                case 'clear-empresas': clearFilters('empresas'); break;
                case 'clear-usuarios': clearFilters('usuarios'); break;
                case 'crear-empresa':  openCreateModal();        break;
                case 'importar':       openImportModal();        break;
                case 'retry-empresas': loadUsers();              break;
                case 'retry-usuarios': loadSubscribers();        break;
            }
        });

        $('.ge-tab-btn').on('click', function () {
            var tab = $(this).data('tab');
            $('.ge-tab-btn').removeClass('active').attr('aria-selected', 'false');
            $(this).addClass('active').attr('aria-selected', 'true');
            $('.ge-tab-panel').hide();
            $('[data-tab-panel="' + tab + '"]').show();

            // Los botones de acción viven dentro de cada panel, así que ya no
            // hace falta mostrarlos u ocultarlos a mano (y la cabecera deja de
            // cambiar de ancho al cambiar de pestaña).
            $('#ge-subtitle').text(GE_SUBTITULOS[tab] || '');

            if (tab === 'usuarios' && !geSubscribersLoaded) {
                geSubscribersLoaded = true;
                loadSubscribers();
                loadEmpresaOptionsForFilter();
            }
        });

        $(document).on('click', '#ge-modal-close, #ge-btn-cancel', closeMainModal);
        $(document).on('click', '#ge-pass-close, #ge-pass-cancel', closePassModal);
        $(document).on('click', '#ge-email-close, #ge-email-cancel', closeEmailModal);
        $(document).on('click', '#ge-area-close, #ge-area-cancel', closeAreaModal);
        // Grupos con subopciones. Hay que cortar la propagación: el clic no
        // debe llegar al manejador de documento que cierra el menú entero.
        $(document).on('click', '.ge-dropdown-sub-toggle', function (e) {
            e.stopPropagation();

            var $sub  = $(this).closest('.ge-dropdown-sub');
            var abrir = !$sub.hasClass('is-open');

            cerrarSubmenus($sub.parent()); // solo un grupo abierto a la vez
            $sub.toggleClass('is-open', abrir);
            $(this).attr('aria-expanded', abrir ? 'true' : 'false');
        });

        $(document).on('click', '#ge-cursos-close', closeCursosModal);
        $(document).on('click', '#ge-modal-cursos-overlay', function (e) {
            if ($(e.target).is('#ge-modal-cursos-overlay')) closeCursosModal();
        });

        $(document).on('click', '#ge-areas-list-close', closeAreasListModal);
        // Delegado: el modal se inyecta al arrancar, pero su contenido se
        // regenera en cada apertura.
        $(document).on('input', '#ge-areas-search', renderAreasList);

        // «Crear Área/s» desde el listado: abre el mismo asistente que la
        // opción del menú de acciones, apilado sobre este modal.
        $(document).on('click', '#ge-areas-crear', function () {
            if (geAreasCtx.grupoId) openAreaModal(geAreasCtx.grupoId);
        });
        $(document).on('click', '.ge-area-act-btn', function (e) {
            e.stopPropagation();
            // Mismo criterio que en las tablas: si no cabe abajo, se abre arriba.
            toggleRowDropdown($(this), $('#ge-area-dd-' + $(this).data('area-id')));
        });
        $(document).on('click', '.ge-area-act-edit', function (e) {
            e.stopPropagation();
            $('.ge-area-dropdown').removeClass('open');
            openEditAreaModal({
                id:               $(this).data('id'),
                nombre:           $(this).data('nombre'),
                cupo:             $(this).data('cupo'),
                fecha_expiracion: $(this).data('fecha')
            });
        });
        $(document).on('click', '#ge-edit-area-close, #ge-edit-area-cancel', closeEditAreaModal);
        $(document).on('click', '#ge-import-close, #ge-import-cancel', closeImportModal);
        $(document).on('click', '#ge-import-back', importGoBack);
        $(document).on('click', '#ge-import-next', importGoNext);
        $(document).on('submit', '#ge-form', handleFormSubmit);
        $(document).on('submit', '#ge-pass-form', handlePassSubmit);
        $(document).on('click',  '#ge-gen-pass', generatePassword);
        $(document).on('submit', '#ge-email-form', handleEmailSubmit);

        // Cerrar al click fuera del dropdown
        $(document).on('click', function (e) {
            if (!$(e.target).closest('.ge-actions-wrap').length) closeAllDropdowns();
        });

        // Cerrar modales con Escape
        $(document).on('keydown', function (e) {
            if ('Escape' !== e.key) return;

            closeAllDropdowns();

            // El asistente de «Crear áreas» puede estar apilado sobre el
            // listado de áreas: en ese caso Escape debe cerrar solo el de
            // arriba, no los dos a la vez.
            if ($('#ge-modal-area-overlay').is(':visible')) {
                closeAreaModal();
                return;
            }

            closeMainModal(); closePassModal(); closeAreasListModal(); closeCursosModal();
            closeEditAreaModal(); closeImportModal(); closeUsermetaModal(); closeUpdateEmailsModal();
        });

        // Click en overlay cierra modal
        $(document).on('click', '#ge-modal-overlay', function (e) {
            if ($(e.target).is('#ge-modal-overlay')) closeMainModal();
        });
        $(document).on('click', '#ge-modal-pass-overlay', function (e) {
            if ($(e.target).is('#ge-modal-pass-overlay')) closePassModal();
        });
        $(document).on('click', '#ge-modal-email-overlay', function (e) {
            if ($(e.target).is('#ge-modal-email-overlay')) closeEmailModal();
        });
        $(document).on('click', '#ge-modal-area-overlay', function (e) {
            if ($(e.target).is('#ge-modal-area-overlay')) closeAreaModal();
        });
        $(document).on('click', '#ge-modal-areas-overlay', function (e) {
            if ($(e.target).is('#ge-modal-areas-overlay')) closeAreasListModal();
        });
        $(document).on('click', '#ge-modal-edit-area-overlay', function (e) {
            if ($(e.target).is('#ge-modal-edit-area-overlay')) closeEditAreaModal();
        });
        $(document).on('click', '#ge-modal-import-overlay', function (e) {
            if ($(e.target).is('#ge-modal-import-overlay')) closeImportModal();
        });

        // Wizard de importación: empresa/área (paso 1)
        $(document).on('change', '#ge-import-empresa', importOnEmpresaChange);
        $(document).on('change', '#ge-import-area', importOnAreaChange);

        // Wizard de importación: dropzone/archivo (paso 2)
        $(document).on('click', '#ge-import-dropzone', function (e) {
            // Evitar bucle: el clic sintético sobre el input burbujea de vuelta hasta este mismo contenedor
            if (e.target && e.target.id === 'ge-import-file-input') return;
            $('#ge-import-file-input').trigger('click');
        });
        $(document).on('change', '#ge-import-file-input', function (e) {
            if (e.target.files && e.target.files[0]) importHandleFile(e.target.files[0]);
        });
        $(document).on('dragover', '#ge-import-dropzone', function (e) {
            e.preventDefault(); e.stopPropagation(); $(this).addClass('dragover');
        });
        $(document).on('dragleave', '#ge-import-dropzone', function (e) {
            e.preventDefault(); e.stopPropagation(); $(this).removeClass('dragover');
        });
        $(document).on('drop', '#ge-import-dropzone', function (e) {
            e.preventDefault(); e.stopPropagation(); $(this).removeClass('dragover');
            var files = e.originalEvent.dataTransfer && e.originalEvent.dataTransfer.files;
            if (files && files[0]) importHandleFile(files[0]);
        });
        $(document).on('click', '#ge-import-file-remove', function (e) {
            e.stopPropagation();
            geImport.file = null; geImport.rows = []; geImport.headers = [];
            renderImportStep2();
        });

        // Wizard de importación: mapeo de columnas (paso 3)
        $(document).on('change', '.ge-import-map-select', function () {
            var field = $(this).data('field');
            geImport.mapping[field] = $(this).val();
            updateImportNextState();
        });

        // Wizard de importación: pantalla final
        $(document).on('click', '#ge-import-finish', function () {
            closeImportModal();
            loadSubscribers();
        });

        // Modal "Ver WP_USERMETA"
        $(document).on('click', '#ge-usermeta-close, #ge-usermeta-cancel', closeUsermetaModal);
        $(document).on('click', '#ge-updemails-close, #ge-updemails-cancel', closeUpdateEmailsModal);
        $(document).on('click', '#ge-modal-updemails-overlay', function (e) {
            if ($(e.target).is('#ge-modal-updemails-overlay')) closeUpdateEmailsModal();
        });
        $(document).on('click', '#ge-updemails-back', updEmailsGoBack);
        $(document).on('click', '#ge-updemails-next', updEmailsGoNext);
        $(document).on('change', '#ge-updemails-col-actual', function () { geUpdEmails.colActual = $(this).val(); updUpdateNextState(); });
        $(document).on('change', '#ge-updemails-col-nuevo', function () { geUpdEmails.colNuevo = $(this).val(); updUpdateNextState(); });
        $(document).on('click', '#ge-updemails-dropzone', function (e) {
            if (e.target && e.target.id === 'ge-updemails-file-input') return;
            $('#ge-updemails-file-input').trigger('click');
        });
        $(document).on('change', '#ge-updemails-file-input', function (e) {
            if (e.target.files && e.target.files[0]) updEmailsHandleFile(e.target.files[0]);
        });
        $(document).on('dragover', '#ge-updemails-dropzone', function (e) { e.preventDefault(); e.stopPropagation(); $(this).addClass('dragover'); });
        $(document).on('dragleave', '#ge-updemails-dropzone', function (e) { e.preventDefault(); e.stopPropagation(); $(this).removeClass('dragover'); });
        $(document).on('drop', '#ge-updemails-dropzone', function (e) {
            e.preventDefault(); e.stopPropagation(); $(this).removeClass('dragover');
            var files = e.originalEvent.dataTransfer && e.originalEvent.dataTransfer.files;
            if (files && files[0]) updEmailsHandleFile(files[0]);
        });
        $(document).on('click', '#ge-updemails-file-remove', function (e) {
            e.stopPropagation();
            geUpdEmails.file = null; geUpdEmails.rows = []; geUpdEmails.headers = [];
            renderUpdEmailsStep1();
        });
        $(document).on('input', '#ge-updemails-search', function () {
            geUpdEmails.search = $(this).val();
            geUpdEmails.page = 1;
            renderUpdEmailsValidationTable();
        });
        $(document).on('change', '#ge-updemails-per-page', function () {
            geUpdEmails.perPage = parseInt($(this).val(), 10) || 25;
            geUpdEmails.page = 1;
            renderUpdEmailsValidationTable();
        });
        $(document).on('input', '#ge-updemails-results-search', function () {
            geUpdEmails.resultsSearch = $(this).val();
            geUpdEmails.resultsPage = 1;
            renderUpdEmailsResultsTable();
        });
        $(document).on('change', '#ge-updemails-results-per-page', function () {
            geUpdEmails.resultsPerPage = parseInt($(this).val(), 10) || 25;
            geUpdEmails.resultsPage = 1;
            renderUpdEmailsResultsTable();
        });
        $(document).on('click', '#ge-updemails-finish', function () {
            closeUpdateEmailsModal();
            loadSubscribers(false);
        });
        $(document).on('click', '#ge-modal-usermeta-overlay', function (e) {
            if ($(e.target).is('#ge-modal-usermeta-overlay')) closeUsermetaModal();
        });
        $(document).on('click', '#ge-usermeta-add-btn', function () { showUsermetaForm(null, '', ''); });
        $(document).on('click', '#ge-usermeta-form-back', backToUsermetaList);
        $(document).on('click', '#ge-usermeta-form-save', saveUsermetaForm);
        $(document).on('submit', '#ge-usermeta-form', function (e) { e.preventDefault(); saveUsermetaForm(); });
        $(document).on('input', '#ge-usermeta-search', function () {
            var val = $(this).val();
            clearTimeout(geUsermetaSearchTimer);
            geUsermetaSearchTimer = setTimeout(function () {
                geUsermeta.search = val;
                geUsermeta.page = 1;
                loadUsermetaList();
            }, 350);
        });
        $(document).on('change', '#ge-usermeta-per-page', function () {
            geUsermeta.perPage = parseInt($(this).val(), 10) || 25;
            geUsermeta.page = 1;
            loadUsermetaList();
        });
        $(document).on('click', '.ge-usermeta-edit-btn', function () {
            var metaId = $(this).data('meta-id');
            var item = geUsermetaCurrentItems.filter(function (it) { return String(it.meta_id) === String(metaId); })[0];
            showUsermetaForm(metaId, item ? item.meta_key : '', item ? item.meta_value : '');
        });
        $(document).on('click', '.ge-usermeta-delete-btn', function () {
            confirmDeleteUsermetaRow($(this).data('meta-id'));
        });
    }

    /* ══════════════════════════════════
       CARGAR USUARIOS
       ══════════════════════════════════ */
    function loadUsers( resetPage ) {
        if ( resetPage !== false ) gePage = 1;
        var search = $('#ge-search').val().trim();
        $('#ge-tbody').html(skeletonRowsHtml(4, 5));
        $.ajax({
            url:      GE_DATA.ajax_url,
            method:   'POST',
            data:     { action: 'ge_list_users', nonce: GE_DATA.nonce, search: search },
            dataType: 'json',
            success: function (res) {
                try {
                    if (res && res.success) {
                        geAllUsers = res.data.users || [];
                        if (geRestorePage && geRestorePage.tab === 'empresas') { gePage = geRestorePage.page; geRestorePage = null; }
                        renderTable();
                    } else {
                        renderError((res && res.data && res.data.message) ? res.data.message : 'No se pudo cargar la lista.');
                    }
                } catch (err) {
                    renderError('Error al renderizar: ' + err.message);
                    console.error('[GE]', err);
                }
            },
            error: function (xhr) {
                // Mostrar respuesta cruda si no es JSON (ej: PHP warning/fatal)
                var raw = xhr.responseText || '';
                var msg = 'Error de conexión (' + xhr.status + ').';
                if (raw && raw.length < 500) msg += '<br><small class="ge-u-mono">' + esc(raw) + '</small>';
                else if (raw) msg += '<br><small>Revisa el log de PHP para más detalles.</small>';
                renderError(msg);
                console.error('[GE] raw response:', raw);
            }
        });
    }

    function getFilteredUsers() {
        if ( ! geProgramFilter ) return geAllUsers;
        return geAllUsers.filter(function (u) {
            var hasWms = !!u.wms, hasOct = !!u.octagono;
            switch (geProgramFilter) {
                case 'wms':      return hasWms && !hasOct;
                case 'octagono': return hasOct && !hasWms;
                case 'ambos':    return hasWms && hasOct;
                case 'ninguno':  return !hasWms && !hasOct;
                default:         return true;
            }
        });
    }

    /* ══════════════════════════════════
       FILTROS: panel plegable, contador y chips
       Agrupar los selects en un panel evita que en pantallas medianas se
       repartan en varias líneas, y los chips dejan ver qué está filtrando
       aunque el panel esté cerrado.
       ══════════════════════════════════ */
    var GE_FILTERS = {
        empresas: {
            panel: '#ge-filters-empresas', boton: '#ge-btn-filters-empresas',
            cuenta: '#ge-filters-count-empresas', chips: '#ge-chips-empresas',
            busqueda: '#ge-search',
            selects: [ { sel: '#ge-filter-programa', etiqueta: 'Programa' } ]
        },
        usuarios: {
            panel: '#ge-filters-usuarios', boton: '#ge-btn-filters-usuarios',
            cuenta: '#ge-filters-count-usuarios', chips: '#ge-chips-usuarios',
            busqueda: '#ge-search-usuarios',
            selects: [
                { sel: '#ge-filter-programa-usuarios', etiqueta: 'Programa' },
                { sel: '#ge-filter-empresa-usuarios',  etiqueta: 'Empresa' },
                { sel: '#ge-filter-area-usuarios',     etiqueta: 'Área' },
                { sel: '#ge-filter-test-usuarios',     etiqueta: 'Test' }
            ]
        }
    };

    var GE_SUBTITULOS = {
        empresas: 'Administra las empresas y sus encargados',
        usuarios: 'Consulta y gestiona los usuarios asignados a cada área'
    };

    function renderFilterUI(tab) {
        var cfg = GE_FILTERS[tab];
        var activos = [];

        var q = $(cfg.busqueda).val();
        q = q ? q.trim() : '';
        if (q) activos.push({ tipo: 'busqueda', etiqueta: 'Búsqueda', valor: q });

        cfg.selects.forEach(function (s) {
            var $s = $(s.sel);
            if (!$s.val()) return;
            activos.push({ tipo: 'select', sel: s.sel, etiqueta: s.etiqueta, valor: $s.find('option:selected').text() });
        });

        $(cfg.cuenta).text(activos.length ? String(activos.length) : '');

        var $chips = $(cfg.chips);
        if (!activos.length) { $chips.empty().prop('hidden', true); return; }

        var html = activos.map(function (f) {
            return '<span class="ge-chip">'
                + '<span class="ge-chip-label">' + esc(f.etiqueta) + ': ' + esc(f.valor) + '</span>'
                + '<button type="button" class="ge-chip-remove"'
                +   ' aria-label="Quitar filtro ' + esc(f.etiqueta) + '"'
                +   ' data-filter-tab="' + tab + '" data-filter-type="' + f.tipo + '"'
                +   ' data-filter-target="' + (f.sel || '') + '">&times;</button>'
                + '</span>';
        }).join('');
        html += '<button type="button" class="ge-chips-clear" data-clear-filters="' + tab + '">Limpiar todo</button>';
        $chips.html(html).prop('hidden', false);
    }

    function updateEmpresaFilterUI()    { renderFilterUI('empresas'); }
    function updateSubscriberFilterUI() { renderFilterUI('usuarios'); }

    function toggleFilterPanel(tab) {
        var cfg     = GE_FILTERS[tab];
        var $panel  = $(cfg.panel);
        var abrir   = $panel.prop('hidden');
        $panel.prop('hidden', !abrir);
        $(cfg.boton).toggleClass('is-open', abrir).attr('aria-expanded', abrir ? 'true' : 'false');
    }

    function removeFilter(tab, tipo, target) {
        if (tipo === 'busqueda') {
            $(GE_FILTERS[tab].busqueda).val('');
            if (tab === 'empresas') loadUsers(); else loadSubscribers();
            return;
        }
        // El change de cada select ya actualiza su estado y repinta la tabla.
        $(target).val('').trigger('change');
    }

    function clearFilters(tab) {
        var cfg = GE_FILTERS[tab];
        $(cfg.busqueda).val('');
        cfg.selects.forEach(function (s) { $(s.sel).val(''); });

        if (tab === 'usuarios') {
            geSubProgramFilter = '';
            geSubTestFilter    = '';
            geSubAreaFilter    = '';
            // Su change repone el select de áreas (que depende de la empresa).
            $('#ge-filter-empresa-usuarios').trigger('change');
            loadSubscribers();
        } else {
            geProgramFilter = '';
            loadUsers();
        }
    }

    /* ══════════════════════════════════
       PIEZAS COMPARTIDAS DE LAS FILAS
       ══════════════════════════════════ */

    /**
     * Celda de identidad: nombre + correo + una línea de datos secundarios
     * (id, encargado o usuario, y fecha de registro). Antes los cinco datos se
     * apilaban con el mismo peso, lo que hacía la fila muy alta y difícil de
     * recorrer.
     *
     * @param {Object} o {nombre, email, meta: [string]}
     */
    function identityCellHtml(o) {
        var meta = (o.meta || []).filter(Boolean).map(esc).join(' <span class="ge-meta-sep">·</span> ');
        return '<td><div class="ge-identity-body">'
            + '<span class="ge-identity-name" title="' + esc(o.nombre) + '">' + esc(o.nombre) + '</span>'
            + '<span class="ge-identity-email" title="' + esc(o.email) + '">' + esc(o.email) + '</span>'
            + (meta ? '<span class="ge-identity-meta">' + meta + '</span>' : '')
            + '</div></td>';
    }

    /**
     * Badges de programas. Se pintan siempre los dos, y el que falta queda en
     * gris: así se distingue "no tiene WMS" de "no se ha sincronizado", que
     * antes eran visualmente idénticos (la celda quedaba vacía en los dos casos).
     *
     * El valor de la meta es el rol remoto ("subscriber", "customer"…). Se
     * muestra junto al nombre solo cuando no es el habitual, que es el caso que
     * merece atención; el resto va en el tooltip.
     */
    function programBadgesHtml(u) {
        return '<td class="ge-u-center ge-u-middle"><div class="ge-programas-cell">'
            + programBadgeHtml('WMS', 'ge-prog-wms', u.wms)
            + programBadgeHtml('Octágono', 'ge-prog-octagono', u.octagono)
            + '</div></td>';
    }

    function programBadgeHtml(etiqueta, clase, valor) {
        var v = String(valor || '').trim();
        var activo = v !== '';
        var sufijo = activo && v !== 'subscriber' ? ' · ' + v : '';
        return '<span class="ge-prog-badge ' + (activo ? clase : 'is-off') + '"'
            + ' title="' + esc(etiqueta + (activo ? ' · ' + v : ': sin cuenta')) + '">'
            + '<span class="ge-dot"></span>'
            + '<span class="ge-prog-name">' + esc(etiqueta + sufijo) + '</span>'
            + '</span>';
    }

    /**
     * Celda «Cursos»: el número de cursos de LearnDash asignados, clicable
     * para ver el detalle con el avance de cada uno. Sin cursos no hay nada
     * que abrir, así que la píldora queda apagada y deshabilitada.
     */
    function cursosCellHtml(u) {
        var total = parseInt(u.cursos, 10) || 0;

        if (!total) {
            return '<td class="ge-u-center ge-u-middle"><span class="ge-cursos-vacio">Sin cursos</span></td>';
        }

        return '<td class="ge-u-center ge-u-middle"><div class="ge-areas-cell">'
            + '<button type="button" class="ge-btn-ver-cursos"'
            +   ' data-id="' + u.id + '" data-nombre="' + esc(u.nombre) + '"'
            +   ' title="Ver los cursos de ' + esc(u.nombre) + '">'
            +   '<span class="ge-areas-count">' + total + '</span> ' + (1 === total ? 'curso' : 'cursos')
            +   '<span class="ge-areas-chevron">' + icon('chevron', 12) + '</span>'
            + '</button></div></td>';
    }

    /** Badge de estado del test, con icono además del color. */
    function testBadgeHtml(tieneTest) {
        return '<td class="ge-u-center ge-u-middle">'
            + (tieneTest
                ? '<span class="ge-badge-state is-ok">' + icon('check', 12) + 'Resuelto</span>'
                : '<span class="ge-badge-state is-muted">' + icon('circle', 12) + 'Sin test</span>')
            + '</td>';
    }

    /** Una opción del menú de acciones. */
    function menuItem(clase, iconName, texto, attrs) {
        return '<button type="button" class="ge-dropdown-item ' + clase + '"' + (attrs || '') + '>'
            + icon(iconName, 14) + ' ' + texto + '</button>';
    }

    /**
     * Grupo con subopciones dentro del menú de acciones. En escritorio se
     * despliega hacia un lado al pasar el ratón o al hacer clic; en pantallas
     * angostas se abre en vertical dentro del propio menú, porque un submenú
     * flotante es incómodo de acertar con el dedo.
     */
    function subMenu(iconName, texto, items) {
        return '<div class="ge-dropdown-sub">'
            + '<button type="button" class="ge-dropdown-item ge-dropdown-sub-toggle" aria-haspopup="true" aria-expanded="false">'
            +   icon(iconName, 14) + ' ' + texto
            +   '<span class="ge-dropdown-sub-caret">' + icon('chevron', 13) + '</span>'
            + '</button>'
            + '<div class="ge-dropdown-submenu">' + items + '</div>'
            + '</div>';
    }

    var MENU_SEP = '<div class="ge-dropdown-sep"></div>';

    /**
     * Celda de acciones: un único botón «Acciones» que despliega todas las
     * opciones de la fila. Lo comparten las dos tablas; lo único que cambia
     * es el contenido del menú y el prefijo del id del desplegable.
     *
     * @param {string} ddId  Id del contenedor del menú (ge-dd-N / ge-sub-dd-N).
     * @param {string} attrs Atributos del botón (data-id…).
     * @param {string} items HTML de las opciones.
     */
    function actionsCellHtml(ddId, attrs, items, claseBoton) {
        return '<td class="ge-u-center">'
            + '<div class="ge-actions-wrap">'
            // Solo el caret: los tres puntos significan "más opciones" y
            // sobran junto a una flecha que ya anuncia el desplegable.
            +   '<button type="button" class="ge-btn-actions ' + (claseBoton || '') + '"' + attrs
            +     ' aria-haspopup="true" aria-expanded="false">'
            +     'Acciones' + icon('caret', 13)
            +   '</button>'
            +   '<div class="ge-dropdown" id="' + ddId + '">' + items + '</div>'
            + '</div></td>';
    }

    /**
     * Abre un menú decidiendo si cae hacia abajo o hacia arriba. Antes siempre
     * caía hacia abajo, así que en las últimas filas se salía de la pantalla.
     */
    function toggleRowDropdown($btn, $dd) {
        if ($dd.hasClass('open')) { closeAllDropdowns(); return; }
        closeAllDropdowns();
        $btn.attr('aria-expanded', 'true');

        // Se mide con el menú fuera de vista para no provocar un salto visible.
        $dd.css('visibility', 'hidden').addClass('open');
        var alto = $dd.outerHeight();
        $dd.removeClass('open').css('visibility', '');

        var espacioAbajo = window.innerHeight - $btn[0].getBoundingClientRect().bottom;
        $dd.toggleClass('is-up', espacioAbajo < alto + 16);

        $dd.addClass('open');
        openDropdown = $dd;
    }

    /* ── Estados de la tabla: cargando / vacío / error ── */

    function skeletonRowsHtml(columnas, filas) {
        var fila = '<tr class="ge-skeleton-row" aria-hidden="true">'
            + new Array(columnas + 1).join('<td><span class="ge-skeleton ge-skeleton-line"></span></td>')
            + '</tr>';
        return new Array((filas || 5) + 1).join(fila);
    }

    function renderStateRow(tbodySel, columnas, html) {
        $(tbodySel).html('<tr class="ge-empty-row"><td colspan="' + columnas + '">' + html + '</td></tr>');
    }

    /**
     * Estado vacío con salida: si hay filtros activos ofrece limpiarlos y si la
     * lista está realmente vacía ofrece la acción de creación. Antes era solo un
     * texto gris sin nada que pulsar.
     */
    function emptyStateHtml(o) {
        var acciones = (o.actions || []).map(function (a) {
            return '<button type="button" class="' + (a.cls || 'ge-btn-secondary') + '"'
                + ' data-state-action="' + a.action + '">' + esc(a.label) + '</button>';
        }).join('');
        return '<div class="ge-state">'
            + '<span class="ge-state-icon">' + icon(o.icon || 'inbox', 22) + '</span>'
            + '<span class="ge-state-title">' + esc(o.title) + '</span>'
            + (o.text ? '<p class="ge-state-text">' + esc(o.text) + '</p>' : '')
            + (acciones ? '<div class="ge-state-actions">' + acciones + '</div>' : '')
            + '</div>';
    }

    /** `htmlMsg` llega ya escapado por quien construye el mensaje. */
    function errorStateHtml(htmlMsg, retryAction) {
        return '<div class="ge-state is-error">'
            + '<span class="ge-state-icon">' + icon('alert', 22) + '</span>'
            + '<span class="ge-state-title">No se pudo cargar la lista</span>'
            + '<p class="ge-state-text">' + htmlMsg + '</p>'
            + '<div class="ge-state-actions">'
            +   '<button type="button" class="ge-btn-primary" data-state-action="' + retryAction + '">Reintentar</button>'
            + '</div>'
            + '</div>';
    }

    function setTabCount(tab, n) {
        $('#ge-tab-count-' + tab).text(typeof n === 'number' ? formatNumber(n) : '');
    }

    function formatNumber(n) {
        return String(n).replace(/\B(?=(\d{3})+(?!\d))/g, '.');
    }

    function renderTable() {
        var visibleUsers = getFilteredUsers();
        var total = visibleUsers.length;
        setTabCount('empresas', geAllUsers.length);
        updateEmpresaFilterUI();

        if (!total) {
            var hayBusqueda = $('#ge-search').val().trim() !== '';
            var hayFiltro   = hayBusqueda || !!geProgramFilter;
            renderStateRow('#ge-tbody', 4, hayFiltro
                ? emptyStateHtml({
                    icon:  'search',
                    title: 'Ninguna empresa coincide',
                    text:  'Prueba con otro término de búsqueda o quita los filtros activos.',
                    actions: [ { action: 'clear-empresas', label: 'Limpiar filtros' } ]
                })
                : emptyStateHtml({
                    icon:  'building',
                    title: 'Aún no hay empresas',
                    text:  'Crea la primera empresa para empezar a dar de alta áreas y usuarios.',
                    actions: [ { action: 'crear-empresa', label: 'Crear empresa', cls: 'ge-btn-primary' } ]
                })
            );
            $('#ge-pagination-info').text('—');
            $('#ge-pagination-controls').empty();
            return;
        }

        var totalPages = Math.max(1, Math.ceil(total / gePerPage));
        if (gePage > totalPages) gePage = totalPages;
        if (gePage < 1) gePage = 1;

        var startIdx = (gePage - 1) * gePerPage;
        var endIdx   = Math.min(startIdx + gePerPage, total);
        var users    = visibleUsers.slice(startIdx, endIdx);

        var rows = '';
        for (var i = 0; i < users.length; i++) {
            var u = users[i];
            var cnt   = parseInt(u.area_count, 10) || 0;
            var label = cnt === 1 ? '\u00e1rea' : '\u00e1reas';
            var attrId = ' data-id="' + u.id + '"';

            // `nombre` (meta nombre_cargado) es el encargado de la empresa: lo
            // devolv\u00eda el endpoint pero nunca se mostraba. Aporta m\u00e1s que repetir
            // el rol, que es el mismo en todas las filas de esta pesta\u00f1a.
            var tdEmpresa = identityCellHtml({
                nombre: u.empresa,
                email:  u.email,
                meta:   [ '#' + u.id, u.nombre, u.registrado ]
            });

            var tdAreas = '<td class="ge-u-center ge-u-middle"><div class="ge-areas-cell">'
                + '<button type="button" class="ge-btn-ver-areas' + (cnt ? '' : ' is-empty') + '"'
                +   attrId + ' data-empresa="' + esc(u.empresa) + '"'
                +   ' title="Ver las \u00e1reas de ' + esc(u.empresa) + '">'
                +   '<span class="ge-areas-count">' + cnt + '</span> ' + label
                +   '<span class="ge-areas-chevron">' + icon('chevron', 12) + '</span>'
                + '</button></div></td>';

            var tdProgramas = programBadgesHtml(u);

            // La acci\u00f3n m\u00e1s frecuente y la destructiva quedan a la vista; el
            // resto se agrupa por intenci\u00f3n, para no desplegar ocho opciones
            // sueltas de golpe.
            var tdAcciones = actionsCellHtml('ge-dd-' + u.id, attrId,
                  menuItem('ge-act-switch', 'user', 'Entrar como usuario', attrId)
                + MENU_SEP
                + subMenu('folder', 'Datos de la empresa',
                      menuItem('ge-act-edit', 'edit', 'Editar datos', attrId)
                    + menuItem('ge-act-area', 'grid', 'Crear \u00e1rea', attrId)
                  )
                + subMenu('lock', 'Cuenta y credenciales',
                      menuItem('ge-act-pass', 'lock', 'Editar contrase\u00f1a', attrId)
                    + menuItem('ge-act-email', 'mail', 'Cambiar correo', attrId + ' data-email="' + esc(u.email) + '"')
                  )
                + subMenu('refresh', 'Sincronizaci\u00f3n y datos',
                      menuItem('ge-act-refresh-programas', 'refresh', 'Refrescar programas', attrId + ' data-empresa="' + esc(u.empresa) + '"')
                    + menuItem('ge-act-usermeta is-technical', 'database', 'Ver wp_usermeta', attrId + ' data-nombre="' + esc(u.empresa) + '"')
                  )
                + MENU_SEP
                + menuItem('ge-act-delete ge-act-delete-danger', 'trash', 'Eliminar empresa', attrId + ' data-empresa="' + esc(u.empresa) + '"')
            );

            rows += '<tr data-id="' + u.id + '">' + tdEmpresa + tdAreas + tdProgramas + tdAcciones + '</tr>';
        }

        $('#ge-tbody').html(rows);
        renderPagination(total, totalPages, startIdx, endIdx);

        $('#ge-tbody').off('click.ge')
            .on('click.ge', '.ge-btn-actions', function (e) {
                e.stopPropagation();
                toggleRowDropdown($(this), $('#ge-dd-' + $(this).data('id')));
            })
            .on('click.ge', '.ge-act-switch', function (e) {
                e.stopPropagation(); closeAllDropdowns(); switchToUser($(this).data('id'));
            })
            .on('click.ge', '.ge-act-edit', function (e) {
                e.stopPropagation(); closeAllDropdowns(); openEditModal($(this).data('id'));
            })
            .on('click.ge', '.ge-act-area', function (e) {
                e.stopPropagation(); closeAllDropdowns(); openAreaModal($(this).data('id'));
            })
            .on('click.ge', '.ge-act-pass', function (e) {
                e.stopPropagation(); closeAllDropdowns(); openPassModal($(this).data('id'));
            })
            .on('click.ge', '.ge-act-email', function (e) {
                e.stopPropagation(); closeAllDropdowns();
                openEmailModal($(this).data('id'), $(this).data('email'), 'empresas');
            })
            .on('click.ge', '.ge-act-usermeta', function (e) {
                e.stopPropagation(); closeAllDropdowns();
                openUsermetaModal($(this).data('id'), $(this).data('nombre'));
            })
            .on('click.ge', '.ge-act-delete', function (e) {
                e.stopPropagation(); closeAllDropdowns();
                confirmDeleteEmpresa($(this).data('id'), $(this).data('empresa'));
            })
            .on('click.ge', '.ge-act-refresh-programas', function (e) {
                e.stopPropagation(); closeAllDropdowns();
                confirmRefreshProgramas($(this).data('id'), $(this).data('empresa'));
            })
            .on('click.ge', '.ge-btn-ver-areas', function (e) {
                e.stopPropagation();
                openAreasListModal($(this).data('id'), $(this).data('empresa'));
            });
    }

    function renderPagination(total, totalPages, startIdx, endIdx, opts) {
        opts = opts || {};
        var infoSel     = opts.infoSel     || '#ge-pagination-info';
        var controlsSel = opts.controlsSel || '#ge-pagination-controls';
        var getPage     = opts.getPage     || function () { return gePage; };
        var setPage     = opts.setPage     || function (p) { gePage = p; };
        var rerender    = opts.rerender    || renderTable;

        $(infoSel).text('Mostrando ' + (startIdx + 1) + '\u2013' + endIdx + ' de ' + total);

        var $controls = $(controlsSel);
        $controls.empty();

        if (totalPages <= 1) return;

        var currentPage = getPage();

        var $prev = $('<button type="button" class="ge-page-btn" aria-label="Anterior">&lsaquo;</button>');
        $prev.prop('disabled', currentPage === 1);
        $prev.on('click', function () { if (getPage() > 1) { setPage(getPage() - 1); rerender(); } });
        $controls.append($prev);

        // Rango de páginas a mostrar (máx 5 números visibles + elipsis)
        var pages = [];
        var windowSize = 2;
        for (var p = 1; p <= totalPages; p++) {
            if (p === 1 || p === totalPages || (p >= currentPage - windowSize && p <= currentPage + windowSize)) {
                pages.push(p);
            }
        }

        var lastShown = 0;
        pages.forEach(function (p) {
            if (lastShown && p - lastShown > 1) {
                $controls.append('<span class="ge-page-ellipsis">\u2026</span>');
            }
            var $btn = $('<button type="button" class="ge-page-btn">' + p + '</button>');
            if (p === currentPage) $btn.addClass('active');
            $btn.on('click', function () { setPage(p); rerender(); });
            $controls.append($btn);
            lastShown = p;
        });

        var $next = $('<button type="button" class="ge-page-btn" aria-label="Siguiente">&rsaquo;</button>');
        $next.prop('disabled', currentPage === totalPages);
        $next.on('click', function () { if (getPage() < totalPages) { setPage(getPage() + 1); rerender(); } });
        $controls.append($next);
    }

    function renderError(msg) {
        renderStateRow('#ge-tbody', 4, errorStateHtml(msg, 'retry-empresas'));
        $('#ge-pagination-info').text('—');
        $('#ge-pagination-controls').empty();
    }

    /* ══════════════════════════════════
       TAB USUARIOS (rol subscriber)
       ══════════════════════════════════ */
    function loadSubscribers(resetPage) {
        if (resetPage !== false) geSubPage = 1;
        var search = $('#ge-search-usuarios').val().trim();
        $('#ge-tbody-usuarios').html(skeletonRowsHtml(7, 5));
        $.ajax({
            url:      GE_DATA.ajax_url,
            method:   'POST',
            data:     { action: 'ge_list_subscribers', nonce: GE_DATA.nonce, search: search },
            dataType: 'json',
            success: function (res) {
                try {
                    if (res && res.success) {
                        geAllSubscribers = res.data.users || [];
                        if (geRestorePage && geRestorePage.tab === 'usuarios') { geSubPage = geRestorePage.page; geRestorePage = null; }
                        renderSubscribersTable();
                    } else {
                        renderSubscribersError((res && res.data && res.data.message) ? res.data.message : 'No se pudo cargar la lista.');
                    }
                } catch (err) {
                    renderSubscribersError('Error al renderizar: ' + err.message);
                    console.error('[GE]', err);
                }
            },
            error: function (xhr) {
                var raw = xhr.responseText || '';
                var msg = 'Error de conexión (' + xhr.status + ').';
                if (raw && raw.length < 500) msg += '<br><small class="ge-u-mono">' + esc(raw) + '</small>';
                renderSubscribersError(msg);
                console.error('[GE] raw response:', raw);
            }
        });
    }

    function loadEmpresaOptionsForFilter() {
        if (geEmpresaOptionsLoaded) return;
        $.post(GE_DATA.ajax_url, { action: 'ge_list_users', nonce: GE_DATA.nonce, search: '' }, function (res) {
            if (!res || !res.success) return;
            geEmpresaOptionsLoaded = true;
            var empresas = (res.data.users || []).slice().sort(function (a, b) {
                return (a.empresa || '').localeCompare(b.empresa || '');
            });
            var $select = $('#ge-filter-empresa-usuarios');
            empresas.forEach(function (e) {
                $select.append('<option value="' + e.id + '">' + esc(e.empresa) + '</option>');
            });
            applyRestoredSubscriberFilters();
        });
    }

    /* ══════════════════════════════════
       RESTAURAR LISTADO (volver desde "Entrar como usuario")
       ══════════════════════════════════ */
    function getReturnState() {
        var tab = $('.ge-tab-btn.active').data('tab') === 'usuarios' ? 'usuarios' : 'empresas';
        if (tab === 'usuarios') {
            return {
                tab: tab, q: $('#ge-search-usuarios').val().trim(), prog: geSubProgramFilter,
                emp: geSubEmpresaFilter, area: geSubAreaFilter, test: geSubTestFilter,
                pp: geSubPerPage, pg: geSubPage
            };
        }
        return { tab: tab, q: $('#ge-search').val().trim(), prog: geProgramFilter, pp: gePerPage, pg: gePage };
    }

    function applyRestoreState(r) {
        // Limpiar los parámetros de la URL para que un F5 no vuelva a aplicar el estado
        try {
            var url = new URL(window.location.href);
            ['ge_back', 'ge_tab', 'ge_q', 'ge_prog', 'ge_emp', 'ge_area', 'ge_test', 'ge_pp', 'ge_pg'].forEach(function (k) { url.searchParams.delete(k); });
            window.history.replaceState(null, '', url.toString());
        } catch (e) { /* navegador sin soporte: no es crítico */ }

        if (r.tab === 'usuarios') {
            geSubPerPage       = r.pp;
            geSubProgramFilter = r.prog || '';
            geSubTestFilter    = r.test || '';
            geSubEmpresaFilter = r.emp ? String(r.emp) : '';
            geSubAreaFilter    = r.area ? String(r.area) : '';
            $('#ge-per-page-usuarios').val(String(r.pp));
            $('#ge-filter-programa-usuarios').val(geSubProgramFilter);
            $('#ge-filter-test-usuarios').val(geSubTestFilter);
            $('#ge-search-usuarios').val(r.q || '');
            geRestorePage       = { tab: 'usuarios', page: r.pg };
            geRestoreSubFilters = { emp: geSubEmpresaFilter, area: geSubAreaFilter };

            loadUsers();
            // Abre la pestaña Usuarios (carga el listado y las opciones de empresa)
            $('.ge-tab-btn[data-tab="usuarios"]').trigger('click');
        } else {
            gePerPage       = r.pp;
            geProgramFilter = r.prog || '';
            $('#ge-per-page').val(String(r.pp));
            $('#ge-filter-programa').val(geProgramFilter);
            $('#ge-search').val(r.q || '');
            geRestorePage = { tab: 'empresas', page: r.pg };
            loadUsers();
        }
        showToast('Sesión de administrador restaurada.', 'success');
    }

    function applyRestoredSubscriberFilters() {
        if (!geRestoreSubFilters) return;
        var f = geRestoreSubFilters;
        geRestoreSubFilters = null;
        if (!f.emp) return;

        var $emp = $('#ge-filter-empresa-usuarios');
        $emp.val(f.emp);
        if ($emp.val() !== f.emp) { // la empresa ya no existe: se descarta el filtro
            geSubEmpresaFilter = ''; geSubAreaFilter = '';
            renderSubscribersTable();
            return;
        }

        var $areaSelect = $('#ge-filter-area-usuarios').prop('disabled', true);
        $.post(GE_DATA.ajax_url, { action: 'ge_list_areas', nonce: GE_DATA.nonce, grupo_id: f.emp }, function (res) {
            if (res && res.success && res.data.areas) {
                res.data.areas.forEach(function (a) {
                    $areaSelect.append('<option value="' + a.id + '">' + esc(a.nombre) + '</option>');
                });
            }
            if (f.area) {
                $areaSelect.val(f.area);
                if ($areaSelect.val() !== f.area) { geSubAreaFilter = ''; renderSubscribersTable(); }
            }
            $areaSelect.prop('disabled', false);
        }).fail(function () {
            $areaSelect.prop('disabled', false);
        });
    }

    function getFilteredSubscribers() {
        var list = geAllSubscribers;

        if (geSubProgramFilter) {
            list = list.filter(function (u) {
                var hasWms = !!u.wms, hasOct = !!u.octagono;
                switch (geSubProgramFilter) {
                    case 'wms':      return hasWms && !hasOct;
                    case 'octagono': return hasOct && !hasWms;
                    case 'ambos':    return hasWms && hasOct;
                    case 'ninguno':  return !hasWms && !hasOct;
                    default:         return true;
                }
            });
        }

        if (geSubEmpresaFilter) {
            list = list.filter(function (u) { return String(u.empresa_id) === String(geSubEmpresaFilter); });
        }

        if (geSubAreaFilter) {
            list = list.filter(function (u) { return String(u.area_id) === String(geSubAreaFilter); });
        }

        if (geSubTestFilter) {
            list = list.filter(function (u) {
                return geSubTestFilter === 'con_test' ? !!u.test : !u.test;
            });
        }

        return list;
    }

    function renderSubscribersTable() {
        var visible = getFilteredSubscribers();
        var total = visible.length;
        setTabCount('usuarios', geAllSubscribers.length);
        updateSubscriberFilterUI();

        if (!total) {
            var hayFiltro = $('#ge-search-usuarios').val().trim() !== ''
                || !!geSubProgramFilter || !!geSubEmpresaFilter || !!geSubAreaFilter || !!geSubTestFilter;
            renderStateRow('#ge-tbody-usuarios', 7, hayFiltro
                ? emptyStateHtml({
                    icon:  'search',
                    title: 'Ningún usuario coincide',
                    text:  'Prueba con otro término de búsqueda o quita los filtros activos.',
                    actions: [ { action: 'clear-usuarios', label: 'Limpiar filtros' } ]
                })
                : emptyStateHtml({
                    icon:  'users',
                    title: 'Aún no hay usuarios',
                    text:  'Importa usuarios desde un CSV o XLSX para asignarlos a un área.',
                    actions: [ { action: 'importar', label: 'Importar usuarios', cls: 'ge-btn-primary' } ]
                })
            );
            $('#ge-pagination-info-usuarios').text('—');
            $('#ge-pagination-controls-usuarios').empty();
            return;
        }

        var totalPages = Math.max(1, Math.ceil(total / geSubPerPage));
        if (geSubPage > totalPages) geSubPage = totalPages;
        if (geSubPage < 1) geSubPage = 1;

        var startIdx = (geSubPage - 1) * geSubPerPage;
        var endIdx   = Math.min(startIdx + geSubPerPage, total);
        var users    = visible.slice(startIdx, endIdx);

        var rows = '';
        for (var i = 0; i < users.length; i++) {
            var u = users[i];

            var attrId    = ' data-id="' + u.id + '"';
            var seleccion = !!geSelectedSubscribers[u.id];

            var tdCheckbox = '<td class="ge-u-center ge-u-middle">'
                + '<input type="checkbox" class="ge-sub-row-checkbox" value="' + u.id + '"'
                + (seleccion ? ' checked' : '')
                + ' aria-label="Seleccionar ' + esc(u.nombre) + '">'
                + '</td>';

            // El rol es id\u00e9ntico en todas las filas (subscriber); en su lugar la
            // l\u00ednea secundaria lleva el usuario de WordPress, que s\u00ed identifica.
            var tdUsuario = identityCellHtml({
                nombre: u.nombre,
                email:  u.email,
                meta:   [ '#' + u.id, u.username, u.registrado ]
            });

            // La empresa pasa aqu\u00ed: es el dato que se consulta junto al \u00e1rea, no
            // junto al nombre.
            var tdAsignacion = '<td class="ge-u-middle"><div class="ge-assign-cell">'
                + (u.area
                    ? '<span class="ge-assign-area" title="' + esc(u.area) + '">' + esc(u.area) + '</span>'
                    : '<span class="ge-assign-empty">Sin \u00e1rea</span>')
                + (u.empresa ? '<span class="ge-assign-empresa" title="' + esc(u.empresa) + '">' + esc(u.empresa) + '</span>' : '')
                + '</div></td>';

            var tdTest = testBadgeHtml(u.test);

            var tdCursos = cursosCellHtml(u);

            var tdProgramas = programBadgesHtml(u);

            // Mismos grupos y mismas posiciones que en Empresas: aunque aquí
            // haya menos opciones, el admin aprende una sola disposición.
            var tdAcciones = actionsCellHtml('ge-sub-dd-' + u.id, attrId,
                  menuItem('ge-sub-act-switch', 'user', 'Entrar como usuario', attrId)
                + MENU_SEP
                + subMenu('lock', 'Cuenta y credenciales',
                      menuItem('ge-sub-act-email', 'mail', 'Cambiar correo', attrId + ' data-email="' + esc(u.email) + '"')
                  )
                + subMenu('refresh', 'Sincronización y datos',
                      menuItem('ge-sub-act-refresh', 'refresh', 'Refrescar programas', attrId + ' data-nombre="' + esc(u.nombre) + '"')
                    + menuItem('ge-sub-act-usermeta is-technical', 'database', 'Ver wp_usermeta', attrId + ' data-nombre="' + esc(u.nombre) + '"')
                  )
                + MENU_SEP
                + menuItem('ge-sub-act-delete ge-act-delete-danger', 'trash', 'Borrar usuario', attrId + ' data-nombre="' + esc(u.nombre) + '"'),
                'ge-sub-btn-actions'
            );

            rows += '<tr data-id="' + u.id + '"' + (seleccion ? ' class="is-selected"' : '') + '>'
                + tdCheckbox + tdUsuario + tdAsignacion + tdTest + tdCursos + tdProgramas + tdAcciones + '</tr>';
        }

        $('#ge-tbody-usuarios').html(rows);
        renderPagination(total, totalPages, startIdx, endIdx, {
            infoSel:     '#ge-pagination-info-usuarios',
            controlsSel: '#ge-pagination-controls-usuarios',
            getPage:     function () { return geSubPage; },
            setPage:     function (p) { geSubPage = p; },
            rerender:    renderSubscribersTable
        });
        updateBulkBar();
        syncSelectAllCheckbox(users);

        $('#ge-tbody-usuarios').off('click.ge change.ge')
            .on('change.ge', '.ge-sub-row-checkbox', function () {
                var id = $(this).val();
                if (this.checked) geSelectedSubscribers[id] = true;
                else delete geSelectedSubscribers[id];
                $(this).closest('tr').toggleClass('is-selected', this.checked);
                updateBulkBar();
                syncSelectAllCheckbox(users);
            })
            .on('click.ge', '.ge-btn-ver-cursos', function (e) {
                e.stopPropagation();
                openCursosModal($(this).data('id'), $(this).data('nombre'));
            })
            .on('click.ge', '.ge-sub-btn-actions', function (e) {
                e.stopPropagation();
                toggleRowDropdown($(this), $('#ge-sub-dd-' + $(this).data('id')));
            })
            .on('click.ge', '.ge-sub-act-switch', function (e) {
                e.stopPropagation(); closeAllDropdowns(); switchToUser($(this).data('id'));
            })
            .on('click.ge', '.ge-sub-act-refresh', function (e) {
                e.stopPropagation(); closeAllDropdowns();
                confirmRefreshProgramaUsuario($(this).data('id'), $(this).data('nombre'));
            })
            .on('click.ge', '.ge-sub-act-usermeta', function (e) {
                e.stopPropagation(); closeAllDropdowns();
                openUsermetaModal($(this).data('id'), $(this).data('nombre'));
            })
            .on('click.ge', '.ge-sub-act-email', function (e) {
                e.stopPropagation(); closeAllDropdowns();
                openEmailModal($(this).data('id'), $(this).data('email'), 'usuarios');
            })
            .on('click.ge', '.ge-sub-act-delete', function (e) {
                e.stopPropagation(); closeAllDropdowns();
                handleDeleteSubscriberClick($(this).data('id'), $(this).data('nombre'));
            });
    }

    function renderSubscribersError(msg) {
        renderStateRow('#ge-tbody-usuarios', 7, errorStateHtml(msg, 'retry-usuarios'));
        $('#ge-pagination-info-usuarios').text('—');
        $('#ge-pagination-controls-usuarios').empty();
    }

    function confirmRefreshProgramaUsuario(userId, nombreUsuario) {
        Swal.fire({
            icon: 'question',
            title: '\u00bfRefrescar programas?',
            html: '<p class="ge-u-body">' +
                  'Esta acci\u00f3n refrescar\u00e1 el tipo de programa (WMS y Oct\u00e1gono) de <strong>' + esc(nombreUsuario) + '</strong>. ' +
                  '\u00bfDesea continuar?' +
                  '</p>',
            showCancelButton: true,
            confirmButtonText: 'S\u00ed, refrescar',
            cancelButtonText: 'Cancelar',
            confirmButtonColor: geColor('--ge-accent', '#944DE9'),
            cancelButtonColor: geColor('--ge-text-muted', '#6B6672'),
            reverseButtons: true,
        }).then(function (result) {
            if (!result.isConfirmed) return;
            processSyncQueue([{ user_id: userId }], function () { loadSubscribers(false); });
        });
    }

    /* ══════════════════════════════════
       BORRAR USUARIO (tab Usuarios)
       ══════════════════════════════════ */
    function handleDeleteSubscriberClick(userId, nombreUsuario) {
        // 1) Refrescar programas automáticamente, sin pedir confirmación
        Swal.fire({
            title: 'Refrescando programas del usuario\u2026',
            allowOutsideClick: false,
            allowEscapeKey: false,
            showConfirmButton: false,
            didOpen: function () { Swal.showLoading(); }
        });

        $.post(GE_DATA.ajax_url, {
            action:  'ge_sync_program_user',
            nonce:   GE_DATA.nonce,
            user_id: userId
        }).always(function () {
            // 2) Independientemente del resultado del refresco, validar el estado actual en wp_usermeta
            $.post(GE_DATA.ajax_url, {
                action:  'ge_get_subscriber_programs',
                nonce:   GE_DATA.nonce,
                user_id: userId
            }).then(function (res) {
                var wms      = (res && res.success) ? res.data.wms      : '';
                var octagono = (res && res.success) ? res.data.octagono : '';
                showDeleteSubscriberConfirm(userId, nombreUsuario, wms, octagono);
            }, function () {
                showDeleteSubscriberConfirm(userId, nombreUsuario, '', '');
            });
        });
    }

    function showDeleteSubscriberConfirm(userId, nombreUsuario, wms, octagono) {
        var hasWms = !!wms;
        var hasOct = !!octagono;
        var mensaje;

        if (hasWms && hasOct) {
            mensaje = 'Este usuario tiene asignados los programas WMS y Oct\u00e1gono. Al eliminarlo de Inspira, perder\u00e1 el acceso a Inspira; sin embargo, conservar\u00e1 el acceso a los programas WMS y Oct\u00e1gono.';
        } else if (hasWms) {
            mensaje = 'Este usuario tiene asignado el programa WMS. Al eliminarlo de Inspira, perder\u00e1 el acceso a Inspira; sin embargo, conservar\u00e1 el acceso al programa WMS.';
        } else if (hasOct) {
            mensaje = 'Este usuario tiene asignado el programa Oct\u00e1gono. Al eliminarlo de Inspira, perder\u00e1 el acceso a Inspira; sin embargo, conservar\u00e1 el acceso al programa Oct\u00e1gono.';
        } else {
            mensaje = '\u00bfDesea eliminar este usuario de forma permanente?';
        }

        Swal.fire({
            icon: (hasWms || hasOct) ? 'info' : 'warning',
            title: (hasWms || hasOct) ? 'Usuario con programa activo' : 'Eliminar usuario',
            html: '<p class="ge-u-body">' + esc(mensaje) + '</p>',
            showCancelButton: true,
            confirmButtonText: 'Eliminar usuario',
            cancelButtonText: 'Cancelar',
            confirmButtonColor: geColor('--ge-error', '#B42318'),
            cancelButtonColor: geColor('--ge-text-muted', '#6B6672'),
            reverseButtons: true,
            customClass: { popup: 'ge-swal-delete-popup' }
        }).then(function (result) {
            if (!result.isConfirmed) return;
            executeDeleteSubscriber(userId);
        });
    }

    function updateBulkBar() {
        var count = Object.keys(geSelectedSubscribers).length;
        // Se usa el atributo `hidden` (no .show()/.hide()) porque la barra es un
        // flex container: un display:block en línea rompería su disposición.
        if (count > 0) {
            $('#ge-bulk-count-usuarios').text(count + (count === 1 ? ' seleccionado' : ' seleccionados'));
        }
        $('#ge-bulk-bar-usuarios').prop('hidden', count === 0);
    }

    function syncSelectAllCheckbox(pageUsers) {
        var $selectAll = $('#ge-sub-select-all');
        if (!pageUsers.length) { $selectAll.prop('checked', false).prop('indeterminate', false); return; }
        var selectedOnPage = pageUsers.filter(function (u) { return !!geSelectedSubscribers[u.id]; }).length;
        $selectAll.prop('checked', selectedOnPage === pageUsers.length);
        $selectAll.prop('indeterminate', selectedOnPage > 0 && selectedOnPage < pageUsers.length);
    }

    function handleBulkDeleteClick() {
        var ids = Object.keys(geSelectedSubscribers);
        if (!ids.length) return;

        Swal.fire({
            title: 'Refrescando programas\u2026',
            html: '<p class="ge-u-body-sm">Verificando ' + ids.length + ' usuario(s) antes de continuar.</p>',
            allowOutsideClick: false,
            allowEscapeKey: false,
            showConfirmButton: false,
            didOpen: function () { Swal.showLoading(); }
        });

        var members = ids.map(function (id) { return { user_id: id }; });

        silentSyncMembers(members).always(function () {
            var calls = ids.map(function (id) {
                return $.post(GE_DATA.ajax_url, { action: 'ge_get_subscriber_programs', nonce: GE_DATA.nonce, user_id: id })
                    .then(function (res) {
                        return { id: id, wms: res && res.success ? res.data.wms : '', octagono: res && res.success ? res.data.octagono : '' };
                    }, function () {
                        return { id: id, wms: '', octagono: '' };
                    });
            });

            $.when.apply($, calls).then(function () {
                var results = calls.length === 1 ? [arguments[0]] : Array.prototype.slice.call(arguments);
                showBulkDeletePreview(ids, results);
            });
        });
    }

    function showBulkDeletePreview(ids, programResults) {
        var byId = {};
        programResults.forEach(function (r) { byId[r.id] = r; });

        var rows = ids.map(function (id) {
            var u = geAllSubscribers.filter(function (s) { return String(s.id) === String(id); })[0] || { id: id, nombre: '(desconocido)', email: '' };
            var p = byId[id] || { wms: '', octagono: '' };
            return '<tr><td><div class="ge-del-user-cell">' +
                '<span class="ge-del-user-id">#' + esc(id) + '</span>' +
                '<span class="ge-del-user-name">' + esc(u.nombre) + '</span>' +
                '<span class="ge-del-user-email">' + esc(u.email || '') + '</span>' +
                '</div></td><td>' + programBadgesHtmlForDelete(p.wms, p.octagono) + '</td></tr>';
        }).join('');

        var html = '<div class="ge-del-preview-scroll">' +
            '<table class="ge-del-preview-table"><thead><tr><th>Usuario</th><th>Programas</th></tr></thead><tbody>' + rows + '</tbody></table>' +
            '</div>' +
            '<p class="ge-del-warning">\u00bfDeseas eliminar estos ' + ids.length + ' usuario(s) de forma permanente? Los que tengan programas activos (WMS/Oct\u00e1gono) conservar\u00e1n el acceso a esos programas, pero perder\u00e1n el acceso a Inspira.</p>';

        Swal.fire({
            title: 'Revisar antes de eliminar',
            html: html,
            width: 640,
            showCancelButton: true,
            confirmButtonText: 'S\u00ed, eliminar ' + ids.length,
            cancelButtonText: 'Cancelar',
            confirmButtonColor: geColor('--ge-error', '#B42318'),
            cancelButtonColor: geColor('--ge-text-muted', '#6B6672'),
            focusCancel: true,
            reverseButtons: true,
            customClass: { popup: 'ge-swal-delete-popup ge-swal-delete-preview' },
        }).then(function (result) {
            if (!result.isConfirmed) return;
            executeBulkDeleteSubscribers(ids);
        });
    }

    function executeBulkDeleteSubscribers(ids) {
        var total = ids.length, done = 0, okCount = 0, failCount = 0;

        Swal.fire({
            title: 'Eliminando usuarios\u2026',
            html: renderProgressHtml(0, total),
            allowOutsideClick: false,
            allowEscapeKey: false,
            showConfirmButton: false,
        });

        function deleteOne(id) {
            return $.post(GE_DATA.ajax_url, { action: 'ge_delete_subscriber', nonce: GE_DATA.nonce, user_id: id })
                .then(function (res) { if (res && res.success) okCount++; else failCount++; }, function () { failCount++; })
                .always(function () {
                    done++;
                    Swal.update({ html: renderProgressHtml(done, total) });
                });
        }

        function processBatch(startIdx) {
            if (startIdx >= total) {
                geSelectedSubscribers = {};
                loadSubscribers(false);
                Swal.fire({
                    icon: failCount ? 'warning' : 'success',
                    title: 'Proceso completado',
                    text: okCount + ' usuario(s) eliminado(s) correctamente' + (failCount ? ', ' + failCount + ' con error.' : '.'),
                    confirmButtonText: 'Aceptar',
                    confirmButtonColor: geColor('--ge-accent', '#944DE9'),
                });
                return;
            }
            var batch = ids.slice(startIdx, startIdx + GE_SYNC_BATCH_SIZE);
            $.when.apply($, batch.map(deleteOne)).always(function () {
                processBatch(startIdx + GE_SYNC_BATCH_SIZE);
            });
        }

        processBatch(0);
    }

    function executeDeleteSubscriber(userId) {
        Swal.fire({
            title: 'Eliminando usuario\u2026',
            allowOutsideClick: false,
            allowEscapeKey: false,
            showConfirmButton: false,
            didOpen: function () { Swal.showLoading(); }
        });

        $.post(GE_DATA.ajax_url, {
            action:  'ge_delete_subscriber',
            nonce:   GE_DATA.nonce,
            user_id: userId
        }).then(function (res) {
            if (res && res.success) {
                Swal.fire({
                    icon: 'success',
                    title: 'Usuario eliminado',
                    text: 'El usuario fue eliminado correctamente.',
                    confirmButtonText: 'Aceptar',
                    confirmButtonColor: geColor('--ge-accent', '#944DE9'),
                });
                loadSubscribers(false);
            } else {
                geShowError('Error al eliminar', (res && res.data && res.data.message) || 'Ocurri\u00f3 un error al eliminar el usuario.');
            }
        }, function () {
            geShowError('Error de conexi\u00f3n', 'No se pudo completar la eliminaci\u00f3n. Intenta de nuevo.');
        });
    }

    /* ══════════════════════════════════
       VER WP_USERMETA (Empresas y Usuarios)
       ══════════════════════════════════ */
    var geUsermeta = { userId: null, nombre: '', search: '', page: 1, perPage: 25, total: 0, totalPages: 1 };
    var geUsermetaSearchTimer = null;
    var geUsermetaCurrentItems = [];

    function openUsermetaModal(userId, nombre) {
        geUsermeta = { userId: userId, nombre: nombre || '', search: '', page: 1, perPage: 25, total: 0, totalPages: 1 };
        $('#ge-usermeta-subtitle').text(nombre ? ('Registros de ' + nombre) : 'Registros de metadatos del usuario');
        $('#ge-usermeta-search').val('');
        $('#ge-usermeta-per-page').val('25');
        showUsermetaListView();
        showModal('#ge-modal-usermeta-overlay');
        loadUsermetaList();
    }

    function closeUsermetaModal() { hideModal('#ge-modal-usermeta-overlay'); }

    function showUsermetaListView() {
        $('#ge-usermeta-list-view').show();
        $('#ge-usermeta-form-view').hide();
        $('#ge-usermeta-footer-list').show();
        $('#ge-usermeta-footer-form').hide();
    }

    function loadUsermetaList() {
        $('#ge-usermeta-tbody').html('<tr class="ge-loading-row"><td colspan="3"><div class="ge-spinner-wrap"><div class="ge-spinner"></div><span>Cargando registros…</span></div></td></tr>');

        $.post(GE_DATA.ajax_url, {
            action:   'ge_list_usermeta',
            nonce:    GE_DATA.nonce,
            user_id:  geUsermeta.userId,
            search:   geUsermeta.search,
            page:     geUsermeta.page,
            per_page: geUsermeta.perPage
        }).then(function (res) {
            if (!res || !res.success) {
                $('#ge-usermeta-tbody').html('<tr><td colspan="3" class="ge-cell-state is-error">' + esc((res && res.data && res.data.message) || 'Error al cargar los registros.') + '</td></tr>');
                return;
            }
            geUsermeta.total = res.data.total;
            geUsermeta.totalPages = res.data.total_pages;
            geUsermetaCurrentItems = res.data.items;
            renderUsermetaTable(res.data.items);

            var startIdx = res.data.total === 0 ? 0 : (geUsermeta.page - 1) * geUsermeta.perPage;
            var endIdx = Math.min(startIdx + res.data.items.length, res.data.total);
            renderPagination(res.data.total, res.data.total_pages, startIdx, endIdx, {
                infoSel: '#ge-usermeta-pagination-info',
                controlsSel: '#ge-usermeta-pagination-controls',
                getPage: function () { return geUsermeta.page; },
                setPage: function (p) { geUsermeta.page = p; },
                rerender: loadUsermetaList
            });
        }, function () {
            $('#ge-usermeta-tbody').html('<tr><td colspan="3" class="ge-cell-state is-error">Error de conexi\u00f3n.</td></tr>');
        });
    }

    function renderUsermetaTable(items) {
        if (!items.length) {
            $('#ge-usermeta-tbody').html('<tr><td colspan="3" class="ge-cell-state">No hay registros que coincidan.</td></tr>');
            return;
        }
        var rows = items.map(function (item) {
            var shortValue = item.meta_value.length > 140 ? item.meta_value.slice(0, 140) + '\u2026' : item.meta_value;
            return '<tr data-meta-id="' + item.meta_id + '">' +
                '<td class="ge-u-strong ge-u-break">' + esc(item.meta_key) + '</td>' +
                '<td class="ge-u-muted ge-u-break">' + esc(shortValue) + '</td>' +
                '<td class="ge-u-center ge-u-nowrap">' +
                    '<button type="button" class="ge-btn-ghost ge-usermeta-edit-btn" data-meta-id="' + item.meta_id + '" title="Editar">' + icon('edit', 13) + '</button> ' +
                    '<button type="button" class="ge-btn-ghost ge-usermeta-delete-btn" data-meta-id="' + item.meta_id + '" title="Eliminar">' + icon('trash', 13) + '</button>' +
                '</td>' +
            '</tr>';
        }).join('');
        $('#ge-usermeta-tbody').html(rows);
    }

    function showUsermetaForm(metaId, metaKey, metaValue) {
        $('#ge-usermeta-form-meta-id').val(metaId || '');
        $('#ge-usermeta-form-key').val(metaKey || '');
        $('#ge-usermeta-form-value').val(metaValue || '');
        $('#ge-usermeta-form-notice').hide().text('');
        $('.ge-modal-title', '#ge-modal-usermeta-overlay').text(metaId ? 'Editar registro' : 'Agregar nuevo registro');
        $('#ge-usermeta-form-save .ge-btn-text').text(metaId ? 'Guardar cambios' : 'Guardar');

        $('#ge-usermeta-list-view').hide();
        $('#ge-usermeta-form-view').show();
        $('#ge-usermeta-footer-list').hide();
        $('#ge-usermeta-footer-form').show();
        setTimeout(function () { $('#ge-usermeta-form-key').focus(); }, 150);
    }

    function backToUsermetaList() {
        $('.ge-modal-title', '#ge-modal-usermeta-overlay').text('WP_USERMETA');
        showUsermetaListView();
    }

    function saveUsermetaForm() {
        var metaId    = $('#ge-usermeta-form-meta-id').val();
        var metaKey   = $('#ge-usermeta-form-key').val().trim();
        var metaValue = $('#ge-usermeta-form-value').val();

        if (!metaKey) {
            $('#ge-usermeta-form-notice').removeClass('success').addClass('error').text('El Meta Key es obligatorio.').show();
            return;
        }

        var $btn = $('#ge-usermeta-form-save');
        $btn.prop('disabled', true).find('.ge-btn-text').hide();
        $btn.find('.ge-btn-spinner').show();

        var action = metaId ? 'ge_edit_usermeta' : 'ge_add_usermeta';
        var payload = {
            action:     action,
            nonce:      GE_DATA.nonce,
            meta_key:   metaKey,
            meta_value: metaValue
        };
        if (metaId) payload.meta_id = metaId;
        else payload.user_id = geUsermeta.userId;

        $.post(GE_DATA.ajax_url, payload).then(function (res) {
            $btn.prop('disabled', false).find('.ge-btn-text').show();
            $btn.find('.ge-btn-spinner').hide();

            if (res && res.success) {
                showToast(res.data.message || 'Guardado correctamente.', 'success');
                backToUsermetaList();
                geUsermeta.page = metaId ? geUsermeta.page : 1; // al crear, volvemos a la primera página para verlo (orden DESC por umeta_id)
                loadUsermetaList();
            } else {
                $('#ge-usermeta-form-notice').removeClass('success').addClass('error').text((res && res.data && res.data.message) || 'Ocurri\u00f3 un error al guardar.').show();
            }
        }, function () {
            $btn.prop('disabled', false).find('.ge-btn-text').show();
            $btn.find('.ge-btn-spinner').hide();
            $('#ge-usermeta-form-notice').removeClass('success').addClass('error').text('Error de conexi\u00f3n. Intenta de nuevo.').show();
        });
    }

    function confirmDeleteUsermetaRow(metaId) {
        Swal.fire({
            icon: 'warning',
            title: '\u00bfEliminar este registro?',
            html: '<p class="ge-u-body">Esta acci\u00f3n eliminar\u00e1 el registro de <code>wp_usermeta</code> de forma permanente y no se puede deshacer.</p>',
            showCancelButton: true,
            confirmButtonText: 'Eliminar',
            cancelButtonText: 'Cancelar',
            confirmButtonColor: geColor('--ge-error', '#B42318'),
            cancelButtonColor: geColor('--ge-text-muted', '#6B6672'),
            focusCancel: true,
            reverseButtons: true,
            customClass: { popup: 'ge-swal-delete-popup' },
        }).then(function (result) {
            if (!result.isConfirmed) return;

            $.post(GE_DATA.ajax_url, {
                action:  'ge_delete_usermeta',
                nonce:   GE_DATA.nonce,
                meta_id: metaId
            }).then(function (res) {
                if (res && res.success) {
                    showToast(res.data.message || 'Registro eliminado.', 'success');
                    loadUsermetaList();
                } else {
                    geShowError('Error al eliminar', (res && res.data && res.data.message) || 'Ocurri\u00f3 un error al eliminar el registro.');
                }
            }, function () {
                geShowError('Error de conexi\u00f3n', 'No se pudo eliminar el registro.');
            });
        });
    }

    /* ══════════════════════════════════
       MODAL CREAR
       ══════════════════════════════════ */
    function openCreateModal() {
        editMode = false;
        $('#ge-modal-title').text('Crear Empresa');
        $('#ge-form')[0].reset();
        $('#ge-edit-user-id').val('');
        $('#ge-email-wrap').show();
        $('#email').prop('disabled', false);
        $('#ge-form-notice').hide().removeClass('success error').text('');
        $('#ge-btn-submit .ge-btn-text').text('Guardar Empresa');
        showModal('#ge-modal-overlay');
        setTimeout(function () { $('#nombre_empresa').focus(); }, 200);
    }

    function closeMainModal() {
        hideModal('#ge-modal-overlay');
    }

    /* ══════════════════════════════════
       MODAL EDITAR
       ══════════════════════════════════ */
    function openEditModal(userId) {
        editMode = true;
        $('#ge-modal-title').text('Editar Empresa');
        $('#ge-form')[0].reset();
        $('#ge-form-notice').hide().removeClass('success error').text('');
        $('#ge-btn-submit .ge-btn-text').text('Actualizar datos');
        $('#ge-email-wrap').hide();
        $('#email').prop('disabled', true);

        $.post(GE_DATA.ajax_url, { action: 'ge_get_user', nonce: GE_DATA.nonce, user_id: userId },
            function (res) {
                if (res.success) {
                    var d = res.data;
                    $('#ge-edit-user-id').val(d.id);
                    $('#nombre_empresa').val(d.nombre_empresa);
                    $('#nombre_encargado').val(d.nombre_encargado);
                    $('#last_name').val(d.last_name);
                    $('#phone_number').val(d.phone_number);
                    $('#ocupacion').val(d.ocupacion);
                } else {
                    showNotice('#ge-form-notice', 'error', 'No se pudieron cargar los datos.');
                }
            }
        );

        showModal('#ge-modal-overlay');
    }

    /* ══════════════════════════════════
       ENVÍO FORMULARIO
       ══════════════════════════════════ */
    function handleFormSubmit(e) {
        e.preventDefault();
        if (!validateForm()) return;

        var $btn  = $('#ge-btn-submit');
        $btn.find('.ge-btn-text').hide();
        $btn.find('.ge-btn-spinner').show();
        $btn.prop('disabled', true);
        $('#ge-form-notice').hide();

        var formData = { action: editMode ? 'ge_edit_user' : 'ge_create_user', nonce: GE_DATA.nonce };
        $('#ge-form').serializeArray().forEach(function (f) { formData[f.name] = f.value; });

        $.post(GE_DATA.ajax_url, formData, function (res) {
            $btn.find('.ge-btn-text').show();
            $btn.find('.ge-btn-spinner').hide();
            $btn.prop('disabled', false);

            if (!editMode) {
                // ── CREAR EMPRESA ──────────────────────────────────────
                var createdEmail   = formData['email']         || '';
                var createdEmpresa = formData['nombre_empresa'] || '';

                if (res.success) {
                    closeMainModal();
                    loadUsers();
                    var sync = res.data.sync || {};
                    if (sync.api_called && sync.webhook_called) {
                        Swal.fire({
                            icon: 'success',
                            title: '¡Usuario registrado!',
                            html: 'El usuario con el correo <strong>' + createdEmail + '</strong> ha sido registrado correctamente y se le ha enviado un correo con su usuario y contraseña.',
                            confirmButtonText: 'Aceptar',
                            confirmButtonColor: geColor('--ge-accent', '#944DE9'),
                        });
                    } else {
                        Swal.fire({
                            icon: 'warning',
                            title: 'Empresa creada, con advertencia',
                            html: 'El usuario con el correo <strong>' + createdEmail + '</strong> se creó correctamente en el sitio, pero hubo un problema al sincronizarlo con WMS/Inspira. Revisa el registro de errores del servidor.',
                            confirmButtonText: 'Aceptar',
                            confirmButtonColor: geColor('--ge-accent', '#944DE9'),
                        });
                    }
                    // Placeholder: ejecutar lógica adicional tras crear empresa
                    ge_on_empresa_creada(createdEmail, createdEmpresa);
                } else {
                    closeMainModal();
                    geShowError('Error al crear empresa', res.data.message || 'Ocurrió un error al crear la empresa.');
                }
            } else {
                // ── EDITAR EMPRESA ─────────────────────────────────────
                if (res.success) {
                    closeMainModal();
                    showToast(res.data.message, 'success');
                    loadUsers(false);
                } else {
                    showNotice('#ge-form-notice', 'error', res.data.message || 'Ocurrió un error.');
                }
            }
        }).fail(function () {
            $btn.find('.ge-btn-text').show();
            $btn.find('.ge-btn-spinner').hide();
            $btn.prop('disabled', false);
            if (!editMode) {
                closeMainModal();
                geShowError('Error de conexión', 'No se pudo conectar con el servidor. Intenta de nuevo.');
            } else {
                showNotice('#ge-form-notice', 'error', 'Error de conexión.');
            }
        });
    }

    function validateForm() {
        var valid = true;
        $('#ge-form input:not([disabled]):visible').each(function () {
            $(this).removeClass('ge-input-error');
            if ($(this).prop('required') && !$(this).val().trim()) {
                $(this).addClass('ge-input-error');
                valid = false;
            }
        });
        if (!valid) showNotice('#ge-form-notice', 'error', 'Completa todos los campos obligatorios.');
        return valid;
    }

    /* ══════════════════════════════════
       MODAL CONTRASEÑA
       ══════════════════════════════════ */
    function openPassModal(userId) {
        $('#ge-pass-user-id').val(userId);
        $('#ge-new-pass').val('');
        $('#ge-pass-notice').hide().removeClass('success error').text('');
        showModal('#ge-modal-pass-overlay');
        setTimeout(function () { $('#ge-new-pass').focus(); }, 200);
    }

    function closePassModal() {
        hideModal('#ge-modal-pass-overlay');
    }

    function handlePassSubmit(e) {
        e.preventDefault();
        var userId  = $('#ge-pass-user-id').val();
        // Recuperar email y nombre de empresa desde la fila de la tabla
        var $row         = $('#ge-tbody tr[data-id="' + userId + '"]');
        var passEmail    = $row.find('.ge-identity-email').text().trim();
        var passEmpresa  = $row.find('.ge-identity-name').text().trim();
        var newPass = $('#ge-new-pass').val().trim();

        if (!newPass || newPass.length < 8) {
            showNotice('#ge-pass-notice', 'error', 'La contraseña debe tener al menos 8 caracteres.');
            return;
        }

        var $btn = $('#ge-pass-submit');
        $btn.find('.ge-btn-text').hide();
        $btn.find('.ge-btn-spinner').show();
        $btn.prop('disabled', true);

        $.post(GE_DATA.ajax_url, {
            action: 'ge_change_password', nonce: GE_DATA.nonce,
            user_id: userId, new_password: newPass
        }, function (res) {
            $btn.find('.ge-btn-text').show();
            $btn.find('.ge-btn-spinner').hide();
            $btn.prop('disabled', false);
            if (res.success) {
                closePassModal();
                showToast(res.data.message, 'success');
                // Placeholder: ejecutar lógica adicional tras actualizar contraseña
                ge_on_password_actualizada(passEmail, passEmpresa, newPass);
            }
            else showNotice('#ge-pass-notice', 'error', res.data.message || 'Error al actualizar.');
        }).fail(function () {
            $btn.find('.ge-btn-text').show();
            $btn.find('.ge-btn-spinner').hide();
            $btn.prop('disabled', false);
            showNotice('#ge-pass-notice', 'error', 'Error de conexión.');
        });
    }

    function generatePassword() {
        var chars = 'abcdefghjkmnpqrstuvwxyzABCDEFGHJKMNPQRSTUVWXYZ23456789!@#';
        var pass  = '';
        for (var i = 0; i < 10; i++) pass += chars.charAt(Math.floor(Math.random() * chars.length));
        $('#ge-new-pass').val(pass).focus();
    }

    /* ══════════════════════════════════
       MODAL CAMBIAR CORREO (tab Usuarios)
       ══════════════════════════════════ */
    var geEmailModalSource = 'usuarios';

    function openEmailModal(userId, correoActual, source) {
        geEmailModalSource = source || 'usuarios';
        $('#ge-email-user-id').val(userId);
        $('#ge-email-actual').val(correoActual || '');
        $('#ge-email-nuevo').val('');
        $('#ge-email-notice').hide().removeClass('success error').text('');
        showModal('#ge-modal-email-overlay');
        setTimeout(function () { $('#ge-email-nuevo').focus(); }, 200);
    }

    function closeEmailModal() {
        hideModal('#ge-modal-email-overlay');
    }

    function handleEmailSubmit(e) {
        e.preventDefault();
        var userId       = $('#ge-email-user-id').val();
        var correoActual = $('#ge-email-actual').val().trim();
        var correoNuevo  = $('#ge-email-nuevo').val().trim().toLowerCase();

        if (!correoNuevo || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(correoNuevo)) {
            showNotice('#ge-email-notice', 'error', 'Escribe un correo electrónico válido.');
            return;
        }
        if (correoNuevo === correoActual.toLowerCase()) {
            showNotice('#ge-email-notice', 'error', 'El nuevo correo es igual al actual.');
            return;
        }

        var $btn = $('#ge-email-submit');
        $btn.find('.ge-btn-text').hide();
        $btn.find('.ge-btn-spinner').show();
        $btn.prop('disabled', true);

        $.post(GE_DATA.ajax_url, {
            action: 'ge_change_subscriber_email', nonce: GE_DATA.nonce,
            user_id: userId, nuevo_correo: correoNuevo
        }, function (res) {
            $btn.find('.ge-btn-text').show();
            $btn.find('.ge-btn-spinner').hide();
            $btn.prop('disabled', false);
            if (res.success) {
                closeEmailModal();
                showToast(res.data.message, 'success');
                if (geEmailModalSource === 'empresas') loadUsers(false);
                else loadSubscribers(false);
            }
            else showNotice('#ge-email-notice', 'error', res.data.message || 'Error al actualizar el correo.');
        }).fail(function () {
            $btn.find('.ge-btn-text').show();
            $btn.find('.ge-btn-spinner').hide();
            $btn.prop('disabled', false);
            showNotice('#ge-email-notice', 'error', 'Error de conexión.');
        });
    }

    /* ══════════════════════════════════
       SWITCH USER
       ══════════════════════════════════ */
    function switchToUser(userId) {
        if (!confirm('¿Seguro que deseas entrar como este usuario? Podrás volver a tu cuenta con el botón «Volver al administrador».')) return;
        $.post(GE_DATA.ajax_url, {
            action: 'ge_switch_user', nonce: GE_DATA.nonce, user_id: userId,
            return_state: JSON.stringify(getReturnState())
        },
            function (res) {
                if (res.success && res.data.redirect) {
                    showToast('Redirigiendo…', 'success');
                    setTimeout(function () { window.location.href = res.data.redirect; }, 800);
                } else {
                    showToast(res.data.message || 'Error al cambiar de usuario.', 'error');
                }
            }
        ).fail(function () { showToast('Error de conexión.', 'error'); });
    }

    /* ══════════════════════════════════
       HELPERS UI
       ══════════════════════════════════ */
    function showModal(sel) {
        // Usar display:flex directamente — sin fadeIn para evitar que jQuery ponga display:block
        $(sel).css({ display: 'flex' });
        $('body').css('overflow', 'hidden');
    }

    function hideModal(sel) {
        var $overlay = $(sel);
        var $modal = $overlay.find('.ge-modal').first();
        if (!$modal.length) {
            $overlay.css({ display: 'none' });
            $('body').css('overflow', '');
            return;
        }
        $modal.addClass('ge-modal-closing');
        setTimeout(function () {
            $overlay.css({ display: 'none' });
            $modal.removeClass('ge-modal-closing');
            $('body').css('overflow', '');
        }, 160);
    }

    function closeAllDropdowns() {
        $('.ge-dropdown').removeClass('open is-up');
        $('.ge-btn-actions').attr('aria-expanded', 'false');
        cerrarSubmenus();
        openDropdown = null;
    }

    function cerrarSubmenus($dentroDe) {
        var $subs = $dentroDe ? $dentroDe.find('.ge-dropdown-sub') : $('.ge-dropdown-sub');
        $subs.removeClass('is-open')
            .children('.ge-dropdown-sub-toggle').attr('aria-expanded', 'false');
    }

    function showNotice(sel, type, msg) {
        $(sel).removeClass('success error').addClass(type).html(msg).show();
    }

    /**
     * Muestra un SweetAlert2 de error con el estilo estándar del plugin.
     * Centraliza el patrón repetido de icon/confirmButtonText/confirmButtonColor
     * que antes se copiaba manualmente en cada llamada AJAX.
     */
    function geShowError(title, text) {
        Swal.fire({
            icon: 'error',
            title: title || 'Error',
            text: text || 'Ocurrió un error inesperado.',
            confirmButtonText: 'Aceptar',
            confirmButtonColor: geColor('--ge-accent', '#944DE9'),
        });
    }

    function showToast(message, type) {
        var icon = type === 'success'
            ? '<svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="20 6 9 17 4 12"/></svg>'
            : '<svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>';
        var $t = $('<div class="ge-toast ' + type + '">' + icon + esc(message) + '</div>');
        $('body').append($t);
        setTimeout(function () { $t.fadeOut(300, function () { $t.remove(); }); }, 3500);
    }

    function esc(str) {
        return String(str || '')
            .replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
    }

    /**
     * Lee un color de marca del :root del CSS. SweetAlert pide el color como
     * valor (no admite una clase), y antes cada llamada repetía el literal
     * hexadecimal, que ya se había desincronizado del CSS en varios sitios.
     */
    var geRootStyles = null;
    function geColor(token, fallback) {
        try {
            if (!geRootStyles) geRootStyles = getComputedStyle(document.documentElement);
            return (geRootStyles.getPropertyValue(token) || '').trim() || fallback;
        } catch (e) {
            return fallback;
        }
    }


    /* ══════════════════════════════════
       ELIMINAR EMPRESA (cascada)
       ══════════════════════════════════ */
    function confirmDeleteEmpresa(empresaId, nombreEmpresa) {
        // 1) Refrescar programas del administrador y de todos los usuarios de cada área, sin pedir confirmación
        Swal.fire({
            title: 'Refrescando programas de la empresa\u2026',
            allowOutsideClick: false,
            allowEscapeKey: false,
            showConfirmButton: false,
            didOpen: function () { Swal.showLoading(); }
        });

        $.post(GE_DATA.ajax_url, {
            action:     'ge_get_empresa_members',
            nonce:      GE_DATA.nonce,
            empresa_id: empresaId
        }).then(function (res) {
            var members = (res && res.success) ? (res.data.members || []) : [];
            return silentSyncMembers(members);
        }, function () {
            return $.Deferred().resolve().promise();
        }).always(function () {
            // 2) Traer datos completos (admin + áreas + usuarios) para la vista previa
            $.post(GE_DATA.ajax_url, {
                action:     'ge_get_empresa_delete_preview',
                nonce:      GE_DATA.nonce,
                empresa_id: empresaId
            }).then(function (res) {
                if (!res || !res.success) {
                    geShowError('Error', (res && res.data && res.data.message) || 'No se pudo cargar la vista previa.');
                    return;
                }
                showDeleteEmpresaPreview(empresaId, res.data.admin, res.data.areas || []);
            }, function () {
                geShowError('Error de conexi\u00f3n');
            });
        });
    }

    // Sincroniza programas en lotes SIN mostrar barra de progreso ni resumen final (uso interno, silencioso)
    function silentSyncMembers(members) {
        var deferred = $.Deferred();
        if (!members.length) { deferred.resolve(); return deferred.promise(); }

        var idx = 0;
        function next() {
            if (idx >= members.length) { deferred.resolve(); return; }
            var batch = members.slice(idx, idx + GE_SYNC_BATCH_SIZE);
            idx += GE_SYNC_BATCH_SIZE;
            $.when.apply($, batch.map(function (m) {
                return $.post(GE_DATA.ajax_url, { action: 'ge_sync_program_user', nonce: GE_DATA.nonce, user_id: m.user_id });
            })).always(next);
        }
        next();
        return deferred.promise();
    }

    function programBadgesHtmlForDelete(wms, octagono) {
        if (wms && octagono) return '<span class="ge-mini-badge ge-mini-wms">WMS</span> <span class="ge-mini-badge ge-mini-oct">Oct\u00e1gono</span>';
        if (wms) return '<span class="ge-mini-badge ge-mini-wms">WMS</span>';
        if (octagono) return '<span class="ge-mini-badge ge-mini-oct">Oct\u00e1gono</span>';
        return '<span class="ge-mini-badge ge-mini-none">Ninguno</span>';
    }

    function deleteUserRowHtml(u) {
        return '<tr>' +
            '<td><div class="ge-del-user-cell">' +
                '<span class="ge-del-user-id">#' + u.id + '</span>' +
                '<span class="ge-del-user-name">' + esc(u.nombre) + '</span>' +
                '<span class="ge-del-user-email">' + esc(u.correo) + '</span>' +
                '<span class="ge-del-user-role">' + esc(u.rol) + '</span>' +
            '</div></td>' +
            '<td>' + programBadgesHtmlForDelete(u.wms, u.octagono) + '</td>' +
        '</tr>';
    }

    function showDeleteEmpresaPreview(empresaId, admin, areas) {
        var html = '<div class="ge-del-preview-scroll">';

        html += '<h4 class="ge-del-section-title">Administrador de la empresa</h4>';
        html += '<table class="ge-del-preview-table"><thead><tr><th>Usuario</th><th>Programas</th></tr></thead><tbody>' + deleteUserRowHtml(admin) + '</tbody></table>';

        areas.forEach(function (area) {
            html += '<h4 class="ge-del-section-title">' + esc(area.nombre) + '</h4>';
            if (area.usuarios && area.usuarios.length) {
                html += '<table class="ge-del-preview-table"><thead><tr><th>Usuario</th><th>Programas</th></tr></thead><tbody>' +
                    area.usuarios.map(deleteUserRowHtml).join('') + '</tbody></table>';
            } else {
                html += '<p class="ge-import-empty-msg">Esta \u00e1rea no tiene usuarios.</p>';
            }
        });

        html += '</div>' +
            '<p class="ge-del-warning">\u00bfDeseas eliminar esta empresa? Esta acci\u00f3n eliminar\u00e1 tambi\u00e9n el administrador asignado, las \u00e1reas relacionadas, los usuarios vinculados a esas \u00e1reas y todo su progreso asociado.</p>';

        Swal.fire({
            title: 'Revisar antes de eliminar',
            html: html,
            width: 640,
            showCancelButton: true,
            confirmButtonText: 'S\u00ed, eliminar',
            cancelButtonText: 'Cancelar',
            confirmButtonColor: geColor('--ge-error', '#B42318'),
            cancelButtonColor: geColor('--ge-text-muted', '#6B6672'),
            focusCancel: true,
            reverseButtons: true,
            customClass: { popup: 'ge-swal-delete-popup ge-swal-delete-preview' },
        }).then(function (result) {
            if (!result.isConfirmed) return;
            executeDeleteEmpresa(empresaId);
        });
    }

    function executeDeleteEmpresa(empresaId) {
        Swal.fire({
            title: 'Eliminando empresa\u2026',
            html: '<div class="ge-u-stack">' +
                  '<div class="ge-spinner ge-spinner-lg"></div>' +
                  '<p class="ge-u-note">Esto puede tomar unos segundos.</p>' +
                  '</div>',
            allowOutsideClick: false,
            allowEscapeKey: false,
            showConfirmButton: false,
            didOpen: function () { Swal.showLoading(); }
        });

        $.post(GE_DATA.ajax_url, {
            action:     'ge_delete_empresa',
            nonce:      GE_DATA.nonce,
            empresa_id: empresaId
        }, function (res) {
            if (res.success) {
                var $row = $('#ge-tbody tr[data-id="' + empresaId + '"]');
                $row.css({ transition: 'opacity .3s', opacity: 0 });
                setTimeout(function () {
                    geAllUsers = geAllUsers.filter(function (u) { return String(u.id) !== String(empresaId); });
                    renderTable();
                }, 310);

                Swal.fire({
                    icon: 'success',
                    title: 'Empresa eliminada',
                    text: res.data.message || 'La empresa fue eliminada correctamente.',
                    confirmButtonText: 'Aceptar',
                    confirmButtonColor: geColor('--ge-accent', '#944DE9'),
                });
            } else {
                geShowError('Error al eliminar', (res.data && res.data.message) || 'Ocurri\u00f3 un error al eliminar la empresa.');
            }
        }).fail(function () {
            geShowError('Error de conexi\u00f3n', 'No se pudo conectar con el servidor.');
        });
    }

    /* ══════════════════════════════════
       REFRESCAR PROGRAMAS (Octágono + WMS)
       ══════════════════════════════════ */
    var GE_SYNC_BATCH_SIZE = 5;

    function confirmRefreshProgramas(empresaId, nombreEmpresa) {
        Swal.fire({
            icon: 'question',
            title: '\u00bfRefrescar programas?',
            html: '<p class="ge-u-body">' +
                  'Esta acci\u00f3n refrescar\u00e1 el tipo de programa al que est\u00e1 vinculada esta empresa ' +
                  '(WMS - Programas de Liderazgo y Oct\u00e1gono), incluyendo la empresa y todos sus integrantes. ' +
                  '\u00bfDesea continuar?' +
                  '</p>',
            showCancelButton: true,
            confirmButtonText: 'S\u00ed, refrescar',
            cancelButtonText: 'Cancelar',
            confirmButtonColor: geColor('--ge-accent', '#944DE9'),
            cancelButtonColor: geColor('--ge-text-muted', '#6B6672'),
            reverseButtons: true,
        }).then(function (result) {
            if (!result.isConfirmed) return;
            runRefreshProgramas(empresaId);
        });
    }

    function runRefreshProgramas(empresaId) {
        Swal.fire({
            title: 'Obteniendo integrantes\u2026',
            html: '<div class="ge-u-stack">' +
                  '<div class="ge-spinner ge-spinner-lg"></div>' +
                  '</div>',
            allowOutsideClick: false,
            allowEscapeKey: false,
            showConfirmButton: false,
            didOpen: function () { Swal.showLoading(); }
        });

        $.post(GE_DATA.ajax_url, {
            action:     'ge_get_empresa_members',
            nonce:      GE_DATA.nonce,
            empresa_id: empresaId
        }, function (res) {
            if (!res.success) {
                geShowError('Error', (res.data && res.data.message) || 'No se pudo obtener el listado de integrantes.');
                return;
            }
            var members = res.data.members || [];
            if (!members.length) {
                Swal.fire({ icon: 'info', title: 'Sin integrantes', text: 'No se encontraron usuarios para sincronizar.', confirmButtonText: 'Aceptar', confirmButtonColor: geColor('--ge-accent', '#944DE9') });
                return;
            }
            processSyncQueue(members);
        }).fail(function () {
            geShowError('Error de conexi\u00f3n', 'No se pudo conectar con el servidor.');
        });
    }

    function renderProgressHtml(done, total) {
        var pct = total ? Math.round((done / total) * 100) : 0;
        return '<div>' +
               '<div class="ge-progress"><div class="ge-progress-fill" style="width:' + pct + '%;"></div></div>' +
               '<p class="ge-u-note">' + pct + '% \u2014 Procesando usuario ' +
                 Math.min(done + 1, total) + ' de ' + total + '\u2026</p>' +
               '</div>';
    }

    function processSyncQueue(members, onDone) {
        var total = members.length;
        var done  = 0;

        var stats = {
            octagono_created: 0, octagono_updated: 0, octagono_removed: 0,
            wms_created: 0, wms_updated: 0, wms_removed: 0,
            errors: 0
        };

        Swal.fire({
            title: 'Refrescando programas\u2026',
            html: renderProgressHtml(0, total),
            allowOutsideClick: false,
            allowEscapeKey: false,
            showConfirmButton: false,
        });

        function tallyResult(r) {
            if (!r) { stats.errors++; return; }
            if (r.octagono === 'created') stats.octagono_created++;
            else if (r.octagono === 'updated') stats.octagono_updated++;
            else if (r.octagono === 'removed') stats.octagono_removed++;
            else if (r.octagono === 'error') stats.errors++;

            if (r.wms === 'created') stats.wms_created++;
            else if (r.wms === 'updated') stats.wms_updated++;
            else if (r.wms === 'removed') stats.wms_removed++;
            else if (r.wms === 'error') stats.errors++;
        }

        function syncOne(member) {
            return $.post(GE_DATA.ajax_url, {
                action:  'ge_sync_program_user',
                nonce:   GE_DATA.nonce,
                user_id: member.user_id
            }).then(function (res) {
                tallyResult(res && res.success ? res.data : null);
                done++;
                Swal.update({ html: renderProgressHtml(done, total) });
            }, function () {
                stats.errors++;
                done++;
                Swal.update({ html: renderProgressHtml(done, total) });
            });
        }

        function processBatch(startIdx) {
            if (startIdx >= total) {
                Swal.fire({
                    icon: 'success',
                    title: 'Sincronizaci\u00f3n completada',
                    html: '<div class="ge-u-list">' +
                          '<p style="margin:0 0 8px;"><strong>Total de usuarios encontrados:</strong> ' + total + '</p>' +
                          '<p style="margin:0 0 8px;"><strong>Usuarios procesados:</strong> ' + done + '</p>' +
                          '<p style="margin:0;">Meta "octagono" creados/actualizados: ' + (stats.octagono_created + stats.octagono_updated) + '</p>' +
                          '<p style="margin:0 0 8px;">Meta "octagono" eliminados: ' + stats.octagono_removed + '</p>' +
                          '<p style="margin:0;">Meta "wms" creados/actualizados: ' + (stats.wms_created + stats.wms_updated) + '</p>' +
                          '<p style="margin:0 0 8px;">Meta "wms" eliminados: ' + stats.wms_removed + '</p>' +
                          '<p style="margin:0;">Errores encontrados: ' + stats.errors + '</p>' +
                          '</div>',
                    confirmButtonText: 'Aceptar',
                    confirmButtonColor: geColor('--ge-accent', '#944DE9'),
                }).then(function () {
                    if (typeof onDone === 'function') onDone();
                    else loadUsers(false);
                });
                return;
            }

            var batch = members.slice(startIdx, startIdx + GE_SYNC_BATCH_SIZE);
            $.when.apply($, batch.map(syncOne)).always(function () {
                processBatch(startIdx + GE_SYNC_BATCH_SIZE);
            });
        }

        processBatch(0);
    }

    /* ══════════════════════════════════
       PLACEHOLDERS — Lógica adicional
       ══════════════════════════════════ */

    /**
     * Se ejecuta después de crear una empresa exitosamente.
     *
     * @param {string} email         - Correo electrónico del encargado registrado.
     * @param {string} nombreEmpresa - Nombre del grupo / empresa creada.
     */
    function ge_on_empresa_creada(email, nombreEmpresa) {
        // TODO: implementar lógica adicional tras la creación de la empresa.
    }

    /**
     * Se ejecuta después de actualizar la contraseña de un usuario exitosamente.
     *
     * @param {string} email         - Correo electrónico del usuario cuya contraseña fue actualizada.
     * @param {string} nombreEmpresa - Nombre del grupo / empresa del usuario.
     * @param {string} nuevaContrasena - Nueva contraseña establecida para el usuario.
     */
    function ge_on_password_actualizada(email, nombreEmpresa, nuevaContrasena) {
        // TODO: implementar lógica adicional tras la actualización de contraseña.
    }

    /* ══════════════════════════════════
       MODAL LISTADO DE AREAS
       ══════════════════════════════════ */
    // \u00c1reas de la empresa abierta en el modal. Se guardan para poder filtrar
    // por nombre sin volver a consultar el servidor: el n\u00famero de \u00e1reas por
    // empresa es peque\u00f1o y el buscador debe responder al instante.
    var geAreasCargadas = [];

    // Empresa cuyo listado est\u00e1 abierto. Permite recargarlo tras crear \u00e1reas
    // sin tener que volver a abrir el modal.
    var geAreasCtx = { grupoId: 0, empresa: '' };

    function openAreasListModal(grupoId, empresa) {
        geAreasCtx = { grupoId: grupoId, empresa: empresa };

        $('#ge-areas-list-title').text('\u00c1reas \u2014 ' + empresa);
        $('#ge-areas-list-desc').text('Listado de \u00e1reas creadas para esta empresa');

        showModal('#ge-modal-areas-overlay');
        cargarAreasList();
    }

    function cargarAreasList() {
        $('#ge-areas-list-body').html('<div class="ge-spinner-wrap"><div class="ge-spinner"></div><span>Cargando \u00e1reas\u2026</span></div>');

        geAreasCargadas = [];
        // Se limpia la b\u00fasqueda: tras crear un \u00e1rea, el filtro anterior podr\u00eda
        // esconder justo lo que se acaba de crear.
        $('#ge-areas-search').val('');
        $('#ge-areas-toolbar').hide();

        $.post(GE_DATA.ajax_url, { action: 'ge_list_areas', nonce: GE_DATA.nonce, grupo_id: geAreasCtx.grupoId },
            function (res) {
                if (!res.success) {
                    $('#ge-areas-list-body').html('<p class="ge-areas-empty">Error al cargar las \u00e1reas.</p>');
                    return;
                }

                geAreasCargadas = res.data.areas || [];

                if (!geAreasCargadas.length) {
                    $('#ge-areas-list-body').html('<p class="ge-areas-empty">Esta empresa no tiene \u00e1reas creadas.</p>');
                    return;
                }

                // El buscador solo aparece si hay algo que buscar.
                $('#ge-areas-toolbar').css('display', 'flex');
                renderAreasList();
            }
        ).fail(function () {
            $('#ge-areas-list-body').html('<p class="ge-areas-empty">Error de conexi\u00f3n.</p>');
        });
    }

    function renderAreasList() {
        var query = String($('#ge-areas-search').val() || '').trim().toLowerCase();
        var areas = query
            ? geAreasCargadas.filter(function (a) {
                return String(a.nombre || '').toLowerCase().indexOf(query) !== -1;
            })
            : geAreasCargadas;

        $('#ge-areas-count').text(
            areas.length === geAreasCargadas.length
                ? geAreasCargadas.length + (geAreasCargadas.length === 1 ? ' \u00e1rea' : ' \u00e1reas')
                : areas.length + ' de ' + geAreasCargadas.length
        );

        if (!areas.length) {
            $('#ge-areas-list-body').html('<p class="ge-areas-empty">Ninguna \u00e1rea coincide con la b\u00fasqueda.</p>');
            return;
        }

        var html = '<table class="ge-areas-table">'
            + '<thead><tr>'
            + '<th>\u00c1rea</th>'
            + '<th style="text-align:center;">Cupos / Miembros</th>'
            + '<th style="text-align:center;">Estado</th>'
            + '<th style="text-align:center;">Acciones</th>'
            + '</tr></thead><tbody>';

        for (var j = 0; j < areas.length; j++) {
            var a = areas[j];
            var miembros    = parseInt(a.miembros, 10) || 0;
            var cupoText    = a.cupo + ' / ' + miembros;
            var estadoClass = a.estado === 'Activo' ? 'ge-badge-activo' : 'ge-badge-inactivo';
            var expira      = formatFechaCorta(a.fecha_expiracion);

            html += '<tr>'
                + '<td><div class="ge-area-info">'
                +   '<span class="ge-area-id">#' + a.id + '</span>'
                +   '<span class="ge-area-nombre">' + esc(a.nombre) + '</span>'
                +   '<span class="ge-area-expira">' + (expira ? 'Vence el ' + esc(expira) : 'Sin fecha de vencimiento') + '</span>'
                + '</div></td>'
                + '<td style="text-align:center;"><span class="ge-cupos-badge">' + cupoText + '</span></td>'
                + '<td style="text-align:center;"><span class="ge-badge ' + estadoClass + '">' + esc(a.estado) + '</span></td>'
                + '<td style="text-align:center;position:relative;">'
                +   '<div class="ge-actions-wrap">'
                +   '<button type="button" class="ge-area-act-btn ge-btn-actions" data-area-id="' + a.id + '"'
                +     ' aria-haspopup="true" aria-expanded="false">Acciones' + icon('caret', 13) + '</button>'
                +   '<div class="ge-area-dropdown ge-dropdown" id="ge-area-dd-' + a.id + '">'
                +   '<button class="ge-dropdown-item ge-area-act-edit"'
                +   ' data-id="' + a.id + '"'
                +   ' data-nombre="' + esc(a.nombre) + '"'
                +   ' data-cupo="' + a.cupo + '"'
                +   ' data-fecha="' + esc(a.fecha_expiracion || '') + '">'
                +   icon('edit', 14) + ' Editar \u00e1rea</button>'
                +   '</div></div>'
                + '</td>'
                + '</tr>';
        }

        $('#ge-areas-list-body').html(html + '</tbody></table>');
    }

    /**
     * Fecha `YYYY-MM-DD` a "18 sep 2026".
     *
     * Se parsea a mano en vez de con `new Date(texto)`: ese constructor trata
     * una fecha sin hora como UTC, as\u00ed que en Colombia (UTC-5) devolver\u00eda el
     * d\u00eda anterior. Aqu\u00ed no hay huso que valga, la fecha es literal.
     */
    var GE_MESES_CORTOS = [ 'ene', 'feb', 'mar', 'abr', 'may', 'jun', 'jul', 'ago', 'sep', 'oct', 'nov', 'dic' ];

    function formatFechaCorta(raw) {
        var texto = String(raw || '').trim();

        if (!texto || texto.indexOf('0000-00-00') === 0) {
            return '';
        }

        var partes = texto.match(/^(\d{4})-(\d{2})-(\d{2})/);
        if (!partes) {
            return texto;
        }

        var mes = GE_MESES_CORTOS[ parseInt(partes[2], 10) - 1 ];

        return mes ? parseInt(partes[3], 10) + ' ' + mes + ' ' + partes[1] : texto;
    }

    function closeAreasListModal() { hideModal('#ge-modal-areas-overlay'); }

    /* ══════════════════════════════════
       MODAL CURSOS DE UN USUARIO
       ══════════════════════════════════ */
    function openCursosModal(userId, nombre) {
        $('#ge-cursos-title').text('Cursos — ' + nombre);
        $('#ge-cursos-desc').text('Cursos de LearnDash y avance de cada uno');
        $('#ge-cursos-body').html('<div class="ge-spinner-wrap"><div class="ge-spinner"></div><span>Cargando cursos…</span></div>');

        showModal('#ge-modal-cursos-overlay');

        $.post(GE_DATA.ajax_url, { action: 'ge_get_cursos_usuario', nonce: GE_DATA.nonce, user_id: userId })
            .done(function (res) {
                if (!res || !res.success) {
                    $('#ge-cursos-body').html('<p class="ge-cell-state is-error">'
                        + esc((res && res.data && res.data.message) || 'No se pudieron cargar los cursos.') + '</p>');
                    return;
                }

                pintarCursos(res.data);

                // El conteo de la fila sale de la inscripción directa; el
                // detalle puede incluir además cursos heredados de un grupo de
                // LearnDash. Si el número real difiere, se corrige la fila.
                sincronizarContadorCursos(userId, res.data.total);
            })
            .fail(function () {
                $('#ge-cursos-body').html('<p class="ge-cell-state is-error">Error de conexión.</p>');
            });
    }

    function closeCursosModal() { hideModal('#ge-modal-cursos-overlay'); }

    function pintarCursos(data) {
        var cursos = data.cursos || [];

        if (!cursos.length) {
            $('#ge-cursos-body').html('<p class="ge-cell-state">Este usuario no tiene cursos asignados.</p>');
            return;
        }

        var resumen = '<div class="ge-cursos-resumen">'
            + '<span><b>' + cursos.length + '</b> ' + (1 === cursos.length ? 'curso' : 'cursos') + '</span>'
            + '<span><b>' + data.completos + '</b> completado' + (1 === data.completos ? '' : 's') + '</span>'
            + '<span><b>' + data.promedio + '%</b> de avance promedio</span>'
            + '</div>';

        var filas = cursos.map(function (curso) {
            var pct = Math.max(0, Math.min(100, parseFloat(curso.pct) || 0));

            return '<tr>'
                + '<td><span class="ge-curso-nombre">' + esc(curso.titulo) + '</span>'
                +   '<span class="ge-curso-id">#' + esc(curso.id) + '</span></td>'
                + '<td class="ge-curso-avance-celda">'
                +   '<div class="ge-curso-avance">'
                +     '<div class="ge-progress"><div class="ge-progress-fill ' + claseAvance(pct) + '" style="width:' + pct + '%;"></div></div>'
                +     '<span class="ge-curso-pct">' + formatPct(pct) + '</span>'
                +   '</div>'
                + '</td>'
                + '</tr>';
        }).join('');

        $('#ge-cursos-body').html(resumen
            + '<div class="ge-cursos-scroll"><table class="ge-areas-table ge-areas-table-compacta">'
            + '<thead><tr><th>Curso</th><th style="width:220px;">Avance</th></tr></thead>'
            + '<tbody>' + filas + '</tbody></table></div>');
    }

    function claseAvance(pct) {
        if (pct >= 100) return 'is-completo';
        if (pct > 0)    return 'is-parcial';
        return 'is-cero';
    }

    /** Sin decimales cuando el avance es un número redondo. */
    function formatPct(pct) {
        return (Math.round(pct) === pct ? pct : pct.toFixed(1).replace('.', ',')) + '%';
    }

    function sincronizarContadorCursos(userId, total) {
        var usuario = geAllSubscribers.filter(function (u) { return String(u.id) === String(userId); })[0];

        if (!usuario || parseInt(usuario.cursos, 10) === parseInt(total, 10)) {
            return;
        }

        usuario.cursos = total;
        renderSubscribersTable();
    }

    /* ══════════════════════════════════
       MODAL CREAR AREA
       ══════════════════════════════════ */
    // Estado del asistente. `pendientes` son las \u00e1reas que todav\u00eda no se han
    // creado: tras un fallo parcial se queda solo con las que fallaron, para
    // que \u00abReintentar\u00bb nunca vuelva a enviar las que ya existen.
    var geAreaWizard = { grupoId: 0, pendientes: [], creadas: [], fallidas: [], enviando: false };

    function openAreaModal(userId) {
        geAreaWizard = { grupoId: userId, pendientes: [], creadas: [], fallidas: [], enviando: false };

        $('#ge-area-grupo-id').val(userId);
        $('#ge-area-notice').hide().removeClass('success error').text('');
        $('#ge-area-notice-2').hide().text('');

        $('#ge-area-filas').html(areaFilaHtml(0, fechaPorDefecto()));
        actualizarFilasUI();
        mostrarPasoArea(1);

        showModal('#ge-modal-area-overlay');
        setTimeout(function () { $('#ge-area-filas .ge-area-nombre').first().focus(); }, 200);
    }

    function closeAreaModal() {
        if (geAreaWizard.enviando) return; // no cerrar a mitad de la creaci\u00f3n
        hideModal('#ge-modal-area-overlay');
    }

    /** Fecha sugerida: seis meses vista, igual que antes. */
    function fechaPorDefecto() {
        var d = new Date();
        d.setMonth(d.getMonth() + 6);
        return d.getFullYear() + '-' +
            String(d.getMonth() + 1).padStart(2, '0') + '-' +
            String(d.getDate()).padStart(2, '0');
    }

    /**
     * Una fila de captura. Las etiquetas se repiten en todas las filas por
     * accesibilidad; en escritorio el CSS oculta las de la segunda en adelante
     * para que la rejilla no se llene de texto repetido.
     */
    function areaFilaHtml(indice, fecha) {
        return '<div class="ge-area-fila" data-index="' + indice + '">'
            + '<div class="ge-field">'
            +   '<label>Nombre del \u00e1rea <span class="ge-required">*</span></label>'
            +   '<input type="text" class="ge-area-nombre" placeholder="Ej: \u00c1rea de Ventas" aria-label="Nombre del \u00e1rea">'
            +   '<p class="ge-field-error" hidden></p>'
            + '</div>'
            + '<div class="ge-field ge-field-cupo">'
            +   '<label>Cupos <span class="ge-required">*</span></label>'
            +   '<input type="number" class="ge-area-cupo" value="1" min="1" step="1" aria-label="N\u00famero de cupos">'
            +   '<p class="ge-field-error" hidden></p>'
            + '</div>'
            + '<div class="ge-field ge-field-fecha">'
            +   '<label>Expiraci\u00f3n <span class="ge-required">*</span></label>'
            +   '<input type="date" class="ge-area-fecha" value="' + esc(fecha) + '" aria-label="Fecha de expiraci\u00f3n">'
            +   '<p class="ge-field-error" hidden></p>'
            + '</div>'
            + '<button type="button" class="ge-area-fila-borrar" aria-label="Quitar esta \u00e1rea" title="Quitar esta \u00e1rea">'
            +   icon('trash', 15)
            + '</button>'
            + '</div>';
    }

    /**
     * La \u00faltima fila que quede no se puede borrar (siempre debe haber al menos
     * un \u00e1rea que registrar), as\u00ed que su bot\u00f3n se oculta.
     */
    function actualizarFilasUI() {
        var $filas = $('#ge-area-filas .ge-area-fila');
        $filas.find('.ge-area-fila-borrar').toggle($filas.length > 1);
        $('#ge-area-submit').text($filas.length > 1 ? 'Registrar \u00c1reas' : 'Registrar \u00c1rea');
    }

    function mostrarPasoArea(numero) {
        $('#ge-area-form').prop('hidden', 1 !== numero);
        $('#ge-area-paso-2').prop('hidden', 2 !== numero);
        $('#ge-area-paso-3').prop('hidden', 3 !== numero);

        var textos = {
            1: [ 'Crear \u00e1reas', 'Registra una o varias \u00e1reas para esta empresa' ],
            2: [ 'Confirmar \u00e1reas', 'Revisa los datos antes de crearlas' ],
            3: [ 'Resultado', 'Resumen de la creaci\u00f3n' ]
        };
        $('#ge-area-titulo').text(textos[numero][0]);
        $('#ge-area-desc').text(textos[numero][1]);
    }

    /* \u2500\u2500 Paso 1: captura y validaci\u00f3n \u2500\u2500 */

    $(document).on('click', '#ge-area-add', function () {
        var $filas  = $('#ge-area-filas .ge-area-fila');
        // La fecha de la \u00faltima fila se hereda: lo normal es crear varias
        // \u00e1reas con la misma vigencia.
        var ultima  = $filas.last().find('.ge-area-fecha').val() || fechaPorDefecto();
        $('#ge-area-filas').append(areaFilaHtml($filas.length, ultima));
        actualizarFilasUI();
        $('#ge-area-filas .ge-area-fila').last().find('.ge-area-nombre').focus();
    });

    $(document).on('click', '.ge-area-fila-borrar', function () {
        $(this).closest('.ge-area-fila').remove();
        actualizarFilasUI();
    });

    // Al corregir un campo se limpia su error, sin esperar a reenviar.
    $(document).on('input change', '#ge-area-filas input', function () {
        $(this).removeClass('ge-input-error')
            .closest('.ge-field').find('.ge-field-error').prop('hidden', true).text('');
    });

    /**
     * Lee las filas del DOM. Devuelve tambi\u00e9n el elemento de cada fila para
     * poder pintar los errores justo al lado del campo que los produce.
     */
    function leerFilasArea() {
        return $('#ge-area-filas .ge-area-fila').map(function () {
            var $f = $(this);
            return {
                $fila:  $f,
                nombre: String($f.find('.ge-area-nombre').val() || '').trim(),
                cupo:   String($f.find('.ge-area-cupo').val() || '').trim(),
                fecha:  String($f.find('.ge-area-fecha').val() || '').trim()
            };
        }).get();
    }

    function marcarErrorCampo($fila, clase, mensaje) {
        $fila.find(clase).addClass('ge-input-error')
            .closest('.ge-field').find('.ge-field-error').text(mensaje).prop('hidden', false);
    }

    /**
     * Valida todas las filas y pinta los errores. Devuelve las \u00e1reas limpias
     * si todo est\u00e1 bien, o null si hubo alg\u00fan error (los datos escritos se
     * conservan tal cual: nunca se repinta el paso 1).
     */
    function validarFilasArea() {
        var filas  = leerFilasArea();
        var areas  = [];
        var hayError = false;

        filas.forEach(function (fila) {
            fila.$fila.find('input').removeClass('ge-input-error');
            fila.$fila.find('.ge-field-error').prop('hidden', true).text('');

            if (!fila.nombre) {
                marcarErrorCampo(fila.$fila, '.ge-area-nombre', 'El nombre es obligatorio.');
                hayError = true;
            }

            // El campo es type=number, pero acepta decimales y notaci\u00f3n
            // cient\u00edfica: se exige expl\u00edcitamente un entero positivo.
            var cupo = /^\d+$/.test(fila.cupo) ? parseInt(fila.cupo, 10) : NaN;
            if (isNaN(cupo) || cupo < 1) {
                marcarErrorCampo(fila.$fila, '.ge-area-cupo', 'Debe ser un entero mayor que 0.');
                hayError = true;
            }

            if (!esFechaValida(fila.fecha)) {
                marcarErrorCampo(fila.$fila, '.ge-area-fecha', 'Indica una fecha v\u00e1lida.');
                hayError = true;
            }

            areas.push({ nombre: fila.nombre, cupo: cupo, fecha: fila.fecha });
        });

        if (hayError) {
            showNotice('#ge-area-notice', 'error', 'Revisa los campos marcados antes de continuar.');
            $('#ge-area-filas .ge-input-error').first().focus();
            return null;
        }

        $('#ge-area-notice').hide().text('');
        return areas;
    }

    /** Comprueba que la cadena sea una fecha real en formato YYYY-MM-DD. */
    function esFechaValida(texto) {
        var p = String(texto || '').match(/^(\d{4})-(\d{2})-(\d{2})$/);
        if (!p) return false;

        var anio = parseInt(p[1], 10), mes = parseInt(p[2], 10), dia = parseInt(p[3], 10);
        if (mes < 1 || mes > 12 || dia < 1) return false;

        // D\u00eda 0 del mes siguiente = \u00faltimo d\u00eda de este mes; cubre bisiestos.
        return dia <= new Date(anio, mes, 0).getDate();
    }

    $(document).on('submit', '#ge-area-form', function (e) {
        e.preventDefault();

        var areas = validarFilasArea();
        if (!areas) return;

        geAreaWizard.pendientes = areas;
        geAreaWizard.creadas    = [];
        geAreaWizard.fallidas   = [];

        pintarConfirmacionAreas(areas);
        $('#ge-area-notice-2').hide().text('');
        mostrarPasoArea(2);
    });

    /* \u2500\u2500 Paso 2: confirmaci\u00f3n \u2500\u2500 */

    function pintarConfirmacionAreas(areas) {
        $('#ge-area-confirmar-intro').text(
            areas.length === 1
                ? 'Se crear\u00e1 la siguiente \u00e1rea:'
                : 'Se crear\u00e1n las siguientes ' + areas.length + ' \u00e1reas:'
        );
        $('#ge-area-confirmar-tabla').html(tablaAreasHtml(areas));
    }

    function tablaAreasHtml(areas, extraCol) {
        return '<table class="ge-areas-table ge-areas-table-compacta"><thead><tr>'
            + '<th>Nombre del \u00e1rea</th>'
            + '<th style="text-align:center;">Cupos</th>'
            + '<th style="text-align:center;">Expiraci\u00f3n</th>'
            + (extraCol ? '<th style="text-align:center;">Estado</th>' : '')
            + '</tr></thead><tbody>'
            + areas.map(function (a) {
                return '<tr>'
                    + '<td><span class="ge-area-nombre">' + esc(a.nombre) + '</span></td>'
                    + '<td style="text-align:center;"><span class="ge-cupos-badge">' + esc(a.cupo) + '</span></td>'
                    + '<td style="text-align:center;" class="ge-u-nowrap">' + esc(formatFechaDMY(a.fecha)) + '</td>'
                    + (extraCol ? '<td style="text-align:center;">' + extraCol(a) + '</td>' : '')
                    + '</tr>';
            }).join('')
            + '</tbody></table>';
    }

    /** `YYYY-MM-DD` a `dd/mm/yyyy`, sin pasar por Date (ver formatFechaCorta). */
    function formatFechaDMY(raw) {
        var p = String(raw || '').match(/^(\d{4})-(\d{2})-(\d{2})$/);
        return p ? p[3] + '/' + p[2] + '/' + p[1] : String(raw || '');
    }

    $(document).on('click', '#ge-area-volver', function () {
        if (geAreaWizard.enviando) return;
        mostrarPasoArea(1); // los campos siguen intactos: el paso 1 nunca se repinta
    });

    $(document).on('click', '#ge-area-crear', function () {
        crearAreasPendientes();
    });

    $(document).on('click', '#ge-area-reintentar', function () {
        // Solo quedan pendientes las que fallaron, as\u00ed que no hay riesgo de
        // duplicar las ya creadas.
        mostrarPasoArea(2);
        pintarConfirmacionAreas(geAreaWizard.pendientes);
        $('#ge-area-notice-2').hide().text('');
    });

    $(document).on('click', '#ge-area-cerrar', function () {
        hideModal('#ge-modal-area-overlay');
    });

    /* \u2500\u2500 Creaci\u00f3n \u2500\u2500 */

    /**
     * Crea un \u00e1rea con el endpoint de siempre (ge_create_area), que conserva
     * todas sus validaciones de servidor. Nunca rechaza la promesa: el fallo
     * viaja en el resultado para poder seguir con las dem\u00e1s \u00e1reas.
     */
    function crearUnArea(area) {
        return new Promise(function (resolve) {
            $.post(GE_DATA.ajax_url, {
                action:           'ge_create_area',
                nonce:            GE_DATA.nonce,
                grupo_id:         geAreaWizard.grupoId,
                nombre:           area.nombre,
                cupo:             area.cupo,
                fecha_expiracion: area.fecha
            })
                .done(function (res) {
                    if (res && res.success) {
                        resolve({ ok: true, area: area });
                    } else {
                        resolve({ ok: false, area: area, error: (res && res.data && res.data.message) || 'No se pudo crear el \u00e1rea.' });
                    }
                })
                .fail(function () {
                    resolve({ ok: false, area: area, error: 'Error de conexi\u00f3n.' });
                });
        });
    }

    /**
     * Crea las \u00e1reas pendientes una tras otra (no en paralelo): as\u00ed el cupo y
     * el orden quedan deterministas y se puede informar del avance.
     */
    function crearAreasPendientes() {
        if (geAreaWizard.enviando || !geAreaWizard.pendientes.length) return;

        var lista = geAreaWizard.pendientes.slice();
        var total = lista.length;

        setCreandoAreas(true, 0, total);
        $('#ge-area-notice-2').hide().text('');

        var resultados = [];

        lista.reduce(function (cadena, area, i) {
            return cadena.then(function () {
                setCreandoAreas(true, i, total);
                return crearUnArea(area).then(function (r) { resultados.push(r); });
            });
        }, Promise.resolve()).then(function () {
            setCreandoAreas(false);

            var creadas  = resultados.filter(function (r) { return r.ok; }).map(function (r) { return r.area; });
            var fallidas = resultados.filter(function (r) { return !r.ok; });

            // Las creadas se acumulan entre reintentos; las pendientes pasan a
            // ser \u00fanicamente las que siguen fallando.
            geAreaWizard.creadas    = geAreaWizard.creadas.concat(creadas);
            geAreaWizard.fallidas   = fallidas;
            geAreaWizard.pendientes = fallidas.map(function (r) { return r.area; });

            if (creadas.length) {
                loadUsers(false); // refresca el contador de \u00e1reas de la empresa

                // Si este asistente se abri\u00f3 desde el listado de \u00e1reas, ese
                // listado sigue detr\u00e1s: se recarga para que al cerrar aqu\u00ed ya
                // muestre las \u00e1reas nuevas.
                if ($('#ge-modal-areas-overlay').is(':visible') &&
                    String(geAreasCtx.grupoId) === String(geAreaWizard.grupoId)) {
                    cargarAreasList();
                }
            }

            pintarResultadoAreas();
            mostrarPasoArea(3);
        });
    }

    function setCreandoAreas(activo, hechas, total) {
        geAreaWizard.enviando = activo;

        var $btn = $('#ge-area-crear');
        $btn.prop('disabled', activo);
        $btn.find('.ge-btn-text').toggle(!activo);
        $btn.find('.ge-btn-spinner').toggle(activo);
        $('#ge-area-volver').prop('disabled', activo);
        $('#ge-area-close').prop('disabled', activo);

        if (activo && total > 1) {
            $('#ge-area-progreso').text('Creando ' + Math.min(hechas + 1, total) + ' de ' + total + '\u2026');
        } else if (activo) {
            $('#ge-area-progreso').text('Creando\u2026');
        }
    }

    /* \u2500\u2500 Paso 3: resultado \u2500\u2500 */

    function pintarResultadoAreas() {
        var creadas  = geAreaWizard.creadas;
        var fallidas = geAreaWizard.fallidas;
        var html     = '';

        if (creadas.length) {
            html += '<div class="ge-area-resultado-bloque">'
                + '<div class="ge-area-resultado-cabecera is-ok">'
                +   icon('check', 16)
                +   '<span>' + (fallidas.length
                        ? creadas.length + (creadas.length === 1 ? ' \u00e1rea creada' : ' \u00e1reas creadas')
                        : 'Las \u00e1reas se crearon correctamente') + '</span>'
                + '</div>'
                + tablaAreasHtml(creadas)
                + '</div>';
        }

        if (fallidas.length) {
            html += '<div class="ge-area-resultado-bloque">'
                + '<div class="ge-area-resultado-cabecera is-error">'
                +   icon('alert', 16)
                +   '<span>' + fallidas.length + (fallidas.length === 1 ? ' \u00e1rea no se pudo crear' : ' \u00e1reas no se pudieron crear') + '</span>'
                + '</div>'
                + tablaAreasHtml(
                    fallidas.map(function (f) { return f.area; }),
                    function (area) {
                        var fallo = fallidas.filter(function (f) { return f.area === area; })[0];
                        return '<span class="ge-area-error-motivo">' + esc(fallo ? fallo.error : '') + '</span>';
                    }
                )
                + '</div>';
        }

        $('#ge-area-resultado').html(html);
        $('#ge-area-reintentar').prop('hidden', 0 === fallidas.length);
    }


    /* ══════════════════════════════════
       MODAL EDITAR AREA
       ══════════════════════════════════ */
    function openEditAreaModal(area) {
        closeAreasListModal();
        $('#ge-edit-area-id').val(area.id);
        $('#ge-edit-area-nombre').val(area.nombre);
        $('#ge-edit-area-cupo').val(area.cupo);
        $('#ge-edit-area-fecha').val(area.fecha_expiracion || '');
        $('#ge-edit-area-notice').hide().removeClass('success error').text('');
        showModal('#ge-modal-edit-area-overlay');
        setTimeout(function () { $('#ge-edit-area-nombre').focus(); }, 200);
    }

    function closeEditAreaModal() { hideModal('#ge-modal-edit-area-overlay'); }

    /* ══════════════════════════════════
       WIZARD DE IMPORTACIÓN MASIVA DE USUARIOS
       ══════════════════════════════════ */
    function openImportModal() {
        geImport = { step: 1, empresaId: '', areaId: '', area: null, file: null, headers: [], rows: [], mapping: {}, mappedRows: [], validated: null, results: { creados: [], fallidos: [] } };
        $('#ge-import-footer').show();
        showModal('#ge-modal-import-overlay');
        renderImportStepper();
        renderImportStep1();
    }

    function closeImportModal() { hideModal('#ge-modal-import-overlay'); }

    function renderImportStepper() {
        var html = '';
        for (var i = 1; i <= 4; i++) {
            var cls = 'ge-import-step-dot';
            if (geImport.step > 4 || i < geImport.step) cls += ' is-done';
            else if (i === geImport.step) cls += ' is-active';
            html += '<div class="' + cls + '">' + i + '</div>';
            if (i < 4) html += '<div class="ge-import-step-sep"></div>';
        }
        $('#ge-import-stepper').html(html);
    }

    function updateImportFooter() {
        var $back = $('#ge-import-back'), $next = $('#ge-import-next'), $cancel = $('#ge-import-cancel');
        if (geImport.step >= 5) { $back.hide(); $next.hide(); $cancel.hide(); return; }
        $cancel.show();
        $back.toggle(geImport.step > 1);
        $next.show();
        $next.find('.ge-btn-text').text(geImport.step === 4 ? 'Crear usuarios' : 'Siguiente');
        updateImportNextState();
    }

    function updateImportNextState() {
        var enabled = true;
        if (geImport.step === 1) {
            enabled = !!(geImport.empresaId && geImport.areaId);
            if (enabled && geImport.area && geImport.area.miembros >= geImport.area.cupo) enabled = false;
        }
        else if (geImport.step === 2) enabled = geImport.rows.length > 0;
        else if (geImport.step === 3) enabled = !!geImport.mapping.correo;
        $('#ge-import-next').prop('disabled', !enabled);
    }

    function importGoNext() {
        if ($('#ge-import-next').prop('disabled')) return;
        if (geImport.step === 1) { geImport.step = 2; renderImportStepper(); renderImportStep2(); return; }
        if (geImport.step === 2) { geImport.step = 3; renderImportStepper(); renderImportStep3(); return; }
        if (geImport.step === 3) { geImport.step = 4; renderImportStepper(); renderImportStep4(); return; }
        if (geImport.step === 4) { startImportCreation(); return; }
    }

    function importGoBack() {
        if (geImport.step <= 1) return;
        geImport.step -= 1;
        renderImportStepper();
        if (geImport.step === 1) renderImportStep1();
        else if (geImport.step === 2) renderImportStep2();
        else if (geImport.step === 3) renderImportStep3();
    }

    // ── Paso 1: Empresa y Área ──
    function renderImportStep1() {
        var html = '' +
            '<div class="ge-import-field">' +
                '<span class="ge-import-label">Empresa</span>' +
                '<select id="ge-import-empresa"><option value="">Cargando empresas…</option></select>' +
            '</div>' +
            '<div class="ge-import-field">' +
                '<span class="ge-import-label">Área / Paquete</span>' +
                '<select id="ge-import-area" disabled><option value="">Selecciona primero la empresa…</option></select>' +
            '</div>' +
            '<div id="ge-import-area-info"></div>';
        $('#ge-import-body').html(html);
        updateImportFooter();
        populateImportEmpresaSelect();
    }

    function populateImportEmpresaSelect() {
        var $sel = $('#ge-import-empresa');
        $.post(GE_DATA.ajax_url, { action: 'ge_list_users', nonce: GE_DATA.nonce, search: '' }, function (res) {
            if (!res || !res.success) return;
            $sel.html('<option value="">Selecciona una empresa…</option>');
            var empresas = (res.data.users || []).slice().sort(function (a, b) {
                return (a.empresa || '').localeCompare(b.empresa || '');
            });
            empresas.forEach(function (e) {
                $sel.append('<option value="' + e.id + '">' + esc(e.empresa) + '</option>');
            });
            if (geImport.empresaId) {
                $sel.val(geImport.empresaId);
                loadAreasForEmpresa(geImport.empresaId, geImport.areaId);
            }
        });
    }

    function importOnEmpresaChange() {
        var id = $('#ge-import-empresa').val();
        geImport.empresaId = id;
        geImport.areaId = null;
        geImport.area = null;
        loadAreasForEmpresa(id, null);
    }

    function loadAreasForEmpresa(id, restoreAreaId) {
        var $areaSel = $('#ge-import-area');
        $('#ge-import-area-info').empty();
        updateImportNextState();

        if (!id) {
            $areaSel.html('<option value="">Selecciona primero la empresa…</option>').prop('disabled', true);
            return;
        }
        $areaSel.html('<option value="">Cargando áreas…</option>').prop('disabled', true);

        $.post(GE_DATA.ajax_url, { action: 'ge_list_areas', nonce: GE_DATA.nonce, grupo_id: id }, function (res) {
            $areaSel.html('<option value="">Selecciona un área…</option>');
            if (res && res.success && res.data.areas && res.data.areas.length) {
                res.data.areas.forEach(function (a) {
                    $areaSel.append('<option value="' + a.id + '" data-cupo="' + a.cupo + '" data-miembros="' + (a.miembros || 0) + '" data-nombre="' + esc(a.nombre) + '">' + esc(a.nombre) + '</option>');
                });
                $areaSel.prop('disabled', false);
                if (restoreAreaId) { $areaSel.val(restoreAreaId); importOnAreaChange(); }
            } else {
                $areaSel.html('<option value="">Esta empresa no tiene áreas creadas</option>');
            }
            updateImportNextState();
        });
    }

    function importOnAreaChange() {
        var $opt = $('#ge-import-area option:selected');
        var id = $opt.val();
        geImport.areaId = id || null;
        if (!id) { $('#ge-import-area-info').empty(); updateImportNextState(); return; }

        var cupo = parseInt($opt.data('cupo'), 10) || 0;
        var miembros = parseInt($opt.data('miembros'), 10) || 0;
        geImport.area = { id: id, nombre: $opt.data('nombre'), cupo: cupo, miembros: miembros };

        var sinCupo = miembros >= cupo;
        var infoHtml = '<div class="ge-import-area-info' + (sinCupo ? ' is-full' : '') + '"><strong>Área: ' + esc(geImport.area.nombre) + '</strong><br>' +
            miembros + ' / ' + cupo + ' cupos utilizados</div>';

        if (sinCupo) {
            infoHtml += '<div class="ge-import-area-warning">Esta área ya no tiene cupos disponibles. Selecciona otra área o aumenta el cupo antes de continuar.</div>';
        }

        $('#ge-import-area-info').html(infoHtml);
        updateImportNextState();
    }

    // ── Paso 2: Subir archivo ──
    function renderImportStep2() {
        var html;
        if (geImport.file) {
            html = '<div class="ge-import-file-card">' +
                '<span>\uD83D\uDCC4 ' + esc(geImport.file.name) + '</span>' +
                '<span class="ge-import-file-meta">' + Math.round(geImport.file.size / 1024) + ' KB &middot; ' + geImport.rows.length + ' registros</span>' +
                '<button type="button" id="ge-import-file-remove" class="ge-import-file-remove">&times;</button>' +
                '</div>';
        } else {
            html = '<div class="ge-import-dropzone" id="ge-import-dropzone">' +
                'Arrastra tu archivo aquí o haz clic para seleccionarlo<br>' +
                '<small class="ge-u-muted">CSV, XLS o XLSX</small>' +
                '<input type="file" id="ge-import-file-input" accept=".csv,.xls,.xlsx" style="display:none;">' +
                '</div>';
        }
        $('#ge-import-body').html(html);
        updateImportFooter();
    }

    function importHandleFile(file) {
        var reader = new FileReader();
        reader.onload = function (e) {
            try {
                var data = new Uint8Array(e.target.result);
                var wb = XLSX.read(data, { type: 'array' });
                var sheet = wb.Sheets[wb.SheetNames[0]];
                var json = XLSX.utils.sheet_to_json(sheet, { defval: '' });
                if (!json.length) {
                    Swal.fire({ icon: 'warning', title: 'Archivo vacío', text: 'No se encontraron registros en el archivo.', confirmButtonText: 'Aceptar', confirmButtonColor: geColor('--ge-accent', '#944DE9') });
                    return;
                }
                geImport.file = file;
                geImport.headers = Object.keys(json[0]);
                geImport.rows = json;
                geImport.mapping = {};
                renderImportStep2();
            } catch (err) {
                geShowError('Error al leer el archivo', err.message);
            }
        };
        reader.readAsArrayBuffer(file);
    }

    // ── Paso 3: Emparejar columnas ──
    function importAutoSuggestHeader(fieldKey) {
        var candidates = {
            correo:        ['correo', 'email', 'correo electronico', 'e-mail', 'mail'],
            first_name:    ['nombre', 'nombres', 'first name', 'first_name', 'name'],
            last_name:     ['apellido', 'apellidos', 'last name', 'last_name', 'surname'],
            user_age:      ['edad', 'age'],
            user_gender:   ['genero', 'gender', 'sexo'],
            country:       ['pais', 'country'],
            phone_number:  ['telefono', 'phone', 'celular', 'contacto', 'numero de contacto'],
            user_position: ['cargo', 'position', 'ocupacion', 'puesto']
        };
        var options = candidates[fieldKey] || [];
        var norm = function (s) { return String(s || '').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').trim(); };
        var found = geImport.headers.find(function (h) { return options.indexOf(norm(h)) !== -1; });
        if (found) return found;
        found = geImport.headers.find(function (h) {
            var nh = norm(h);
            return options.some(function (o) { return nh.indexOf(o) !== -1 || o.indexOf(nh) !== -1; });
        });
        return found || '';
    }

    function renderImportStep3() {
        if (!Object.keys(geImport.mapping).length) {
            GE_IMPORT_SYSTEM_FIELDS.forEach(function (f) { geImport.mapping[f.key] = importAutoSuggestHeader(f.key); });
        }

        var rows = GE_IMPORT_SYSTEM_FIELDS.map(function (f) {
            var options = '<option value="">— No asignar —</option>';
            geImport.headers.forEach(function (h) {
                var sel = (geImport.mapping[f.key] === h) ? ' selected' : '';
                options += '<option value="' + esc(h) + '"' + sel + '>' + esc(h) + '</option>';
            });
            return '<tr><td>' + esc(f.label) + (f.required ? ' <span class="ge-required">*</span>' : '') + '</td>' +
                   '<td><select class="ge-import-map-select" data-field="' + f.key + '">' + options + '</select></td></tr>';
        }).join('');

        var html = '<p class="ge-u-note-mb">Indica qué columna de tu archivo corresponde a cada campo. El sistema ya sugirió las coincidencias más probables.</p>' +
            '<table class="ge-import-map-table"><thead><tr><th>Campo del sistema</th><th>Columna del archivo</th></tr></thead><tbody>' + rows + '</tbody></table>';

        $('#ge-import-body').html(html);
        updateImportFooter();
    }

    // ── Paso 4: Validación previa ──
    function importBuildMappedRows() {
        return geImport.rows.map(function (raw) {
            var obj = {};
            GE_IMPORT_SYSTEM_FIELDS.forEach(function (f) {
                var col = geImport.mapping[f.key];
                obj[f.key] = col ? raw[col] : '';
            });
            return obj;
        });
    }

    function renderImportStep4() {
        $('#ge-import-body').html('<div class="ge-spinner-wrap"><div class="ge-spinner"></div><span>Validando registros…</span></div>');
        updateImportFooter();
        $('#ge-import-next').prop('disabled', true);

        geImport.mappedRows = importBuildMappedRows();

        $.post(GE_DATA.ajax_url, {
            action: 'ge_import_validate',
            nonce: GE_DATA.nonce,
            empresa_id: geImport.empresaId,
            area_id: geImport.areaId,
            rows: JSON.stringify(geImport.mappedRows)
        }, function (res) {
            if (!res || !res.success) {
                $('#ge-import-body').html('<p class="ge-import-empty-msg">Error al validar: ' + esc((res && res.data && res.data.message) || 'Error desconocido.') + '</p>');
                return;
            }
            geImport.validated = res.data;
            renderImportStep4Results();
            $('#ge-import-next').prop('disabled', false);
        }).fail(function () {
            $('#ge-import-body').html('<p class="ge-import-empty-msg">Error de conexión al validar.</p>');
        });
    }

    function renderImportStep4Results() {
        var v = geImport.validated;
        var nuevosHtml = v.nuevos.length
            ? v.nuevos.map(function (u) { return '<div class="ge-import-summary-row">' + esc(u.correo) + '<small>' + esc(u.nombre) + ' &middot; ' + esc(u.area) + '</small></div>'; }).join('')
            : '<p class="ge-import-empty-msg">No hay registros en este grupo.</p>';
        var omitidosHtml = v.omitidos.length
            ? v.omitidos.map(function (u) { return '<div class="ge-import-summary-row">' + esc(u.correo) + '<small>' + esc(u.motivo) + '</small></div>'; }).join('')
            : '<p class="ge-import-empty-msg">No hay registros en este grupo.</p>';

        var html = '<p class="ge-u-note-mb">' + v.total + ' registros procesados</p>' +
            '<div class="ge-import-summary-grid">' +
                '<div class="ge-import-summary-box ok"><h4>Usuarios nuevos (' + v.nuevos.length + ')</h4>' + nuevosHtml + '</div>' +
                '<div class="ge-import-summary-box warn"><h4>Usuarios omitidos (' + v.omitidos.length + ')</h4>' + omitidosHtml + '</div>' +
            '</div>';
        $('#ge-import-body').html(html);
    }

    // ── Creación de usuarios + progreso + resumen final ──
    function startImportCreation() {
        geImport.step = 5;
        renderImportStepper();
        $('#ge-import-footer').hide();

        var nuevos = geImport.validated.nuevos;
        var total  = nuevos.length;
        var done   = 0;
        var creados  = [];
        var fallidos = [];

        var byEmail = {};
        geImport.mappedRows.forEach(function (r) {
            var e = String(r.correo || '').trim().toLowerCase();
            if (e) byEmail[e] = r;
        });

        renderImportProgress(done, total);

        if (!total) { finishImportCreation(creados, fallidos); return; }

        function createOne(item) {
            var row = byEmail[item.correo] || { correo: item.correo };
            return $.post(GE_DATA.ajax_url, {
                action: 'ge_import_create_one',
                nonce: GE_DATA.nonce,
                area_id: geImport.areaId,
                row: JSON.stringify(row)
            }).then(function (res) {
                if (res && res.success) {
                    creados.push({ correo: res.data.correo, nombre: res.data.nombre, area: res.data.area, estado: 'Creado' });
                } else {
                    fallidos.push({ correo: item.correo, motivo: (res && res.data && res.data.message) || 'Error desconocido.' });
                }
            }, function () {
                fallidos.push({ correo: item.correo, motivo: 'Error de conexión.' });
            }).always(function () {
                done++;
                renderImportProgress(done, total);
            });
        }

        function processBatch(startIdx) {
            if (startIdx >= total) { finishImportCreation(creados, fallidos); return; }
            var batch = nuevos.slice(startIdx, startIdx + GE_IMPORT_BATCH_SIZE);
            $.when.apply($, batch.map(createOne)).always(function () {
                processBatch(startIdx + GE_IMPORT_BATCH_SIZE);
            });
        }

        processBatch(0);
    }

    function renderImportProgress(done, total) {
        var pct = total ? Math.round((done / total) * 100) : 100;
        var html = '<div class="ge-import-progress-wrap">' +
            '<p class="ge-u-note-lg">Creando usuarios…</p>' +
            '<div class="ge-import-progress-pct">' + pct + '%</div>' +
            '<div class="ge-import-progress-bar-outer"><div class="ge-import-progress-bar-inner" style="width:' + pct + '%;"></div></div>' +
            '<p class="ge-u-note-top">' + done + ' de ' + total + ' usuarios procesados</p>' +
            '</div>';
        $('#ge-import-body').html(html);
    }

    function finishImportCreation(creados, fallidos) {
        geImport.step = 6;
        geImport.results = { creados: creados, fallidos: fallidos };
        renderImportStepper();

        var totalOmitidos = (geImport.validated.omitidos || []).concat(fallidos);

        var creadosHtml = creados.length
            ? creados.map(function (u) { return '<div class="ge-import-summary-row">' + esc(u.correo) + '<small>' + esc(u.nombre) + ' &middot; ' + esc(u.area) + ' &middot; ' + esc(u.estado) + '</small></div>'; }).join('')
            : '<p class="ge-import-empty-msg">No se creó ningún usuario.</p>';
        var omitidosHtml = totalOmitidos.length
            ? totalOmitidos.map(function (u) { return '<div class="ge-import-summary-row">' + esc(u.correo) + '<small>' + esc(u.motivo) + '</small></div>'; }).join('')
            : '<p class="ge-import-empty-msg">No hay registros omitidos.</p>';

        var html = '<div class="ge-import-final-totals">' +
                '<div class="ge-import-final-stat"><div class="num">' + geImport.validated.total + '</div><div class="lbl">Total encontrados</div></div>' +
                '<div class="ge-import-final-stat"><div class="num">' + creados.length + '</div><div class="lbl">Creados</div></div>' +
                '<div class="ge-import-final-stat"><div class="num">' + totalOmitidos.length + '</div><div class="lbl">Omitidos</div></div>' +
            '</div>' +
            '<div class="ge-import-summary-grid">' +
                '<div class="ge-import-summary-box ok"><h4>Usuarios creados (' + creados.length + ')</h4>' + creadosHtml + '</div>' +
                '<div class="ge-import-summary-box warn"><h4>Usuarios omitidos (' + totalOmitidos.length + ')</h4>' + omitidosHtml + '</div>' +
            '</div>' +
            '<div style="text-align:right;margin-top:18px;">' +
                '<button type="button" id="ge-import-finish" class="ge-btn-primary">Finalizar</button>' +
            '</div>';

        $('#ge-import-body').html(html);
    }

    /* ══════════════════════════════════
       ACTUALIZAR CORREOS (wizard masivo)
       ══════════════════════════════════ */
    var geUpdEmails = {
        step: 1, file: null, headers: [], rows: [],
        colActual: '', colNuevo: '',
        validated: [], search: '', page: 1, perPage: 25,
        results: [], resultsSearch: '', resultsPage: 1, resultsPerPage: 25,
        startTime: 0
    };

    function openUpdateEmailsModal() {
        geUpdEmails = {
            step: 1, file: null, headers: [], rows: [], colActual: '', colNuevo: '',
            validated: [], search: '', page: 1, perPage: 25,
            results: [], resultsSearch: '', resultsPage: 1, resultsPerPage: 25, startTime: 0
        };
        $('#ge-updemails-footer').show();
        showModal('#ge-modal-updemails-overlay');
        renderUpdEmailsStepper();
        renderUpdEmailsStep1();
    }

    function closeUpdateEmailsModal() { hideModal('#ge-modal-updemails-overlay'); }

    function renderUpdEmailsStepper() {
        var html = '';
        for (var i = 1; i <= 2; i++) {
            var cls = 'ge-import-step-dot';
            if (geUpdEmails.step > 2 || i < geUpdEmails.step) cls += ' is-done';
            else if (i === geUpdEmails.step) cls += ' is-active';
            html += '<div class="' + cls + '">' + i + '</div>';
            if (i < 2) html += '<div class="ge-import-step-sep"></div>';
        }
        $('#ge-updemails-stepper').html(html);
    }

    function updUpdateFooter() {
        var $back = $('#ge-updemails-back'), $next = $('#ge-updemails-next'), $cancel = $('#ge-updemails-cancel');
        if (geUpdEmails.step >= 3) { $back.hide(); $next.hide(); $cancel.hide(); return; }
        $cancel.show();
        $back.toggle(geUpdEmails.step > 1);
        $next.show();
        $next.find('.ge-btn-text').text(geUpdEmails.step === 2 ? 'Actualizar correos' : 'Siguiente');
        updUpdateNextState();
    }

    function updUpdateNextState() {
        var enabled = true;
        if (geUpdEmails.step === 1) enabled = geUpdEmails.rows.length > 0 && !!geUpdEmails.colActual && !!geUpdEmails.colNuevo;
        else if (geUpdEmails.step === 2) enabled = geUpdEmails.validated.some(function (r) { return r.estado === 'ok'; });
        $('#ge-updemails-next').prop('disabled', !enabled);
    }

    function updEmailsGoNext() {
        if ($('#ge-updemails-next').prop('disabled')) return;
        if (geUpdEmails.step === 1) { runEmailValidation(); return; }
        if (geUpdEmails.step === 2) { showUpdateEmailsConfirm(); return; }
    }

    function updEmailsGoBack() {
        if (geUpdEmails.step <= 1) return;
        geUpdEmails.step -= 1;
        renderUpdEmailsStepper();
        renderUpdEmailsStep1();
    }

    // ── Paso 1: Cargar archivo + elegir columnas ──
    function renderUpdEmailsStep1() {
        var html = '';
        if (geUpdEmails.file) {
            html += '<div class="ge-import-file-card">' +
                '<span>\uD83D\uDCC4 ' + esc(geUpdEmails.file.name) + '</span>' +
                '<span class="ge-import-file-meta">' + Math.round(geUpdEmails.file.size / 1024) + ' KB &middot; ' + geUpdEmails.rows.length + ' registros</span>' +
                '<button type="button" id="ge-updemails-file-remove" class="ge-import-file-remove">&times;</button>' +
                '</div>';

            html += '<div class="ge-import-field" style="margin-top:18px;">' +
                '<span class="ge-import-label">Columna del correo actual <span class="ge-required">*</span></span>' +
                '<select id="ge-updemails-col-actual"><option value="">Selecciona una columna…</option>' +
                geUpdEmails.headers.map(function (h) {
                    return '<option value="' + esc(h) + '"' + (geUpdEmails.colActual === h ? ' selected' : '') + '>' + esc(h) + '</option>';
                }).join('') + '</select></div>' +
                '<div class="ge-import-field">' +
                '<span class="ge-import-label">Columna del correo nuevo <span class="ge-required">*</span></span>' +
                '<select id="ge-updemails-col-nuevo"><option value="">Selecciona una columna…</option>' +
                geUpdEmails.headers.map(function (h) {
                    return '<option value="' + esc(h) + '"' + (geUpdEmails.colNuevo === h ? ' selected' : '') + '>' + esc(h) + '</option>';
                }).join('') + '</select></div>';
        } else {
            html = '<div class="ge-import-dropzone" id="ge-updemails-dropzone">' +
                'Arrastra tu archivo aquí o haz clic para seleccionarlo<br>' +
                '<small class="ge-u-muted">XLS o XLSX</small>' +
                '<input type="file" id="ge-updemails-file-input" accept=".xls,.xlsx" style="display:none;">' +
                '</div>';
        }
        $('#ge-updemails-body').html(html);
        updUpdateFooter();
    }

    function updEmailsHandleFile(file) {
        var reader = new FileReader();
        reader.onload = function (e) {
            try {
                var data = new Uint8Array(e.target.result);
                var wb = XLSX.read(data, { type: 'array' });
                var sheet = wb.Sheets[wb.SheetNames[0]];
                var json = XLSX.utils.sheet_to_json(sheet, { defval: '' });
                if (!json.length) {
                    Swal.fire({ icon: 'warning', title: 'Archivo vacío', text: 'No se encontraron registros en el archivo.', confirmButtonText: 'Aceptar', confirmButtonColor: geColor('--ge-accent', '#944DE9') });
                    return;
                }
                geUpdEmails.file = file;
                geUpdEmails.headers = Object.keys(json[0]);
                geUpdEmails.rows = json;
                geUpdEmails.colActual = '';
                geUpdEmails.colNuevo = '';
                // auto-sugerencia simple por nombre de columna
                geUpdEmails.headers.forEach(function (h) {
                    var norm = String(h).toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '');
                    if (!geUpdEmails.colActual && /correo.*actual|antiguo|old/.test(norm)) geUpdEmails.colActual = h;
                    if (!geUpdEmails.colNuevo && /correo.*nuevo|new/.test(norm)) geUpdEmails.colNuevo = h;
                });
                renderUpdEmailsStep1();
            } catch (err) {
                Swal.fire({ icon: 'error', title: 'Error al leer el archivo', text: err.message, confirmButtonText: 'Aceptar', confirmButtonColor: geColor('--ge-accent', '#944DE9') });
            }
        };
        reader.readAsArrayBuffer(file);
    }

    // ── Paso 2: Validación previa ──
    function runEmailValidation() {
        var rows = geUpdEmails.rows.map(function (raw) {
            return { correo_actual: raw[geUpdEmails.colActual], correo_nuevo: raw[geUpdEmails.colNuevo] };
        });

        $('#ge-updemails-body').html('<div class="ge-spinner-wrap"><div class="ge-spinner"></div><span>Validando registros…</span></div>');
        $('#ge-updemails-next').prop('disabled', true).find('.ge-btn-text').hide();
        $('#ge-updemails-next').find('.ge-btn-spinner').show();

        $.post(GE_DATA.ajax_url, {
            action: 'ge_validate_email_update',
            nonce: GE_DATA.nonce,
            rows: JSON.stringify(rows)
        }, function (res) {
            $('#ge-updemails-next').find('.ge-btn-text').show();
            $('#ge-updemails-next').find('.ge-btn-spinner').hide();

            if (!res || !res.success) {
                $('#ge-updemails-body').html('<p class="ge-import-empty-msg">Error al validar: ' + esc((res && res.data && res.data.message) || 'Error desconocido.') + '</p>');
                return;
            }
            geUpdEmails.validated = res.data.items;
            geUpdEmails.step = 2;
            geUpdEmails.page = 1;
            geUpdEmails.search = '';
            renderUpdEmailsStepper();
            renderUpdEmailsStep2();
        }).fail(function () {
            $('#ge-updemails-next').find('.ge-btn-text').show();
            $('#ge-updemails-next').find('.ge-btn-spinner').hide();
            $('#ge-updemails-body').html('<p class="ge-import-empty-msg">Error de conexión al validar.</p>');
        });
    }

    function updEmailsFilteredValidated() {
        var list = geUpdEmails.validated;
        var q = geUpdEmails.search.trim().toLowerCase();
        if (q) {
            list = list.filter(function (r) {
                return r.correo_actual.toLowerCase().indexOf(q) !== -1 || r.correo_nuevo.toLowerCase().indexOf(q) !== -1;
            });
        }
        return list;
    }

    function renderUpdEmailsStep2() {
        var okCount = geUpdEmails.validated.filter(function (r) { return r.estado === 'ok'; }).length;
        var errCount = geUpdEmails.validated.length - okCount;

        var html = '<div class="ge-usermeta-toolbar ge-updemails-toolbar-inline">' +
            '<div class="ge-search-inner ge-usermeta-search-inner">' +
            '<svg class="ge-search-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/></svg>' +
            '<input type="text" id="ge-updemails-search" class="ge-search-input" placeholder="Buscar por correo actual o nuevo…" value="' + esc(geUpdEmails.search) + '"></div>' +
            '<span class="ge-u-note ge-u-nowrap">' + okCount + ' v\u00e1lidos &middot; ' + errCount + ' omitidos</span>' +
            '</div>' +
            '<div class="ge-table-wrap ge-usermeta-table-wrap">' +
            '<table class="ge-table"><thead><tr><th>Correo actual</th><th>Correo nuevo</th><th style="width:150px;text-align:center;">Estado</th><th>Motivo</th></tr></thead>' +
            '<tbody id="ge-updemails-tbody"></tbody></table>' +
            '<div class="ge-pagination-bar">' +
            '<div class="ge-per-page"><label for="ge-updemails-per-page">Mostrar</label>' +
            '<select id="ge-updemails-per-page"><option value="10">10</option><option value="25" selected>25</option><option value="50">50</option><option value="100">100</option></select>' +
            '<span>por página</span></div>' +
            '<div class="ge-pagination-info" id="ge-updemails-pagination-info">—</div>' +
            '<div class="ge-pagination-controls" id="ge-updemails-pagination-controls"></div>' +
            '</div></div>';

        $('#ge-updemails-body').html(html);
        updUpdateFooter();
        renderUpdEmailsValidationTable();
    }

    function renderUpdEmailsValidationTable() {
        var filtered = updEmailsFilteredValidated();
        var total = filtered.length;
        var totalPages = Math.max(1, Math.ceil(total / geUpdEmails.perPage));
        if (geUpdEmails.page > totalPages) geUpdEmails.page = totalPages;
        var startIdx = (geUpdEmails.page - 1) * geUpdEmails.perPage;
        var pageItems = filtered.slice(startIdx, startIdx + geUpdEmails.perPage);

        if (!pageItems.length) {
            $('#ge-updemails-tbody').html('<tr><td colspan="4" class="ge-cell-state">No hay registros que coincidan.</td></tr>');
        } else {
            $('#ge-updemails-tbody').html(pageItems.map(function (r) {
                var badge = r.estado === 'ok'
                    ? '<span class="ge-mini-badge ge-mini-ok">' + icon('check', 11) + ' Se puede actualizar</span>'
                    : '<span class="ge-mini-badge ge-mini-bad">' + icon('alert', 11) + ' No se puede actualizar</span>';
                return '<tr><td>' + esc(r.correo_actual) + '</td><td>' + esc(r.correo_nuevo) + '</td>' +
                    '<td class="ge-u-center">' + badge + '</td><td class="ge-u-muted">' + esc(r.motivo) + '</td></tr>';
            }).join(''));
        }

        renderPagination(total, totalPages, total ? startIdx : 0, Math.min(startIdx + pageItems.length, total), {
            infoSel: '#ge-updemails-pagination-info',
            controlsSel: '#ge-updemails-pagination-controls',
            getPage: function () { return geUpdEmails.page; },
            setPage: function (p) { geUpdEmails.page = p; },
            rerender: renderUpdEmailsValidationTable
        });
    }

    // ── Confirmación previa a ejecutar ──
    function showUpdateEmailsConfirm() {
        var okCount = geUpdEmails.validated.filter(function (r) { return r.estado === 'ok'; }).length;
        var errCount = geUpdEmails.validated.length - okCount;

        Swal.fire({
            icon: 'warning',
            title: '\u00bfActualizar correos?',
            html: '<div class="ge-u-list">' +
                '<strong>' + geUpdEmails.validated.length + '</strong> registros encontrados en total.<br>' +
                '<strong class="ge-u-ok">' + okCount + '</strong> ser\u00e1n actualizados.<br>' +
                '<strong class="ge-u-error">' + errCount + '</strong> ser\u00e1n omitidos (no superaron alguna validaci\u00f3n).<br><br>' +
                '\u00danicamente se modificar\u00e1n los usuarios que superaron todas las validaciones.' +
                '</div>',
            showCancelButton: true,
            confirmButtonText: 'Actualizar correos',
            cancelButtonText: 'Cancelar',
            confirmButtonColor: geColor('--ge-accent', '#944DE9'),
            cancelButtonColor: geColor('--ge-text-muted', '#6B6672'),
            reverseButtons: true,
        }).then(function (result) {
            if (!result.isConfirmed) return;
            executeUpdateEmails();
        });
    }

    // ── Ejecución + progreso ──
    function executeUpdateEmails() {
        geUpdEmails.step = 3;
        renderUpdEmailsStepper();
        $('#ge-updemails-footer').hide();
        geUpdEmails.startTime = Date.now();

        var validRows = geUpdEmails.validated.filter(function (r) { return r.estado === 'ok'; });
        var total = validRows.length;
        var done = 0;
        var results = [];

        renderUpdEmailsProgress(done, total);

        function updateOne(row) {
            return $.post(GE_DATA.ajax_url, {
                action: 'ge_update_email_one',
                nonce: GE_DATA.nonce,
                correo_actual: row.correo_actual,
                correo_nuevo: row.correo_nuevo
            }).then(function (res) {
                if (res && res.success) {
                    results.push({ correo_actual: row.correo_actual, correo_nuevo: row.correo_nuevo, resultado: 'Actualizado correctamente.', ok: true });
                } else {
                    results.push({ correo_actual: row.correo_actual, correo_nuevo: row.correo_nuevo, resultado: ((res && res.data && res.data.message) || 'Error durante la actualizaci\u00f3n.'), ok: false });
                }
            }, function () {
                results.push({ correo_actual: row.correo_actual, correo_nuevo: row.correo_nuevo, resultado: 'Error de conexi\u00f3n.', ok: false });
            }).always(function () {
                done++;
                renderUpdEmailsProgress(done, total);
            });
        }

        // Los omitidos por validación previa también entran al resumen final como informativos
        var skipped = geUpdEmails.validated.filter(function (r) { return r.estado !== 'ok'; }).map(function (r) {
            return { correo_actual: r.correo_actual, correo_nuevo: r.correo_nuevo, resultado: r.motivo, ok: false };
        });

        if (!total) {
            finishUpdateEmails(skipped);
            return;
        }

        function processBatch(startIdx) {
            if (startIdx >= total) {
                finishUpdateEmails(skipped.concat(results));
                return;
            }
            var batch = validRows.slice(startIdx, startIdx + GE_SYNC_BATCH_SIZE);
            $.when.apply($, batch.map(updateOne)).always(function () {
                processBatch(startIdx + GE_SYNC_BATCH_SIZE);
            });
        }
        processBatch(0);
    }

    function renderUpdEmailsProgress(done, total) {
        var pct = total ? Math.round((done / total) * 100) : 100;
        var html = '<div class="ge-import-progress-wrap">' +
            '<p class="ge-u-note-lg">Actualizando correos…</p>' +
            '<div class="ge-import-progress-pct">' + pct + '%</div>' +
            '<div class="ge-import-progress-bar-outer"><div class="ge-import-progress-bar-inner" style="width:' + pct + '%;"></div></div>' +
            '<p class="ge-u-note-top">' + done + ' de ' + total + ' registros procesados</p>' +
            '</div>';
        $('#ge-updemails-body').html(html);
    }

    // ── Resumen final ──
    function finishUpdateEmails(allResults) {
        geUpdEmails.step = 4;
        geUpdEmails.results = allResults;
        geUpdEmails.resultsSearch = '';
        geUpdEmails.resultsPage = 1;
        renderUpdEmailsStepper();

        var elapsedSec = ((Date.now() - geUpdEmails.startTime) / 1000).toFixed(1);
        var okCount = allResults.filter(function (r) { return r.ok; }).length;
        var errCount = allResults.length - okCount;

        var html = '<div class="ge-import-final-totals">' +
            '<div class="ge-import-final-stat"><div class="num">' + allResults.length + '</div><div class="lbl">Procesados</div></div>' +
            '<div class="ge-import-final-stat"><div class="num">' + okCount + '</div><div class="lbl">Actualizados</div></div>' +
            '<div class="ge-import-final-stat"><div class="num">' + errCount + '</div><div class="lbl">Omitidos / errores</div></div>' +
            '<div class="ge-import-final-stat"><div class="num">' + elapsedSec + 's</div><div class="lbl">Tiempo total</div></div>' +
            '</div>' +
            '<div class="ge-usermeta-toolbar ge-updemails-toolbar-inline">' +
            '<div class="ge-search-inner ge-usermeta-search-inner">' +
            '<svg class="ge-search-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/></svg>' +
            '<input type="text" id="ge-updemails-results-search" class="ge-search-input" placeholder="Buscar en el resultado…"></div>' +
            '</div>' +
            '<div class="ge-table-wrap ge-usermeta-table-wrap">' +
            '<table class="ge-table"><thead><tr><th>Correo anterior</th><th>Correo nuevo</th><th>Resultado</th></tr></thead>' +
            '<tbody id="ge-updemails-results-tbody"></tbody></table>' +
            '<div class="ge-pagination-bar">' +
            '<div class="ge-per-page"><label for="ge-updemails-results-per-page">Mostrar</label>' +
            '<select id="ge-updemails-results-per-page"><option value="10">10</option><option value="25" selected>25</option><option value="50">50</option><option value="100">100</option></select>' +
            '<span>por página</span></div>' +
            '<div class="ge-pagination-info" id="ge-updemails-results-pagination-info">—</div>' +
            '<div class="ge-pagination-controls" id="ge-updemails-results-pagination-controls"></div>' +
            '</div></div>' +
            '<div style="text-align:right;margin-top:18px;">' +
            '<button type="button" id="ge-updemails-finish" class="ge-btn-primary">Finalizar</button>' +
            '</div>';

        $('#ge-updemails-body').html(html);
        renderUpdEmailsResultsTable();
    }

    function updEmailsFilteredResults() {
        var list = geUpdEmails.results;
        var q = geUpdEmails.resultsSearch.trim().toLowerCase();
        if (q) {
            list = list.filter(function (r) {
                return r.correo_actual.toLowerCase().indexOf(q) !== -1 || r.correo_nuevo.toLowerCase().indexOf(q) !== -1 || r.resultado.toLowerCase().indexOf(q) !== -1;
            });
        }
        return list;
    }

    function renderUpdEmailsResultsTable() {
        var filtered = updEmailsFilteredResults();
        var total = filtered.length;
        var totalPages = Math.max(1, Math.ceil(total / geUpdEmails.resultsPerPage));
        if (geUpdEmails.resultsPage > totalPages) geUpdEmails.resultsPage = totalPages;
        var startIdx = (geUpdEmails.resultsPage - 1) * geUpdEmails.resultsPerPage;
        var pageItems = filtered.slice(startIdx, startIdx + geUpdEmails.resultsPerPage);

        if (!pageItems.length) {
            $('#ge-updemails-results-tbody').html('<tr><td colspan="3" class="ge-cell-state">No hay registros que coincidan.</td></tr>');
        } else {
            $('#ge-updemails-results-tbody').html(pageItems.map(function (r) {
                var estado = r.ok
                    ? '<span class="ge-mini-badge ge-mini-ok">' + icon('check', 11) + ' OK</span>'
                    : '<span class="ge-mini-badge ge-mini-bad">' + icon('alert', 11) + ' Error</span>';
                return '<tr><td>' + esc(r.correo_actual) + '</td><td>' + esc(r.correo_nuevo) + '</td>'
                    + '<td class="ge-u-break">' + estado + ' <span class="ge-u-muted">' + esc(r.resultado) + '</span></td></tr>';
            }).join(''));
        }

        renderPagination(total, totalPages, total ? startIdx : 0, Math.min(startIdx + pageItems.length, total), {
            infoSel: '#ge-updemails-results-pagination-info',
            controlsSel: '#ge-updemails-results-pagination-controls',
            getPage: function () { return geUpdEmails.resultsPage; },
            setPage: function (p) { geUpdEmails.resultsPage = p; },
            rerender: renderUpdEmailsResultsTable
        });
    }


    $(document).on('submit', '#ge-edit-area-form', function (e) {
        e.preventDefault();
        var areaId = $('#ge-edit-area-id').val();
        var nombre = $('#ge-edit-area-nombre').val().trim();
        var cupo   = parseInt($('#ge-edit-area-cupo').val(), 10);
        var fecha  = $('#ge-edit-area-fecha').val().trim();

        if (!nombre) { showNotice('#ge-edit-area-notice', 'error', 'El nombre es obligatorio.'); return; }
        if (!cupo || cupo < 1) { showNotice('#ge-edit-area-notice', 'error', 'Los cupos deben ser mayor a 0.'); return; }
        if (!fecha)  { showNotice('#ge-edit-area-notice', 'error', 'La fecha es obligatoria.'); return; }

        // Validar que fecha sea mayor a hoy
        var hoy   = new Date(); hoy.setHours(0,0,0,0);
        var parts = fecha.split('-');
        var fDate = new Date(parts[0], parts[1]-1, parts[2]);
        if (fDate <= hoy) { showNotice('#ge-edit-area-notice', 'error', 'La fecha debe ser mayor a la fecha actual.'); return; }

        var $btn = $('#ge-edit-area-submit');
        $btn.find('.ge-btn-text').hide();
        $btn.find('.ge-btn-spinner').show();
        $btn.prop('disabled', true);

        $.post(GE_DATA.ajax_url, {
            action: 'ge_edit_area', nonce: GE_DATA.nonce,
            area_id: areaId, nombre: nombre, cupo: cupo, fecha_expiracion: fecha
        }, function (res) {
            $btn.find('.ge-btn-text').show();
            $btn.find('.ge-btn-spinner').hide();
            $btn.prop('disabled', false);
            if (res.success) {
                closeEditAreaModal();
                loadUsers(false);
                Swal.fire({ icon: 'success', title: '\u00c1rea actualizada', text: res.data.message || 'Los cambios fueron guardados.', confirmButtonText: 'Aceptar', confirmButtonColor: geColor('--ge-accent', '#944DE9') });
            } else {
                showNotice('#ge-edit-area-notice', 'error', res.data.message || 'Ocurri\u00f3 un error.');
            }
        }).fail(function () {
            $btn.find('.ge-btn-text').show();
            $btn.find('.ge-btn-spinner').hide();
            $btn.prop('disabled', false);
            showNotice('#ge-edit-area-notice', 'error', 'Error de conexi\u00f3n.');
        });
    });

    // Cerrar dropdowns de área al click fuera
    $(document).on('click', function () { $('.ge-area-dropdown').removeClass('open'); });


})(jQuery);

// NOTE: Lines above close the IIFE. The placeholders below are appended outside
// intentionally as named functions so they can be overridden from other scripts.
