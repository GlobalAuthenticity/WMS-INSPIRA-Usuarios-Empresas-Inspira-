<?php
/**
 * Renderizado de la página principal del admin (tabs Empresas / Usuarios)
 *
 * @package GestionarEmpresa
 */

if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Devuelve un icono SVG del set del panel.
 *
 * Los mismos paths se repetían literalmente en la plantilla y en el JS, lo que
 * acabó mezclando iconos SVG con emojis sueltos. Centralizarlos mantiene un
 * único trazo (stroke 2, viewBox 24) en todo el plugin.
 *
 * @param string $nombre Clave del icono.
 * @param int    $tamano Lado en píxeles.
 * @return string
 */
function ge_icon( $nombre, $tamano = 16 ) {
    $paths = [
        'building'  => '<path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/>',
        'search'    => '<circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/>',
        'refresh'   => '<path d="M23 4v6h-6"/><path d="M1 20v-6h6"/><path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15"/>',
        'filter'    => '<polygon points="22 3 2 3 10 12.46 10 19 14 21 14 12.46 22 3"/>',
        'info'      => '<circle cx="12" cy="12" r="10"/><path d="M12 16v-4"/><path d="M12 8h.01"/>',
        'trash'     => '<polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/><path d="M10 11v6"/><path d="M14 11v6"/><path d="M9 6V4a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2"/>',
    ];

    if ( ! isset( $paths[ $nombre ] ) ) return '';

    return '<svg xmlns="http://www.w3.org/2000/svg" width="' . (int) $tamano . '" height="' . (int) $tamano . '"'
        . ' viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"'
        . ' stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">'
        . $paths[ $nombre ] . '</svg>';
}

/**
 * Filas de carga (esqueleto) para el primer pintado.
 *
 * Se renderizan desde PHP para que la tabla ya tenga su altura real antes de
 * que el JS arranque; si no, la página salta cuando llega la primera respuesta.
 */
function ge_render_skeleton_rows( $columnas, $filas = 5 ) {
    for ( $f = 0; $f < $filas; $f++ ) {
        echo '<tr class="ge-skeleton-row" aria-hidden="true">';
        for ( $c = 0; $c < $columnas; $c++ ) {
            echo '<td><span class="ge-skeleton ge-skeleton-line"></span></td>';
        }
        echo '</tr>';
    }
}

function ge_render_page() {
    ?>
    <div id="ge-app">
        <div class="ge-header">
            <div class="ge-header-left">
                <div class="ge-logo-mark"><?php echo ge_icon( 'building', 22 ); ?></div>
                <div>
                    <h1 class="ge-title">Usuarios &amp; Empresas (Inspira)</h1>
                    <p class="ge-subtitle" id="ge-subtitle">Administra las empresas y sus encargados</p>
                </div>
            </div>
        </div>

        <div class="ge-tabs" role="tablist">
            <button type="button" class="ge-tab-btn active" data-tab="empresas" role="tab" aria-selected="true" aria-controls="ge-tab-empresas">
                Empresas <span class="ge-tab-count" id="ge-tab-count-empresas"></span>
            </button>
            <button type="button" class="ge-tab-btn" data-tab="usuarios" role="tab" aria-selected="false" aria-controls="ge-tab-usuarios">
                Usuarios <span class="ge-tab-count" id="ge-tab-count-usuarios"></span>
            </button>
        </div>

        <!-- ════════════ TAB EMPRESAS ════════════ -->
        <div class="ge-tab-panel" id="ge-tab-empresas" data-tab-panel="empresas" role="tabpanel">
            <p class="ge-scope-note"><?php echo ge_icon( 'info', 16 ); ?><span>Aquí se muestran las empresas que tienen asignado directamente el programa <strong>Inspira</strong>.</span></p>
            <div class="ge-toolbar">
                <div class="ge-toolbar-main">
                    <div class="ge-search-inner">
                        <span class="ge-search-icon"><?php echo ge_icon( 'search', 16 ); ?></span>
                        <input type="text" id="ge-search" class="ge-search-input" placeholder="Buscar empresa por nombre o correo…" />
                    </div>
                    <button type="button" class="ge-btn-filters" id="ge-btn-filters-empresas"
                            aria-expanded="false" aria-controls="ge-filters-empresas">
                        <?php echo ge_icon( 'filter', 14 ); ?>
                        Filtros
                        <span class="ge-filters-count" id="ge-filters-count-empresas"></span>
                    </button>
                    <button type="button" id="ge-btn-refresh-empresas" class="ge-btn-refresh" title="Refrescar lista" aria-label="Refrescar lista">
                        <?php echo ge_icon( 'refresh', 16 ); ?>
                    </button>
                </div>
                <div class="ge-toolbar-actions">
                    <button id="ge-btn-crear" class="ge-btn-primary">
                        <span class="ge-btn-icon" aria-hidden="true">+</span>
                        Crear Empresa
                    </button>
                </div>
            </div>

            <div class="ge-filters-panel" id="ge-filters-empresas" hidden>
                <div class="ge-filters-grid">
                    <div class="ge-filter-field">
                        <label for="ge-filter-programa">Programa</label>
                        <select id="ge-filter-programa" class="ge-filter-select">
                            <option value="">Todos los programas</option>
                            <option value="wms">Solo WMS</option>
                            <option value="octagono">Solo Octágono</option>
                            <option value="ambos">WMS y Octágono</option>
                            <option value="ninguno">Sin programa</option>
                        </select>
                    </div>
                </div>
            </div>

            <div class="ge-chips-bar" id="ge-chips-empresas" hidden></div>

            <div class="ge-table-wrap">
                <table class="ge-table ge-table-cards">
                    <thead>
                        <tr>
                            <th>Empresa</th>
                            <th style="text-align:center;">Áreas</th>
                            <th style="text-align:center;">Programas</th>
                            <th style="text-align:center;">Acciones</th>
                        </tr>
                    </thead>
                    <tbody id="ge-tbody"><?php ge_render_skeleton_rows( 4 ); ?></tbody>
                </table>

                <div class="ge-pagination-bar">
                    <div class="ge-per-page">
                        <label for="ge-per-page">Mostrar</label>
                        <select id="ge-per-page">
                            <option value="10">10</option>
                            <option value="25" selected>25</option>
                            <option value="50">50</option>
                            <option value="100">100</option>
                        </select>
                        <span>por página</span>
                    </div>
                    <div class="ge-pagination-info" id="ge-pagination-info">—</div>
                    <div class="ge-pagination-controls" id="ge-pagination-controls"></div>
                </div>
            </div>
        </div>

        <!-- ════════════ TAB USUARIOS ════════════ -->
        <div class="ge-tab-panel" id="ge-tab-usuarios" data-tab-panel="usuarios" role="tabpanel" style="display:none;">
            <p class="ge-scope-note"><?php echo ge_icon( 'info', 16 ); ?><span>Aquí se muestran los usuarios que tienen asignado directamente el programa <strong>Inspira</strong>.</span></p>
            <div class="ge-toolbar">
                <div class="ge-toolbar-main">
                    <div class="ge-search-inner">
                        <span class="ge-search-icon"><?php echo ge_icon( 'search', 16 ); ?></span>
                        <input type="text" id="ge-search-usuarios" class="ge-search-input" placeholder="Buscar por nombre, usuario o correo…" />
                    </div>
                    <button type="button" class="ge-btn-filters" id="ge-btn-filters-usuarios"
                            aria-expanded="false" aria-controls="ge-filters-usuarios">
                        <?php echo ge_icon( 'filter', 14 ); ?>
                        Filtros
                        <span class="ge-filters-count" id="ge-filters-count-usuarios"></span>
                    </button>
                    <button type="button" id="ge-btn-refresh-usuarios" class="ge-btn-refresh" title="Refrescar lista" aria-label="Refrescar lista">
                        <?php echo ge_icon( 'refresh', 16 ); ?>
                    </button>
                </div>
                <div class="ge-toolbar-actions">
                    <button id="ge-btn-importar" class="ge-btn-primary">
                        <span class="ge-btn-icon" aria-hidden="true">+</span>
                        Importar usuarios
                    </button>
                    <button id="ge-btn-update-emails" class="ge-btn-secondary">
                        Actualizar correos
                    </button>
                </div>
            </div>

            <div class="ge-filters-panel" id="ge-filters-usuarios" hidden>
                <div class="ge-filters-grid">
                    <div class="ge-filter-field">
                        <label for="ge-filter-programa-usuarios">Programa</label>
                        <select id="ge-filter-programa-usuarios" class="ge-filter-select">
                            <option value="">Todos los programas</option>
                            <option value="wms">Solo WMS</option>
                            <option value="octagono">Solo Octágono</option>
                            <option value="ambos">WMS y Octágono</option>
                            <option value="ninguno">Sin programa</option>
                        </select>
                    </div>
                    <div class="ge-filter-field">
                        <label for="ge-filter-empresa-usuarios">Empresa</label>
                        <select id="ge-filter-empresa-usuarios" class="ge-filter-select">
                            <option value="">Todas las empresas</option>
                        </select>
                    </div>
                    <div class="ge-filter-field">
                        <label for="ge-filter-area-usuarios">Área</label>
                        <select id="ge-filter-area-usuarios" class="ge-filter-select" disabled>
                            <option value="">Todas las áreas</option>
                        </select>
                    </div>
                    <div class="ge-filter-field">
                        <label for="ge-filter-test-usuarios">Test</label>
                        <select id="ge-filter-test-usuarios" class="ge-filter-select">
                            <option value="">Todos (test)</option>
                            <option value="con_test">Con test</option>
                            <option value="sin_test">Sin test</option>
                        </select>
                    </div>
                </div>
            </div>

            <div class="ge-chips-bar" id="ge-chips-usuarios" hidden></div>

            <div class="ge-bulk-bar" id="ge-bulk-bar-usuarios" hidden>
                <span class="ge-bulk-count" id="ge-bulk-count-usuarios">0 seleccionados</span>
                <button type="button" id="ge-bulk-delete-usuarios" class="ge-btn-primary ge-btn-danger">
                    <?php echo ge_icon( 'trash', 14 ); ?>
                    Borrar seleccionados
                </button>
                <button type="button" id="ge-bulk-clear-usuarios" class="ge-btn-secondary">Cancelar selección</button>
            </div>

            <div class="ge-table-wrap">
                <table class="ge-table ge-table-cards">
                    <thead>
                        <tr>
                            <th style="width:44px;">
                                <input type="checkbox" id="ge-sub-select-all" aria-label="Seleccionar todos los usuarios de la página" />
                            </th>
                            <th>Usuario</th>
                            <th>Asignación</th>
                            <th style="text-align:center;">Test</th>
                            <th style="text-align:center;">Cursos</th>
                            <th style="text-align:center;">Programas</th>
                            <th style="text-align:center;">Acciones</th>
                        </tr>
                    </thead>
                    <tbody id="ge-tbody-usuarios"><?php ge_render_skeleton_rows( 7 ); ?></tbody>
                </table>

                <div class="ge-pagination-bar">
                    <div class="ge-per-page">
                        <label for="ge-per-page-usuarios">Mostrar</label>
                        <select id="ge-per-page-usuarios">
                            <option value="10">10</option>
                            <option value="25" selected>25</option>
                            <option value="50">50</option>
                            <option value="100">100</option>
                        </select>
                        <span>por página</span>
                    </div>
                    <div class="ge-pagination-info" id="ge-pagination-info-usuarios">—</div>
                    <div class="ge-pagination-controls" id="ge-pagination-controls-usuarios"></div>
                </div>
            </div>
        </div>
    </div>
    <?php
}
