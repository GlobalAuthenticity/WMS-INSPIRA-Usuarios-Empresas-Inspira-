<?php
/**
 * Activación, tabla wp_areas, menú del admin y registro de assets
 *
 * @package GestionarEmpresa
 */

if ( ! defined( 'ABSPATH' ) ) exit;

function ge_activate() {
    ge_ensure_role_exists( 'empresa_admin', 'Empresa Admin' );
    ge_create_areas_table();
}

function ge_create_areas_table() {
    global $wpdb;
    require_once ABSPATH . 'wp-admin/includes/upgrade.php';
    $tabla  = $wpdb->prefix . 'areas';
    $collate = 'CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci';
    $sql = "CREATE TABLE {$tabla} (
        id               bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        nombre           varchar(255) {$collate} NOT NULL,
        cupo             int(11) NOT NULL,
        estado           varchar(255) {$collate} NOT NULL DEFAULT 'Activo',
        tipo             varchar(255) {$collate} DEFAULT NULL,
        grupo_id         bigint(20) UNSIGNED NOT NULL,
        fecha_expiracion date DEFAULT NULL,
        PRIMARY KEY (id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;";
    dbDelta( $sql );
}

// Auto-crear tabla wp_areas si no existe (cubre actualizaciones sin reactivar)
add_action( 'admin_init', function() {
    global $wpdb;
    $tabla = $wpdb->prefix . 'areas';
    if ( $wpdb->get_var( "SHOW TABLES LIKE '{$tabla}'" ) !== $tabla ) {
        ge_create_areas_table();
    }
});

add_action( 'admin_menu', 'ge_register_menu' );
function ge_register_menu() {
    add_menu_page(
        'Usuarios & Empresas (Inspira)',
        'Usuarios & Empresas',
        'manage_options',
        'gestionar-empresa',
        'ge_render_page',
        'dashicons-building',
        30
    );

    add_submenu_page(
        'gestionar-empresa',
        'Configuración de Integraciones',
        'Configuración',
        'manage_options',
        'ge-configuracion',
        'ge_render_settings_page'
    );
}

/**
 * Marca el <body> de las pantallas del plugin con la clase ge-admin.
 *
 * Los estilos de SweetAlert2 viven fuera de #ge-app (las ventanas se insertan
 * al final del body); esta clase permite acotarlos a estas pantallas para que
 * no alteren ventanas de otros plugins ni el resto de WordPress.
 */
add_filter( 'admin_body_class', 'ge_admin_body_class' );
function ge_admin_body_class( $classes ) {
    $screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
    $paginas_plugin = [ 'toplevel_page_gestionar-empresa', 'gestionar-empresa_page_ge-configuracion' ];
    if ( $screen && in_array( $screen->id, $paginas_plugin, true ) ) {
        $classes .= ' ge-admin';
    }
    return $classes;
}

add_action( 'admin_enqueue_scripts', 'ge_enqueue_assets' );
function ge_enqueue_assets( $hook ) {
    $paginas_plugin = [ 'toplevel_page_gestionar-empresa', 'gestionar-empresa_page_ge-configuracion' ];
    if ( ! in_array( $hook, $paginas_plugin, true ) ) return;

    wp_enqueue_style( 'sweetalert2', 'https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css', [], null );
    // Tipografía de wmslatam.com: Plus Jakarta Sans (títulos) + Inter (interfaz y cuerpo).
    wp_enqueue_style( 'ge-fonts', 'https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Plus+Jakarta+Sans:wght@500;600;700&display=swap', [], null );
    wp_enqueue_style( 'ge-style', GE_PLUGIN_URL . 'assets/style.css', [ 'sweetalert2', 'ge-fonts' ], GE_VERSION );

    // Ocultar avisos de otros plugins en esta página
    $hide_notices = '
        #wpbody-content .notice,
        #wpbody-content .updated,
        #wpbody-content .update-nag,
        #wpbody-content .is-dismissible,
        .e-notice,
        .elementor-admin-notice,
        [class*="redirection-"] .notice-wrap,
        .rmp-notice,
        div[class*="woocommerce-message"],
        #wpcontent > .wrap > .notice,
        #wpcontent > .wrap > .updated,
        #wpcontent > .wrap > div[class*="notice"] {
            display: none !important;
        }
    ';
    wp_add_inline_style( 'ge-style', $hide_notices );

    if ( $hook === 'toplevel_page_gestionar-empresa' ) {
        wp_enqueue_script( 'sweetalert2', 'https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.all.min.js', [], null, true );
        wp_enqueue_script( 'sheetjs', 'https://cdn.jsdelivr.net/npm/xlsx@0.18.5/dist/xlsx.full.min.js', [], null, true );
        wp_enqueue_script( 'ge-script', GE_PLUGIN_URL . 'assets/script.js', [ 'jquery', 'sweetalert2', 'sheetjs' ], GE_VERSION, true );
        wp_localize_script( 'ge-script', 'GE_DATA', [
            'ajax_url' => admin_url( 'admin-ajax.php' ),
            'nonce'    => wp_create_nonce( 'ge_nonce' ),
            'site_url' => site_url(),
            'restore'  => ge_get_restore_state(),
        ]);
    }
}

