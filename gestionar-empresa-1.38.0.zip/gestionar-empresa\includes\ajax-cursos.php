<?php
/**
 * Cursos de LearnDash asignados a cada usuario: conteo para el listado y
 * detalle con avance para el modal.
 *
 * El conteo del listado se resuelve con UNA consulta para todos los usuarios
 * (ver ge_contar_cursos_por_usuario), porque la pestaña «Usuarios» devuelve el
 * padrón completo de una vez: preguntarle a LearnDash usuario por usuario
 * dispararía cientos de consultas en cada búsqueda.
 *
 * El detalle, en cambio, se calcula solo para el usuario que se abre, y ahí sí
 * se consulta también la API de LearnDash, que incluye los cursos heredados de
 * un grupo. Si el detalle encuentra más cursos que el conteo, el JS corrige el
 * número de la fila con el valor real.
 *
 * @package GestionarEmpresa
 */

if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Número de cursos asignados a cada uno de los usuarios indicados, en una sola
 * consulta. Se cuentan las claves `course_{id}_access_from`, que es el usermeta
 * que LearnDash crea al inscribir a un usuario en un curso.
 *
 * @param array<int,int> $user_ids
 * @return array<int,int> Mapa user_id => número de cursos.
 */
function ge_contar_cursos_por_usuario( array $user_ids ): array {
    $user_ids = array_values( array_unique( array_filter( array_map( 'intval', $user_ids ) ) ) );

    if ( empty( $user_ids ) ) {
        return [];
    }

    global $wpdb;

    $ids_sql = implode( ',', $user_ids );
    $filas   = (array) $wpdb->get_results(
        "SELECT user_id, COUNT(*) AS total
           FROM {$wpdb->usermeta}
          WHERE user_id IN ({$ids_sql})
            AND meta_key REGEXP '^course_[0-9]+_access_from$'
          GROUP BY user_id",
        ARRAY_A
    );

    $conteo = [];
    foreach ( $filas as $fila ) {
        $conteo[ (int) $fila['user_id'] ] = (int) $fila['total'];
    }

    return $conteo;
}

/**
 * IDs de los cursos de un usuario: los del usermeta de inscripción directa más
 * los que devuelve LearnDash (que añade los heredados de un grupo).
 *
 * @return array<int,int>
 */
function ge_get_course_ids_usuario( int $user_id ): array {
    global $wpdb;

    $ids = array_map( 'intval', (array) $wpdb->get_col( $wpdb->prepare(
        "SELECT CAST( SUBSTRING( meta_key, 8, CHAR_LENGTH( meta_key ) - 19 ) AS UNSIGNED )
           FROM {$wpdb->usermeta}
          WHERE user_id = %d
            AND meta_key REGEXP '^course_[0-9]+_access_from$'",
        $user_id
    ) ) );

    if ( function_exists( 'learndash_user_get_enrolled_courses' ) ) {
        $ids = array_merge( $ids, array_map( 'intval', (array) learndash_user_get_enrolled_courses( $user_id ) ) );
    }

    return array_values( array_unique( array_filter( $ids ) ) );
}

/**
 * Porcentaje de avance de un usuario en un curso (0–100).
 *
 * Se prioriza el mismo dato que ve el alumno en su panel
 * (`_sfwd-course_progress`, vía learndash_course_progress). Si no está
 * disponible, se lee ese metadato a mano y, como último recurso, se consulta la
 * tabla de actividad: un curso marcado como completado cuenta como 100%.
 */
function ge_get_progreso_curso( int $user_id, int $course_id ): float {
    if ( function_exists( 'learndash_course_progress' ) ) {
        $ld = learndash_course_progress( [
            'user_id'   => $user_id,
            'course_id' => $course_id,
            'array'     => true,
        ] );

        if ( is_array( $ld ) && isset( $ld['percentage'] ) && (float) $ld['percentage'] > 0 ) {
            return (float) min( 100, max( 0, (float) $ld['percentage'] ) );
        }
    }

    $meta = get_user_meta( $user_id, '_sfwd-course_progress', true );

    if ( is_array( $meta ) && ! empty( $meta[ $course_id ]['total'] ) && (int) $meta[ $course_id ]['total'] > 0 ) {
        $pct = (int) ( $meta[ $course_id ]['completed'] ?? 0 ) / (int) $meta[ $course_id ]['total'] * 100;

        if ( $pct > 0 ) {
            return round( min( 100, max( 0, $pct ) ), 2 );
        }
    }

    global $wpdb;

    $completado = $wpdb->get_var( $wpdb->prepare(
        "SELECT activity_status
           FROM {$wpdb->prefix}learndash_user_activity
          WHERE user_id = %d AND course_id = %d AND activity_type = 'course'
          LIMIT 1",
        $user_id,
        $course_id
    ) );

    return $completado ? 100.0 : 0.0;
}

add_action( 'wp_ajax_ge_get_cursos_usuario', 'ge_ajax_get_cursos_usuario' );
function ge_ajax_get_cursos_usuario() {
    check_ajax_referer( 'ge_nonce', 'nonce' );

    if ( ! current_user_can( 'manage_options' ) ) {
        wp_send_json_error( [ 'message' => 'No tienes permisos.' ], 403 );
    }

    $user_id = intval( $_POST['user_id'] ?? 0 );
    $usuario = $user_id ? get_userdata( $user_id ) : null;

    if ( ! $usuario ) {
        wp_send_json_error( [ 'message' => 'El usuario no existe.' ], 404 );
    }

    $cursos = [];

    foreach ( ge_get_course_ids_usuario( $user_id ) as $course_id ) {
        $titulo = get_the_title( $course_id );

        $cursos[] = [
            'id'     => $course_id,
            'titulo' => $titulo !== '' ? $titulo : 'Curso #' . $course_id,
            'pct'    => round( ge_get_progreso_curso( $user_id, $course_id ), 2 ),
        ];
    }

    usort( $cursos, static function ( $a, $b ) {
        return strcasecmp( $a['titulo'], $b['titulo'] );
    } );

    $total     = count( $cursos );
    $promedio  = $total ? round( array_sum( wp_list_pluck( $cursos, 'pct' ) ) / $total ) : 0;
    $completos = count( array_filter( $cursos, static function ( $c ) { return $c['pct'] >= 100; } ) );

    wp_send_json_success( [
        'cursos'    => $cursos,
        'total'     => $total,
        'promedio'  => $promedio,
        'completos' => $completos,
    ] );
}
