<?php
/**
 * "Entrar como usuario" + "Volver al administrador"
 *
 * Flujo:
 *  1) El admin pulsa "Entrar como usuario" (tab Empresas o Usuarios). El JS envía, además del
 *     user_id, el estado del listado (tab, búsqueda, filtros, paginación).
 *  2) ge_ajax_switch_user() genera un token de un solo uso (60 s) y devuelve la URL de cambio.
 *  3) ge_process_switch() consume el token, abre la sesión del usuario destino y emite una
 *     cookie FIRMADA (HMAC, HttpOnly) + un registro en servidor (transient) que enlazan esa
 *     sesión con el administrador original.
 *  4) Mientras ambos existan y sean válidos, se muestra el botón "Volver al administrador".
 *  5) ge_process_return() valida todo de nuevo (nonce, cookie, registro en servidor, que el
 *     admin siga teniendo manage_options), restaura la sesión del admin y lo devuelve al
 *     listado de origen con sus filtros y página.
 *
 * @package GestionarEmpresa
 */

if ( ! defined( 'ABSPATH' ) ) exit;

const GE_SWITCH_TTL = 8 * HOUR_IN_SECONDS; // vigencia máxima de una sesión "como usuario"

/* ══════════════════════════════════════════════
   Cookie firmada
   ══════════════════════════════════════════════ */

function ge_switch_cookie_name() {
    return 'ge_switch_back_' . COOKIEHASH;
}

function ge_switch_b64_encode( $str ) {
    return rtrim( strtr( base64_encode( $str ), '+/', '-_' ), '=' );
}

function ge_switch_b64_decode( $str ) {
    return base64_decode( strtr( $str, '-_', '+/' ) );
}

function ge_switch_sign( $payload_b64 ) {
    return hash_hmac( 'sha256', $payload_b64, wp_salt( 'auth' ) );
}

function ge_switch_send_cookie( $value, $expires ) {
    $domain = defined( 'COOKIE_DOMAIN' ) && COOKIE_DOMAIN ? COOKIE_DOMAIN : '';
    $path   = defined( 'COOKIEPATH' ) ? COOKIEPATH : '/';

    if ( PHP_VERSION_ID >= 70300 ) {
        setcookie( ge_switch_cookie_name(), $value, [
            'expires'  => $expires,
            'path'     => $path,
            'domain'   => $domain,
            'secure'   => is_ssl(),
            'httponly' => true,
            'samesite' => 'Lax',
        ] );
    } else {
        setcookie( ge_switch_cookie_name(), $value, $expires, $path . '; samesite=Lax', $domain, is_ssl(), true );
    }
}

function ge_switch_set_cookie( $tid, $admin_id, $target_id, $exp ) {
    $payload = ge_switch_b64_encode( wp_json_encode( [
        'tid' => $tid,
        'a'   => (int) $admin_id,
        't'   => (int) $target_id,
        'exp' => (int) $exp,
    ] ) );
    $value = $payload . '.' . ge_switch_sign( $payload );

    ge_switch_send_cookie( $value, 0 ); // cookie de sesión: se borra al cerrar el navegador
    $_COOKIE[ ge_switch_cookie_name() ] = $value;
}

/**
 * Lee la cookie y verifica firma y vigencia. NO verifica el registro en servidor.
 *
 * @return array{tid:string,a:int,t:int,exp:int}|null
 */
function ge_switch_read_cookie() {
    $name = ge_switch_cookie_name();
    if ( empty( $_COOKIE[ $name ] ) || ! is_string( $_COOKIE[ $name ] ) ) return null;

    $parts = explode( '.', wp_unslash( $_COOKIE[ $name ] ) );
    if ( count( $parts ) !== 2 ) return null;

    list( $payload, $sig ) = $parts;
    if ( ! hash_equals( ge_switch_sign( $payload ), $sig ) ) return null;

    $data = json_decode( (string) ge_switch_b64_decode( $payload ), true );
    if ( ! is_array( $data ) || empty( $data['tid'] ) || empty( $data['a'] ) || empty( $data['t'] ) || empty( $data['exp'] ) ) return null;
    if ( (int) $data['exp'] < time() ) return null;
    if ( ! preg_match( '/^[A-Za-z0-9]{32}$/', (string) $data['tid'] ) ) return null;

    return [
        'tid' => (string) $data['tid'],
        'a'   => (int) $data['a'],
        't'   => (int) $data['t'],
        'exp' => (int) $data['exp'],
    ];
}

/**
 * Borra la cookie y el registro en servidor asociados (si los hay).
 */
function ge_switch_clear() {
    $data = ge_switch_read_cookie();
    if ( $data ) {
        delete_transient( 'ge_switchback_' . $data['tid'] );
    }
    ge_switch_send_cookie( '', time() - YEAR_IN_SECONDS );
    unset( $_COOKIE[ ge_switch_cookie_name() ] );
}

/**
 * Devuelve la sesión "como usuario" vigente, o null si NO hay una válida.
 * Condiciones (todas):
 *  - hay un usuario conectado y NO es administrador;
 *  - la cookie está firmada, vigente y apunta a ESTE usuario;
 *  - existe el registro en servidor y coincide con la cookie;
 *  - el administrador original sigue existiendo y conserva manage_options.
 *
 * @return array{tid:string,admin_id:int,target_id:int,state:array}|null
 */
function ge_switch_get_session() {
    $uid = get_current_user_id();
    if ( ! $uid || user_can( $uid, 'manage_options' ) ) return null;

    $cookie = ge_switch_read_cookie();
    if ( ! $cookie || $cookie['t'] !== $uid ) return null;

    $record = get_transient( 'ge_switchback_' . $cookie['tid'] );
    if ( ! is_array( $record )
        || (int) ( $record['admin_id'] ?? 0 )  !== $cookie['a']
        || (int) ( $record['target_id'] ?? 0 ) !== $uid ) {
        return null;
    }

    $admin = get_userdata( $cookie['a'] );
    if ( ! $admin || ! user_can( $admin, 'manage_options' ) ) return null;

    return [
        'tid'       => $cookie['tid'],
        'admin_id'  => $cookie['a'],
        'target_id' => $uid,
        'state'     => isset( $record['state'] ) && is_array( $record['state'] ) ? $record['state'] : [],
    ];
}

/* ══════════════════════════════════════════════
   Estado del listado (tab, filtros, paginación)
   ══════════════════════════════════════════════ */

/**
 * Normaliza y acota el estado del listado. Acepta JSON (string) o array.
 */
function ge_sanitize_return_state( $raw ) {
    if ( is_string( $raw ) ) {
        $raw = strlen( $raw ) <= 2000 ? json_decode( $raw, true ) : [];
    }
    $in = is_array( $raw ) ? $raw : [];

    $get = function ( $key ) use ( $in ) {
        return ( isset( $in[ $key ] ) && is_scalar( $in[ $key ] ) ) ? (string) $in[ $key ] : '';
    };

    $pp = (int) $get( 'pp' );

    return [
        'tab'  => in_array( $get( 'tab' ), [ 'empresas', 'usuarios' ], true ) ? $get( 'tab' ) : 'empresas',
        'q'    => mb_substr( sanitize_text_field( $get( 'q' ) ), 0, 100 ),
        'prog' => in_array( $get( 'prog' ), [ 'wms', 'octagono', 'ambos', 'ninguno' ], true ) ? $get( 'prog' ) : '',
        'emp'  => absint( $get( 'emp' ) ),
        'area' => absint( $get( 'area' ) ),
        'test' => in_array( $get( 'test' ), [ 'con_test', 'sin_test' ], true ) ? $get( 'test' ) : '',
        'pp'   => in_array( $pp, [ 10, 25, 50, 100 ], true ) ? $pp : 25,
        'pg'   => max( 1, absint( $get( 'pg' ) ) ),
    ];
}

/**
 * URL del panel (siempre dentro de wp-admin) con el estado serializado en la query.
 */
function ge_build_return_url( array $state ) {
    $state = ge_sanitize_return_state( $state );
    $args  = [ 'page' => 'gestionar-empresa', 'ge_back' => 1, 'ge_tab' => $state['tab'], 'ge_pp' => $state['pp'], 'ge_pg' => $state['pg'] ];

    if ( $state['q'] !== '' )    $args['ge_q']    = $state['q'];
    if ( $state['prog'] !== '' ) $args['ge_prog'] = $state['prog'];
    if ( $state['emp'] )         $args['ge_emp']  = $state['emp'];
    if ( $state['area'] )        $args['ge_area'] = $state['area'];
    if ( $state['test'] !== '' ) $args['ge_test'] = $state['test'];

    return add_query_arg( $args, admin_url( 'admin.php' ) );
}

/**
 * Estado a restaurar en el panel, leído de la URL. Solo para administradores.
 * Se entrega al JS vía GE_DATA.restore.
 */
function ge_get_restore_state() {
    if ( ! current_user_can( 'manage_options' ) || ! isset( $_GET['ge_back'] ) ) return null;

    $state = ge_sanitize_return_state( [
        'tab'  => $_GET['ge_tab']  ?? '',
        'q'    => isset( $_GET['ge_q'] ) && is_scalar( $_GET['ge_q'] ) ? wp_unslash( $_GET['ge_q'] ) : '',
        'prog' => $_GET['ge_prog'] ?? '',
        'emp'  => $_GET['ge_emp']  ?? '',
        'area' => $_GET['ge_area'] ?? '',
        'test' => $_GET['ge_test'] ?? '',
        'pp'   => $_GET['ge_pp']   ?? '',
        'pg'   => $_GET['ge_pg']   ?? '',
    ] );

    return $state;
}

/* ══════════════════════════════════════════════
   1) Iniciar el cambio (AJAX, solo administradores)
   ══════════════════════════════════════════════ */

add_action( 'wp_ajax_ge_switch_user', 'ge_ajax_switch_user' );
function ge_ajax_switch_user() {
    check_ajax_referer( 'ge_nonce', 'nonce' );

    if ( ! current_user_can( 'manage_options' ) ) {
        wp_send_json_error( [ 'message' => 'No tienes permisos.' ] );
        die();
    }

    $admin_id = get_current_user_id();
    $user_id  = intval( $_POST['user_id'] ?? 0 );
    $user     = $user_id ? get_userdata( $user_id ) : false;

    if ( ! $user ) {
        wp_send_json_error( [ 'message' => 'Usuario no encontrado.' ] );
        die();
    }
    if ( $user_id === $admin_id ) {
        wp_send_json_error( [ 'message' => 'Ya estás usando esta cuenta.' ] );
        die();
    }
    // Nunca se permite "entrar como" una cuenta con privilegios de administración.
    if ( user_can( $user, 'manage_options' ) || is_super_admin( $user_id ) ) {
        wp_send_json_error( [ 'message' => 'No es posible entrar como una cuenta de administrador.' ] );
        die();
    }

    $state = ge_sanitize_return_state( isset( $_POST['return_state'] ) ? wp_unslash( $_POST['return_state'] ) : '' );

    // Token de un solo uso válido por 60 segundos, ligado al administrador que lo generó
    $token = wp_generate_password( 32, false );
    set_transient( 'ge_switch_' . $token, [
        'user_id'  => $user_id,
        'admin_id' => $admin_id,
        'state'    => $state,
    ], 60 );

    wp_send_json_success( [
        'redirect' => add_query_arg( 'ge_switch', $token, home_url( '/' ) ),
    ] );
    die();
}

/* ══════════════════════════════════════════════
   2) Consumir el token y abrir la sesión del usuario
   ══════════════════════════════════════════════ */

add_action( 'init', 'ge_process_switch' );
function ge_process_switch() {
    if ( empty( $_GET['ge_switch'] ) || ! is_string( $_GET['ge_switch'] ) ) return;

    $token = sanitize_text_field( wp_unslash( $_GET['ge_switch'] ) );
    $data  = get_transient( 'ge_switch_' . $token );

    if ( ! is_array( $data ) || empty( $data['user_id'] ) || empty( $data['admin_id'] ) ) {
        wp_die( 'Token inválido o expirado.', 'Error', [ 'response' => 403 ] );
    }

    // Eliminar token inmediatamente (un solo uso)
    delete_transient( 'ge_switch_' . $token );

    $admin_id  = (int) $data['admin_id'];
    $target_id = (int) $data['user_id'];

    // El enlace solo sirve para el administrador que lo generó, con su sesión aún activa.
    if ( get_current_user_id() !== $admin_id || ! user_can( $admin_id, 'manage_options' ) ) {
        wp_die( 'Este enlace solo puede ser usado por el administrador que lo generó.', 'Error', [ 'response' => 403 ] );
    }

    $target = get_userdata( $target_id );
    if ( ! $target ) {
        wp_die( 'Usuario no encontrado.', 'Error', [ 'response' => 404 ] );
    }
    if ( user_can( $target, 'manage_options' ) || is_super_admin( $target_id ) ) {
        wp_die( 'No es posible entrar como una cuenta de administrador.', 'Error', [ 'response' => 403 ] );
    }

    // Registro en servidor + cookie firmada que enlazan la sesión con el admin original
    $tid = wp_generate_password( 32, false, false );
    $exp = time() + GE_SWITCH_TTL;
    set_transient( 'ge_switchback_' . $tid, [
        'admin_id'  => $admin_id,
        'target_id' => $target_id,
        'state'     => ge_sanitize_return_state( $data['state'] ?? [] ),
        'created'   => time(),
    ], GE_SWITCH_TTL );

    wp_destroy_current_session();
    wp_clear_auth_cookie();
    wp_set_current_user( $target_id );
    wp_set_auth_cookie( $target_id, false, is_ssl() ); // cookie de sesión: no persiste tras cerrar el navegador
    ge_switch_set_cookie( $tid, $admin_id, $target_id, $exp );

    error_log( '[Gestionar Empresa] Admin #' . $admin_id . ' entró como usuario #' . $target_id . '.' );

    wp_safe_redirect( home_url( '/mi-cuenta/panel-usuario/' ) );
    exit;
}

/* ══════════════════════════════════════════════
   3) Volver al administrador
   ══════════════════════════════════════════════ */

function ge_switch_return_url() {
    return add_query_arg( [
        'ge_return'   => 1,
        '_gewpnonce'  => wp_create_nonce( 'ge_return_' . get_current_user_id() ),
    ], home_url( '/' ) );
}

add_action( 'init', 'ge_process_return' );
function ge_process_return() {
    if ( empty( $_GET['ge_return'] ) ) return;

    if ( ! is_user_logged_in() ) {
        wp_safe_redirect( wp_login_url() );
        exit;
    }

    $uid   = get_current_user_id();
    $nonce = isset( $_GET['_gewpnonce'] ) && is_string( $_GET['_gewpnonce'] ) ? sanitize_text_field( wp_unslash( $_GET['_gewpnonce'] ) ) : '';

    if ( ! wp_verify_nonce( $nonce, 'ge_return_' . $uid ) ) {
        wp_die( 'El enlace no es válido o expiró. Recarga la página e inténtalo de nuevo.', 'Error', [ 'response' => 403 ] );
    }

    $session = ge_switch_get_session();
    if ( ! $session ) {
        ge_switch_clear();
        wp_die( 'No hay una sesión de administrador que restaurar.', 'Acceso denegado', [ 'response' => 403 ] );
    }

    $admin_id = $session['admin_id'];

    // Uso único: se invalida antes de restaurar la sesión
    ge_switch_clear();

    wp_destroy_current_session();
    wp_clear_auth_cookie();
    wp_set_current_user( $admin_id );
    wp_set_auth_cookie( $admin_id, false, is_ssl() );

    error_log( '[Gestionar Empresa] Admin #' . $admin_id . ' volvió a su cuenta desde el usuario #' . $uid . '.' );

    wp_safe_redirect( ge_build_return_url( $session['state'] ) );
    exit;
}

// Si el usuario cierra sesión, se descarta el vínculo con el administrador.
add_action( 'wp_logout', 'ge_switch_clear' );

// Evita que plugins de caché sirvan una página con el botón (y su nonce) a otra persona.
add_action( 'init', function () {
    if ( ! empty( $_COOKIE[ ge_switch_cookie_name() ] ) && ! defined( 'DONOTCACHEPAGE' ) ) {
        define( 'DONOTCACHEPAGE', true );
    }
}, 1 );

/* ══════════════════════════════════════════════
   4) Botón visible "Volver al administrador"
   ══════════════════════════════════════════════ */

add_action( 'wp_footer',    'ge_render_return_button', 99 );
add_action( 'admin_footer', 'ge_render_return_button', 99 );
function ge_render_return_button() {
    $session = ge_switch_get_session();
    if ( ! $session ) return;

    $user  = wp_get_current_user();
    $admin = get_userdata( $session['admin_id'] );
    $as    = $user->display_name ?: $user->user_login;
    ?>
    <div id="ge-return-admin" role="region" aria-label="Sesión como otro usuario">
        <span class="ge-return-info">Sesión como <strong><?php echo esc_html( $as ); ?></strong></span>
        <a class="ge-return-btn" rel="nofollow"
           href="<?php echo esc_url( ge_switch_return_url() ); ?>"
           title="<?php echo esc_attr( 'Volver a la cuenta de ' . ( $admin ? ( $admin->display_name ?: $admin->user_login ) : 'administrador' ) ); ?>">
            &larr; Volver al administrador
        </a>
    </div>
    <style>
        #ge-return-admin{position:fixed;left:20px;bottom:20px;z-index:2147483000;display:flex;align-items:center;gap:12px;
            background:#423A59;color:#fff;padding:8px 8px 8px 16px;border-radius:8px;
            box-shadow:0 8px 24px rgba(45,38,49,.22);font:500 13px/1.2 Inter,-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Arial,sans-serif;max-width:calc(100vw - 40px);}
        #ge-return-admin .ge-return-info{opacity:.85;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:200px;}
        #ge-return-admin .ge-return-btn{background:#944DE9;color:#fff !important;text-decoration:none !important;
            padding:9px 16px;border-radius:6px;font-weight:600;white-space:nowrap;}
        #ge-return-admin .ge-return-btn:hover{background:#7D3CCB;}
        #ge-return-admin .ge-return-btn:focus-visible{outline:2px solid #fff;outline-offset:2px;}
        @media (max-width:520px){#ge-return-admin .ge-return-info{display:none;}#ge-return-admin{padding:8px;}}
    </style>
    <?php
}
