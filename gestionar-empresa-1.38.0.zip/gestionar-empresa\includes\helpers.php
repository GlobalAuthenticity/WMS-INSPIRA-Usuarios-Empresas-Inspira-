<?php
/**
 * Funciones auxiliares reutilizables
 *
 * @package GestionarEmpresa
 */

if ( ! defined( 'ABSPATH' ) ) exit;

function ge_format_fecha_natural( $mysql_datetime ) {
    if ( empty( $mysql_datetime ) || $mysql_datetime === '0000-00-00 00:00:00' ) return '';
    $meses = [ 1 => 'Ene', 2 => 'Feb', 3 => 'Mar', 4 => 'Abr', 5 => 'May', 6 => 'Jun', 7 => 'Jul', 8 => 'Ago', 9 => 'Sep', 10 => 'Oct', 11 => 'Nov', 12 => 'Dic' ];
    $ts = strtotime( $mysql_datetime );
    if ( ! $ts ) return '';
    return (int) date( 'j', $ts ) . ' ' . $meses[ (int) date( 'n', $ts ) ] . ' ' . date( 'Y', $ts );
}

/**
 * Neutraliza temporalmente CUALQUIER hook de terceros enganchado al hook nativo
 * 'user_register' (Ultimate Member, WooCommerce, LearnDash, etc.) que pueda hacer
 * auto-login y/o redirect+exit al crear un usuario vía wp_insert_user(). Sin esto,
 * un plugin ajeno puede matar la ejecución del script a mitad de camino, antes de
 * que el plugin termine de guardar usermeta, vincular áreas o notificar por email.
 * Devuelve el estado original de los hooks para restaurarlo con ge_restore_user_register_hooks().
 */
function ge_suspend_user_register_hooks() {
    global $wp_filter;
    $saved = isset( $wp_filter['user_register'] ) ? $wp_filter['user_register'] : null;
    remove_all_actions( 'user_register' );
    remove_all_actions( 'woocommerce_created_customer' );
    remove_all_actions( 'woocommerce_new_customer_data' );
    add_filter( 'woocommerce_registration_auth_new_customer', '__return_false', 9999 );
    add_filter( 'woocommerce_reg_field_set_password',         '__return_false', 9999 );
    return $saved;
}

function ge_restore_user_register_hooks( $saved ) {
    global $wp_filter;
    if ( $saved !== null ) {
        $wp_filter['user_register'] = $saved;
    }
}

/**
 * Restaura por completo la sesión del administrador (PHP + cookie real del
 * navegador) si algún plugin de terceros la cambió durante wp_insert_user().
 * wp_set_current_user() por sí solo NO alcanza: solo corrige el contexto de
 * ESTA petición, pero no revierte una cookie de auth que ya se haya enviado
 * para el usuario recién creado.
 */
function ge_restore_admin_session( $admin_id ) {
    if ( get_current_user_id() !== $admin_id ) {
        wp_clear_auth_cookie();
        wp_set_current_user( $admin_id );
        wp_set_auth_cookie( $admin_id, true );
    }
}

function ge_random_password( $length = 8 ) {
    $chars = 'abcdefghjkmnpqrstuvwxyzABCDEFGHJKMNPQRSTUVWXYZ23456789!@#';
    $pass  = '';
    for ( $i = 0; $i < $length; $i++ ) {
        $pass .= $chars[ random_int( 0, strlen( $chars ) - 1 ) ];
    }
    return $pass;
}

function ge_ensure_role_exists( $role_slug, $role_name ) {
    if ( ! get_role( $role_slug ) ) {
        $subscriber = get_role( 'subscriber' );
        add_role( $role_slug, $role_name, $subscriber ? $subscriber->capabilities : [] );
    }
}

function ge_send_welcome_notification( $nombre, $email, $password ) {
    $site_name = get_bloginfo( 'name' );
    $login_url = site_url( 'wp-login.php' );
    $subject   = '¡Bienvenido/a a ' . $site_name . '! Tus credenciales de acceso';
    $headers   = [ 'Content-Type: text/html; charset=UTF-8' ];
    $year      = date( 'Y' );

    $body = <<<HTML
<!DOCTYPE html>
<html lang="es">
<head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"></head>
<body style="margin:0;padding:0;background:#F7F7F7;font-family:Inter,Arial,Helvetica,sans-serif;">
<table width="100%" cellpadding="0" cellspacing="0" style="background:#F7F7F7;padding:40px 20px;">
  <tr><td align="center">
    <table width="600" cellpadding="0" cellspacing="0" style="max-width:600px;width:100%;background:#ffffff;border-radius:20px;overflow:hidden;border:1px solid #D1D5DB;">
      <tr>
        <td style="background:#423A59;padding:40px 48px;text-align:center;">
          <div style="display:inline-block;background:rgba(255,255,255,.14);border-radius:50%;width:60px;height:60px;line-height:60px;font-size:28px;font-weight:700;color:#fff;margin-bottom:16px;">A</div>
          <h1 style="margin:0;color:#fff;font-size:26px;font-weight:700;">¡Bienvenido/a!</h1>
          <p style="margin:8px 0 0;color:rgba(255,255,255,.85);font-size:15px;">Tu cuenta ha sido creada exitosamente en {$site_name}</p>
        </td>
      </tr>
      <tr>
        <td style="padding:40px 48px;">
          <p style="margin:0 0 16px;color:#2D2631;font-size:16px;">Hola <strong>{$nombre}</strong>,</p>
          <p style="margin:0 0 28px;color:#6B6672;font-size:15px;line-height:1.6;">
            Tu empresa ha sido registrada. A continuación tus credenciales de acceso.
            Te recomendamos cambiar tu contraseña tras el primer ingreso.
          </p>
          <table width="100%" cellpadding="0" cellspacing="0"
                 style="background:#F0EADE;border:1px solid #D1D5DB;border-radius:16px;margin-bottom:32px;">
            <tr><td style="padding:24px 28px;">
              <p style="margin:0 0 12px;font-size:11px;font-weight:600;letter-spacing:.08em;text-transform:uppercase;color:#7A3DCB;">TUS CREDENCIALES</p>
              <table width="100%" cellpadding="0" cellspacing="0">
                <tr>
                  <td style="padding:10px 0;border-bottom:1px solid #D1D5DB;">
                    <span style="font-size:13px;color:#6B6672;display:block;margin-bottom:2px;">Correo / Usuario</span>
                    <strong style="font-size:15px;color:#2D2631;">{$email}</strong>
                  </td>
                </tr>
                <tr>
                  <td style="padding:10px 0;">
                    <span style="font-size:13px;color:#6B6672;display:block;margin-bottom:2px;">Contraseña</span>
                    <strong style="font-size:15px;color:#2D2631;font-family:monospace;background:#fff;padding:4px 10px;border-radius:8px;border:1px solid #D1D5DB;">{$password}</strong>
                  </td>
                </tr>
              </table>
            </td></tr>
          </table>
          <table width="100%" cellpadding="0" cellspacing="0">
            <tr><td align="center" style="padding-bottom:32px;">
              <a href="{$login_url}"
                 style="display:inline-block;background:#944DE9;
                        color:#fff;text-decoration:none;font-size:15px;font-weight:600;
                        padding:14px 36px;border-radius:40px;">
                Iniciar sesión &rarr;
              </a>
            </td></tr>
          </table>
          <p style="margin:0;color:#6B6672;font-size:13px;line-height:1.6;text-align:center;">
            Si tienes dudas contáctanos respondiendo este correo.<br>
            No compartas tus credenciales con nadie.
          </p>
        </td>
      </tr>
      <tr>
        <td style="background:#F7F7F7;padding:20px 48px;text-align:center;border-top:1px solid #ECEAEF;">
          <p style="margin:0;font-size:12px;color:#6B6672;">&copy; {$year} {$site_name}. Todos los derechos reservados.</p>
        </td>
      </tr>
    </table>
  </td></tr>
</table>
</body>
</html>
HTML;

    return wp_mail( $email, $subject, $body, $headers );
}

/**
 * Carga en UNA sola consulta (get_users con 'include') todos los usuarios
 * cuyos IDs se pasan, evitando el patrón N+1 de llamar get_userdata() dentro
 * de un foreach. Devuelve un mapa [user_id => WP_User], omitiendo IDs que ya
 * no correspondan a un usuario existente.
 *
 * @param int[] $user_ids
 * @return array<int, WP_User>
 */
function ge_get_users_map( array $user_ids ) {
    $user_ids = array_values( array_unique( array_map( 'intval', $user_ids ) ) );
    $user_ids = array_filter( $user_ids );
    if ( empty( $user_ids ) ) return [];

    $users = get_users( [
        'include'     => $user_ids,
        'orderby'     => 'include', // conserva un orden estable, no afecta el resultado (se indexa por ID)
        'number'      => count( $user_ids ),
        'fields'      => 'all_with_meta',
    ] );

    $map = [];
    foreach ( $users as $user ) {
        $map[ (int) $user->ID ] = $user;
    }
    return $map;
}
