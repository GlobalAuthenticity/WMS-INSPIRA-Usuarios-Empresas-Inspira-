<?php
/**
 * "Actualizar correos" — actualización masiva de correos electrónicos de
 * usuarios mediante un archivo Excel, con validación previa completa antes
 * de tocar la base de datos.
 *
 * @package GestionarEmpresa
 */

if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Meta keys que se consideran "perfil completo". Si un usuario tiene TODOS
 * estos campos diligenciados (con valor no vacío), NO se le puede cambiar
 * el correo. Si le falta al menos uno, sí se permite la actualización.
 */
const GE_EMAIL_UPDATE_PROFILE_KEYS = [
    'first_name', 'last_name', 'user_age', 'user_gender',
    'country', 'phone_number', 'user_position',
];

/**
 * Valida una sola fila (correo_actual, correo_nuevo) contra las 4 reglas del
 * spec, en orden. Devuelve ['estado' => 'ok'|'error', 'motivo' => string].
 * Reutilizada tanto por el paso de validación previa como por la re-validación
 * de seguridad justo antes de ejecutar cada actualización individual.
 */
function ge_validate_email_update_row( $correo_actual, $correo_nuevo ) {
    if ( ! is_email( $correo_actual ) || ! is_email( $correo_nuevo ) ) {
        return [ 'estado' => 'error', 'motivo' => 'Formato de correo inválido.' ];
    }

    $user_actual = get_user_by( 'email', $correo_actual );
    if ( ! $user_actual ) {
        return [ 'estado' => 'error', 'motivo' => 'El correo actual no se encuentra registrado en WordPress.' ];
    }

    if ( strtolower( $correo_actual ) !== strtolower( $correo_nuevo ) ) {
        $user_nuevo = get_user_by( 'email', $correo_nuevo );
        if ( $user_nuevo ) {
            return [ 'estado' => 'error', 'motivo' => 'El nuevo correo ya se encuentra registrado.' ];
        }
    }

    $campos_llenos = 0;
    foreach ( GE_EMAIL_UPDATE_PROFILE_KEYS as $key ) {
        $value = get_user_meta( $user_actual->ID, $key, true );
        if ( '' !== trim( (string) $value ) ) {
            $campos_llenos++;
        }
    }
    if ( $campos_llenos === count( GE_EMAIL_UPDATE_PROFILE_KEYS ) ) {
        return [ 'estado' => 'error', 'motivo' => 'El usuario ya tiene el perfil completo (todos los campos requeridos están diligenciados).' ];
    }

    return [ 'estado' => 'ok', 'motivo' => 'Validación exitosa.' ];
}

/**
 * Paso de validación previa: recibe TODAS las filas del Excel ya mapeadas
 * (correo_actual / correo_nuevo) y devuelve el resultado de las 4 validaciones
 * por fila, sin tocar la base de datos.
 */
add_action( 'wp_ajax_ge_validate_email_update', 'ge_ajax_validate_email_update' );
function ge_ajax_validate_email_update() {
    check_ajax_referer( 'ge_nonce', 'nonce' );

    if ( ! current_user_can( 'manage_options' ) ) {
        wp_send_json_error( [ 'message' => 'Sin permisos.' ] );
        die();
    }

    $rows = json_decode( wp_unslash( $_POST['rows'] ?? '' ), true );
    if ( ! is_array( $rows ) || empty( $rows ) ) {
        wp_send_json_error( [ 'message' => 'No hay registros para validar.' ] );
        die();
    }

    $seen   = [];
    $result = [];

    foreach ( $rows as $row ) {
        $correo_actual = sanitize_email( trim( strtolower( (string) ( $row['correo_actual'] ?? '' ) ) ) );
        $correo_nuevo  = sanitize_email( trim( strtolower( (string) ( $row['correo_nuevo'] ?? '' ) ) ) );

        if ( '' === $correo_actual && '' === $correo_nuevo ) {
            continue; // fila vacía del Excel, se ignora silenciosamente
        }

        if ( isset( $seen[ $correo_actual ] ) ) {
            $result[] = [
                'correo_actual' => $correo_actual,
                'correo_nuevo'  => $correo_nuevo,
                'estado'        => 'error',
                'motivo'        => 'Registro duplicado en el archivo.',
            ];
            continue;
        }
        $seen[ $correo_actual ] = true;

        $validation = ge_validate_email_update_row( $correo_actual, $correo_nuevo );
        $result[] = [
            'correo_actual' => $correo_actual,
            'correo_nuevo'  => $correo_nuevo,
            'estado'        => $validation['estado'],
            'motivo'        => $validation['motivo'],
        ];
    }

    wp_send_json_success( [ 'items' => $result, 'total' => count( $result ) ] );
    die();
}

/**
 * Ejecuta la actualización de UN solo registro. El front-end llama a este
 * endpoint una vez por cada fila válida, para poder mostrar progreso en
 * tiempo real y para que un fallo puntual no detenga el resto.
 */
add_action( 'wp_ajax_ge_update_email_one', 'ge_ajax_update_email_one' );
function ge_ajax_update_email_one() {
    check_ajax_referer( 'ge_nonce', 'nonce' );

    if ( ! current_user_can( 'manage_options' ) ) {
        wp_send_json_error( [ 'message' => 'Sin permisos.' ] );
        die();
    }

    $correo_actual = isset( $_POST['correo_actual'] ) ? sanitize_email( trim( strtolower( wp_unslash( $_POST['correo_actual'] ) ) ) ) : '';
    $correo_nuevo  = isset( $_POST['correo_nuevo'] )  ? sanitize_email( trim( strtolower( wp_unslash( $_POST['correo_nuevo'] ) ) ) )  : '';

    // Re-validar justo antes de ejecutar (defensa en profundidad ante condiciones de carrera:
    // otro proceso pudo haber tomado el correo nuevo, o editado el perfil, entre el paso de
    // validación previa y este momento).
    $validation = ge_validate_email_update_row( $correo_actual, $correo_nuevo );
    if ( 'ok' !== $validation['estado'] ) {
        wp_send_json_error( [
            'correo_actual' => $correo_actual,
            'correo_nuevo'  => $correo_nuevo,
            'message'       => $validation['motivo'],
        ] );
        die();
    }

    $user = get_user_by( 'email', $correo_actual );

    $update_args = [
        'ID'         => $user->ID,
        'user_email' => $correo_nuevo,
    ];
    // Solo se actualiza el user_login si el sistema lo usaba igual al correo actual
    // (patrón usado por este plugin al crear empresas/usuarios); si el login es distinto
    // del correo, se respeta tal cual y no se toca.
    if ( strtolower( $user->user_login ) === strtolower( $correo_actual ) ) {
        $update_args['user_login'] = $correo_nuevo;
    }

    $updated = wp_update_user( $update_args );

    if ( is_wp_error( $updated ) ) {
        wp_send_json_error( [
            'correo_actual' => $correo_actual,
            'correo_nuevo'  => $correo_nuevo,
            'message'       => 'Error durante la actualización: ' . $updated->get_error_message(),
        ] );
        die();
    }

    wp_send_json_success( [
        'correo_actual' => $correo_actual,
        'correo_nuevo'  => $correo_nuevo,
        'message'       => 'Actualizado correctamente.',
    ] );
    die();
}
