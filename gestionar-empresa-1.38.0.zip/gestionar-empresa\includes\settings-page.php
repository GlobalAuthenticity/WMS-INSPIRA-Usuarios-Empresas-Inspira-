<?php
/**
 * Página de Configuración (credenciales de integraciones externas)
 *
 * @package GestionarEmpresa
 */

if ( ! defined( 'ABSPATH' ) ) exit;

add_action( 'admin_init', 'ge_register_settings' );
function ge_register_settings() {
    register_setting( 'ge_settings_group', 'ge_integraciones', [
        'type'              => 'array',
        'sanitize_callback' => 'ge_sanitize_settings',
        'default'           => [],
    ] );
}

function ge_sanitize_settings( $input ) {
    $input = is_array( $input ) ? $input : [];
    return [
        'wms_api_url'          => isset( $input['wms_api_url'] )          ? esc_url_raw( trim( $input['wms_api_url'] ) )          : '',
        'wms_api_token'        => isset( $input['wms_api_token'] )        ? sanitize_text_field( trim( $input['wms_api_token'] ) ) : '',
        'webhook_creado'       => isset( $input['webhook_creado'] )       ? esc_url_raw( trim( $input['webhook_creado'] ) )       : '',
        'webhook_existente'    => isset( $input['webhook_existente'] )    ? esc_url_raw( trim( $input['webhook_existente'] ) )    : '',
        'octagono_verify_url'  => isset( $input['octagono_verify_url'] )  ? esc_url_raw( trim( $input['octagono_verify_url'] ) )  : '',
        'octagono_verify_token'=> isset( $input['octagono_verify_token'] )? sanitize_text_field( trim( $input['octagono_verify_token'] ) ) : '',
        'wms_verify_url'       => isset( $input['wms_verify_url'] )       ? esc_url_raw( trim( $input['wms_verify_url'] ) )       : '',
        'wms_verify_token'     => isset( $input['wms_verify_token'] )     ? sanitize_text_field( trim( $input['wms_verify_token'] ) ) : '',
    ];
}

/**
 * Devuelve un valor de integración: prioriza lo guardado en Configuración,
 * y si está vacío cae de vuelta a la constante definida en el archivo (compatibilidad).
 */
function ge_get_integration_setting( $key ) {
    $opts = get_option( 'ge_integraciones', [] );
    if ( ! empty( $opts[ $key ] ) ) {
        return $opts[ $key ];
    }
    $fallback_map = [
        'wms_api_url'           => defined( 'GE_WMS_API_URL' )           ? GE_WMS_API_URL           : '',
        'wms_api_token'         => defined( 'GE_WMS_API_TOKEN' )         ? GE_WMS_API_TOKEN         : '',
        'webhook_creado'        => defined( 'GE_WEBHOOK_CREADO' )        ? GE_WEBHOOK_CREADO        : '',
        'webhook_existente'     => defined( 'GE_WEBHOOK_EXISTENTE' )     ? GE_WEBHOOK_EXISTENTE     : '',
        'octagono_verify_url'   => defined( 'GE_OCTAGONO_VERIFY_URL' )   ? GE_OCTAGONO_VERIFY_URL   : '',
        'octagono_verify_token' => defined( 'GE_OCTAGONO_VERIFY_TOKEN' ) ? GE_OCTAGONO_VERIFY_TOKEN : '',
        'wms_verify_url'        => defined( 'GE_WMS_VERIFY_URL' )        ? GE_WMS_VERIFY_URL        : '',
        'wms_verify_token'      => defined( 'GE_WMS_VERIFY_TOKEN' )      ? GE_WMS_VERIFY_TOKEN      : '',
    ];
    return isset( $fallback_map[ $key ] ) ? $fallback_map[ $key ] : '';
}

function ge_render_settings_page() {
    $val = function ( $key ) {
        return esc_attr( ge_get_integration_setting( $key ) );
    };
    ?>
    <div id="ge-app">
        <div class="ge-header">
            <div class="ge-header-left">
                <div class="ge-logo-mark">A</div>
                <div>
                    <h1 class="ge-title">Configuración de Integraciones</h1>
                    <p class="ge-subtitle">API de WMS Latam y webhooks de notificación de Inspira</p>
                </div>
            </div>
        </div>

        <?php if ( isset( $_GET['settings-updated'] ) && $_GET['settings-updated'] ) : ?>
            <div class="ge-notice success" style="display:block;margin-bottom:20px;">Configuración guardada correctamente.</div>
        <?php endif; ?>

        <?php
        $missing_labels = [
            'wms_api_url'           => 'URL de creación de usuario (WMS)',
            'wms_api_token'         => 'Token de creación de usuario (WMS)',
            'webhook_creado'        => 'Webhook — usuario creado (Inspira)',
            'webhook_existente'     => 'Webhook — usuario ya existía (Inspira)',
            'octagono_verify_url'   => 'URL de verificación (Octágono)',
            'octagono_verify_token' => 'Token de verificación (Octágono)',
            'wms_verify_url'        => 'URL de verificación (WMS)',
            'wms_verify_token'      => 'Token de verificación (WMS)',
        ];
        $missing = [];
        foreach ( $missing_labels as $key => $label ) {
            if ( '' === ge_get_integration_setting( $key ) ) $missing[] = $label;
        }
        ?>
        <?php if ( ! empty( $missing ) ) : ?>
            <div class="ge-notice error" style="display:block;margin-bottom:20px;">
                <strong>Configuración incompleta.</strong> Faltan por completar: <?php echo esc_html( implode( ', ', $missing ) ); ?>.
                Las llamadas correspondientes no se ejecutarán hasta que se guarden estos valores aquí.
            </div>
        <?php endif; ?>

        <form method="post" action="options.php" class="ge-settings-form">
            <?php settings_fields( 'ge_settings_group' ); ?>

            <div class="ge-table-wrap ge-settings-card">
                <h2 class="ge-section-title">API de creación de usuario — WMS Latam</h2>
                <p class="ge-section-desc">Se llama automáticamente después de crear cada empresa.</p>

                <div class="ge-form-grid">
                    <div class="ge-field ge-field-full">
                        <label>URL del endpoint</label>
                        <input type="url" name="ge_integraciones[wms_api_url]" value="<?php echo $val('wms_api_url'); ?>" placeholder="https://wmslatam.com/wp-json/wms/v1/create-user">
                    </div>
                    <div class="ge-field ge-field-full">
                        <label>Bearer Token</label>
                        <div class="ge-token-wrap">
                            <input type="password" class="ge-token-input" name="ge_integraciones[wms_api_token]" value="<?php echo $val('wms_api_token'); ?>" placeholder="Token de autorización">
                            <button type="button" class="ge-token-toggle ge-btn-ghost">Ver</button>
                        </div>
                    </div>
                </div>
            </div>

            <div class="ge-table-wrap ge-settings-card">
                <h2 class="ge-section-title">Webhooks de notificación — Inspira</h2>
                <p class="ge-section-desc">Se elige uno u otro según la respuesta de la API de WMS Latam (<code>data.created</code>).</p>

                <div class="ge-form-grid">
                    <div class="ge-field ge-field-full">
                        <label>Webhook — usuario creado (data.created = true)</label>
                        <input type="url" name="ge_integraciones[webhook_creado]" value="<?php echo $val('webhook_creado'); ?>" placeholder="https://api.efrenmartinezortiz-ia.com/webhook/creacion-inspira-wms">
                    </div>
                    <div class="ge-field ge-field-full">
                        <label>Webhook — usuario ya existía (data.created = false)</label>
                        <input type="url" name="ge_integraciones[webhook_existente]" value="<?php echo $val('webhook_existente'); ?>" placeholder="https://api.efrenmartinezortiz-ia.com/webhook/creacion-inspira">
                    </div>
                </div>
            </div>

            <div class="ge-table-wrap ge-settings-card">
                <h2 class="ge-section-title">Verificación de programas — "Refrescar programas"</h2>
                <p class="ge-section-desc">Se usan al refrescar los programas de una empresa y sus integrantes (columna Programas → Acciones → Refrescar programas).</p>

                <div class="ge-form-grid">
                    <div class="ge-field ge-field-full">
                        <label>URL de verificación — Octágono</label>
                        <input type="url" name="ge_integraciones[octagono_verify_url]" value="<?php echo $val('octagono_verify_url'); ?>" placeholder="https://octagono.wmslatam.com/wp-json/octagono-api/v1/verificar-usuario">
                    </div>
                    <div class="ge-field ge-field-full">
                        <label>Bearer Token — Octágono</label>
                        <div class="ge-token-wrap">
                            <input type="password" class="ge-token-input" name="ge_integraciones[octagono_verify_token]" value="<?php echo $val('octagono_verify_token'); ?>" placeholder="Token de autorización">
                            <button type="button" class="ge-token-toggle ge-btn-ghost">Ver</button>
                        </div>
                    </div>
                    <div class="ge-field ge-field-full">
                        <label>URL de verificación — WMS</label>
                        <input type="url" name="ge_integraciones[wms_verify_url]" value="<?php echo $val('wms_verify_url'); ?>" placeholder="https://wmslatam.com/wp-json/wms-api/v1/verificar-usuario">
                    </div>
                    <div class="ge-field ge-field-full">
                        <label>Bearer Token — WMS</label>
                        <div class="ge-token-wrap">
                            <input type="password" class="ge-token-input" name="ge_integraciones[wms_verify_token]" value="<?php echo $val('wms_verify_token'); ?>" placeholder="Token de autorización">
                            <button type="button" class="ge-token-toggle ge-btn-ghost">Ver</button>
                        </div>
                    </div>
                </div>
            </div>

            <div class="ge-settings-actions">
                <?php submit_button( 'Guardar configuración', 'ge-btn-primary', 'submit', false ); ?>
            </div>
        </form>
    </div>
    <script>
    document.addEventListener('DOMContentLoaded', function () {
        document.querySelectorAll('.ge-token-toggle').forEach(function (toggle) {
            var input = toggle.previousElementSibling;
            if (!input) return;
            toggle.addEventListener('click', function () {
                var isPass = input.getAttribute('type') === 'password';
                input.setAttribute('type', isPass ? 'text' : 'password');
                toggle.textContent = isPass ? 'Ocultar' : 'Ver';
            });
        });
    });
    </script>
    <?php
}

