<?php
/**
 * "Ver WP_USERMETA" — administración directa de la tabla wp_usermeta
 * para un usuario específico (empresa o suscriptor), con listado paginado
 * y búsqueda por meta_key/meta_value, y CRUD completo por umeta_id.
 *
 * @package GestionarEmpresa
 */

if ( ! defined( 'ABSPATH' ) ) exit;

const GE_USERMETA_PER_PAGE_OPTIONS = [ 10, 25, 50, 100 ];

/**
 * Paso 1: listado paginado + búsqueda, consultado directamente contra
 * $wpdb->usermeta (no usa get_user_meta(), que trae TODO el meta en memoria).
 */
add_action( 'wp_ajax_ge_list_usermeta', 'ge_ajax_list_usermeta' );
function ge_ajax_list_usermeta() {
    check_ajax_referer( 'ge_nonce', 'nonce' );

    if ( ! current_user_can( 'manage_options' ) ) {
        wp_send_json_error( [ 'message' => 'Sin permisos.' ] );
        die();
    }

    $user_id = isset( $_POST['user_id'] ) ? intval( $_POST['user_id'] ) : 0;
    if ( ! $user_id || ! get_userdata( $user_id ) ) {
        wp_send_json_error( [ 'message' => 'Usuario no válido.' ] );
        die();
    }

    $search   = isset( $_POST['search'] ) ? sanitize_text_field( wp_unslash( $_POST['search'] ) ) : '';
    $page     = isset( $_POST['page'] ) ? max( 1, intval( $_POST['page'] ) ) : 1;
    $per_page = isset( $_POST['per_page'] ) ? intval( $_POST['per_page'] ) : 25;
    if ( ! in_array( $per_page, GE_USERMETA_PER_PAGE_OPTIONS, true ) ) {
        $per_page = 25;
    }
    $offset = ( $page - 1 ) * $per_page;

    global $wpdb;

    $where_sql = $wpdb->prepare( 'user_id = %d', $user_id );
    if ( '' !== $search ) {
        $like = '%' . $wpdb->esc_like( $search ) . '%';
        $where_sql .= $wpdb->prepare( ' AND ( meta_key LIKE %s OR meta_value LIKE %s )', $like, $like );
    }

    $total = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->usermeta} WHERE {$where_sql}" );

    // $per_page y $offset ya están forzados a enteros arriba (whitelist / intval), es seguro interpolarlos directo.
    $rows = $wpdb->get_results(
        "SELECT umeta_id, meta_key, meta_value FROM {$wpdb->usermeta} WHERE {$where_sql} ORDER BY umeta_id DESC LIMIT {$per_page} OFFSET {$offset}",
        ARRAY_A
    );

    $items = array_map( function ( $row ) {
        return [
            'meta_id'    => (int) $row['umeta_id'],
            'meta_key'   => (string) $row['meta_key'],
            'meta_value' => (string) $row['meta_value'],
        ];
    }, $rows );

    wp_send_json_success( [
        'items'      => $items,
        'total'      => $total,
        'page'       => $page,
        'per_page'   => $per_page,
        'total_pages'=> $per_page > 0 ? (int) ceil( $total / $per_page ) : 1,
    ] );
    die();
}

/**
 * Crear un nuevo registro de meta para el usuario (siempre inserta una fila
 * nueva, incluso si ya existe otra con la misma meta_key — así es como
 * funciona wp_usermeta de forma nativa).
 */
add_action( 'wp_ajax_ge_add_usermeta', 'ge_ajax_add_usermeta' );
function ge_ajax_add_usermeta() {
    check_ajax_referer( 'ge_nonce', 'nonce' );

    if ( ! current_user_can( 'manage_options' ) ) {
        wp_send_json_error( [ 'message' => 'Sin permisos.' ] );
        die();
    }

    $user_id    = isset( $_POST['user_id'] ) ? intval( $_POST['user_id'] ) : 0;
    $meta_key   = isset( $_POST['meta_key'] ) ? sanitize_text_field( wp_unslash( $_POST['meta_key'] ) ) : '';
    $meta_value = isset( $_POST['meta_value'] ) ? sanitize_textarea_field( wp_unslash( $_POST['meta_value'] ) ) : '';

    if ( ! $user_id || ! get_userdata( $user_id ) ) {
        wp_send_json_error( [ 'message' => 'Usuario no válido.' ] );
        die();
    }
    if ( '' === trim( $meta_key ) ) {
        wp_send_json_error( [ 'message' => 'El Meta Key es obligatorio.' ] );
        die();
    }

    // $unique = false: siempre agrega una fila nueva, no actualiza una existente con la misma key.
    $meta_id = add_user_meta( $user_id, $meta_key, $meta_value, false );

    if ( ! $meta_id ) {
        wp_send_json_error( [ 'message' => 'No se pudo crear el registro.' ] );
        die();
    }

    wp_send_json_success( [ 'message' => 'Registro creado correctamente.', 'meta_id' => $meta_id ] );
    die();
}

/**
 * Editar un registro puntual identificado por su umeta_id (permite además
 * renombrar la meta_key del registro, no solo cambiar el valor).
 */
add_action( 'wp_ajax_ge_edit_usermeta', 'ge_ajax_edit_usermeta' );
function ge_ajax_edit_usermeta() {
    check_ajax_referer( 'ge_nonce', 'nonce' );

    if ( ! current_user_can( 'manage_options' ) ) {
        wp_send_json_error( [ 'message' => 'Sin permisos.' ] );
        die();
    }

    $meta_id    = isset( $_POST['meta_id'] ) ? intval( $_POST['meta_id'] ) : 0;
    $meta_key   = isset( $_POST['meta_key'] ) ? sanitize_text_field( wp_unslash( $_POST['meta_key'] ) ) : '';
    $meta_value = isset( $_POST['meta_value'] ) ? sanitize_textarea_field( wp_unslash( $_POST['meta_value'] ) ) : '';

    if ( ! $meta_id ) {
        wp_send_json_error( [ 'message' => 'Registro no válido.' ] );
        die();
    }
    if ( '' === trim( $meta_key ) ) {
        wp_send_json_error( [ 'message' => 'El Meta Key es obligatorio.' ] );
        die();
    }

    global $wpdb;
    $exists = $wpdb->get_var( $wpdb->prepare( "SELECT umeta_id FROM {$wpdb->usermeta} WHERE umeta_id = %d", $meta_id ) );
    if ( ! $exists ) {
        wp_send_json_error( [ 'message' => 'El registro ya no existe (puede que otra persona lo haya eliminado).' ] );
        die();
    }

    // update_metadata_by_mid() devuelve false tanto si falla como si el valor no cambió;
    // como ya confirmamos que el registro existe, tratamos cualquier resultado como éxito.
    update_metadata_by_mid( 'user', $meta_id, $meta_value, $meta_key );

    wp_send_json_success( [ 'message' => 'Registro actualizado correctamente.' ] );
    die();
}

/**
 * Eliminar un único registro por su umeta_id.
 */
add_action( 'wp_ajax_ge_delete_usermeta', 'ge_ajax_delete_usermeta' );
function ge_ajax_delete_usermeta() {
    check_ajax_referer( 'ge_nonce', 'nonce' );

    if ( ! current_user_can( 'manage_options' ) ) {
        wp_send_json_error( [ 'message' => 'Sin permisos.' ] );
        die();
    }

    $meta_id = isset( $_POST['meta_id'] ) ? intval( $_POST['meta_id'] ) : 0;
    if ( ! $meta_id ) {
        wp_send_json_error( [ 'message' => 'Registro no válido.' ] );
        die();
    }

    $deleted = delete_metadata_by_mid( 'user', $meta_id );
    if ( ! $deleted ) {
        wp_send_json_error( [ 'message' => 'No se pudo eliminar el registro (puede que ya no exista).' ] );
        die();
    }

    wp_send_json_success( [ 'message' => 'Registro eliminado correctamente.' ] );
    die();
}
