<?php
/**
 * Sincronización externa: WMS Latam, webhooks Inspira, verificación Octágono/WMS
 *
 * @package GestionarEmpresa
 */

if ( ! defined( 'ABSPATH' ) ) exit;

add_action( 'wp_ajax_ge_get_empresa_members', 'ge_ajax_get_empresa_members' );
function ge_ajax_get_empresa_members() {
    check_ajax_referer( 'ge_nonce', 'nonce' );

    if ( ! current_user_can( 'manage_options' ) ) {
        wp_send_json_error( [ 'message' => 'Sin permisos.' ] );
        die();
    }

    $empresa_id = isset( $_POST['empresa_id'] ) ? intval( $_POST['empresa_id'] ) : 0;
    if ( ! $empresa_id || ! get_userdata( $empresa_id ) ) {
        wp_send_json_error( [ 'message' => 'Empresa no válida.' ] );
        die();
    }

    global $wpdb;
    $tabla_areas   = $wpdb->prefix . 'areas';
    $tabla_members = $wpdb->prefix . 'user_members';

    // 1) El administrador de la empresa
    $user_ids = [ $empresa_id ];

    // 2) Áreas de la empresa
    $area_ids = $wpdb->get_col( $wpdb->prepare( "SELECT id FROM {$tabla_areas} WHERE grupo_id = %d", $empresa_id ) );

    // 3) Integrantes de esas áreas
    if ( ! empty( $area_ids ) ) {
        $ids_sql    = implode( ',', array_map( 'intval', $area_ids ) );
        $member_ids = $wpdb->get_col( "SELECT DISTINCT user_id FROM {$tabla_members} WHERE area_id IN ({$ids_sql})" );
        foreach ( $member_ids as $mid ) {
            $user_ids[] = (int) $mid;
        }
    }

    // Deduplicar por user_id y luego por correo (por si dos IDs comparten el mismo email)
    $user_ids     = array_values( array_unique( array_map( 'intval', $user_ids ) ) );
    $users_map    = ge_get_users_map( $user_ids ); // 1 sola consulta en vez de N
    $seen_emails  = [];
    $members      = [];

    foreach ( $user_ids as $uid ) {
        $u = $users_map[ $uid ] ?? null;
        if ( ! $u || empty( $u->user_email ) ) continue;
        $key = strtolower( $u->user_email );
        if ( isset( $seen_emails[ $key ] ) ) continue;
        $seen_emails[ $key ] = true;
        $members[] = [ 'user_id' => $uid, 'email' => $u->user_email ];
    }

    wp_send_json_success( [ 'members' => $members, 'total' => count( $members ) ] );
    die();
}

/**
 * Devuelve la información completa para el modal de vista previa antes de
 * eliminar una empresa: el administrador y, agrupados por área, todos los
 * usuarios vinculados, junto con el estado actual de sus programas
 * (wms / octagono) leído directo de wp_usermeta.
 */
add_action( 'wp_ajax_ge_get_empresa_delete_preview', 'ge_ajax_get_empresa_delete_preview' );
function ge_ajax_get_empresa_delete_preview() {
    check_ajax_referer( 'ge_nonce', 'nonce' );

    if ( ! current_user_can( 'manage_options' ) ) {
        wp_send_json_error( [ 'message' => 'Sin permisos.' ] );
        die();
    }

    $empresa_id   = isset( $_POST['empresa_id'] ) ? intval( $_POST['empresa_id'] ) : 0;
    $empresa_user = $empresa_id ? get_userdata( $empresa_id ) : false;

    if ( ! $empresa_user ) {
        wp_send_json_error( [ 'message' => 'Empresa no válida.' ] );
        die();
    }

    global $wpdb;
    $tabla_areas   = $wpdb->prefix . 'areas';
    $tabla_members = $wpdb->prefix . 'user_members';

    $area_rows = $wpdb->get_results( $wpdb->prepare(
        "SELECT id, nombre FROM {$tabla_areas} WHERE grupo_id = %d ORDER BY nombre ASC", $empresa_id
    ), ARRAY_A );

    $members_exist = $wpdb->get_var( "SHOW TABLES LIKE '{$tabla_members}'" ) === $tabla_members;

    // 1 sola consulta para TODOS los vínculos área→usuario de esta empresa (en vez de una por área)
    $area_members = []; // [ area_id => [ user_id, ... ] ]
    if ( $members_exist && ! empty( $area_rows ) ) {
        $area_ids_sql = implode( ',', array_map( 'intval', wp_list_pluck( $area_rows, 'id' ) ) );
        $rows = $wpdb->get_results(
            "SELECT DISTINCT area_id, user_id FROM {$tabla_members} WHERE area_id IN ({$area_ids_sql})",
            ARRAY_A
        );
        foreach ( $rows as $row ) {
            $area_members[ (int) $row['area_id'] ][] = (int) $row['user_id'];
        }
    }

    // 1 sola consulta para TODOS los usuarios involucrados (admin + integrantes de todas las áreas)
    $all_user_ids = [ (int) $empresa_id ];
    foreach ( $area_members as $ids ) $all_user_ids = array_merge( $all_user_ids, $ids );
    $users_map = ge_get_users_map( $all_user_ids );

    $build_user_row = function ( $user ) {
        $nombre = trim( $user->first_name . ' ' . $user->last_name );
        return [
            'id'       => $user->ID,
            'nombre'   => $nombre !== '' ? $nombre : $user->display_name,
            'correo'   => $user->user_email,
            'rol'      => ! empty( $user->roles ) ? $user->roles[0] : '',
            'wms'      => get_user_meta( $user->ID, 'wms', true ),
            'octagono' => get_user_meta( $user->ID, 'octagono', true ),
        ];
    };

    $admin_user = $users_map[ (int) $empresa_id ] ?? $empresa_user;
    $admin      = $build_user_row( $admin_user );

    $areas_result = [];
    foreach ( $area_rows as $area ) {
        $usuarios = [];
        foreach ( ( $area_members[ (int) $area['id'] ] ?? [] ) as $uid ) {
            if ( isset( $users_map[ $uid ] ) ) $usuarios[] = $build_user_row( $users_map[ $uid ] );
        }
        $areas_result[] = [ 'nombre' => $area['nombre'], 'usuarios' => $usuarios ];
    }

    wp_send_json_success( [
        'admin' => $admin,
        'areas' => $areas_result,
    ] );
    die();
}

add_action( 'wp_ajax_ge_sync_program_user', 'ge_ajax_sync_program_user' );
function ge_ajax_sync_program_user() {
    check_ajax_referer( 'ge_nonce', 'nonce' );

    if ( ! current_user_can( 'manage_options' ) ) {
        wp_send_json_error( [ 'message' => 'Sin permisos.' ] );
        die();
    }

    $user_id = isset( $_POST['user_id'] ) ? intval( $_POST['user_id'] ) : 0;
    $user    = $user_id ? get_userdata( $user_id ) : false;

    if ( ! $user ) {
        wp_send_json_error( [ 'message' => 'Usuario no válido.' ] );
        die();
    }

    $result = ge_sync_user_programs( $user_id, $user->user_email );
    wp_send_json_success( $result );
    die();
}

/**
 * Consulta Octágono y WMS para un correo y actualiza/elimina el usermeta
 * correspondiente (octagono / wms) según las reglas de negocio.
 *
 * @return array{user_id:int,email:string,octagono:string,wms:string}
 *         Cada estado es uno de: 'created' | 'updated' | 'removed' | 'unchanged' | 'error'
 */
function ge_sync_user_programs( $user_id, $email ) {
    $result = [
        'user_id'  => $user_id,
        'email'    => $email,
        'octagono' => 'unchanged',
        'wms'      => 'unchanged',
    ];

    $octagono_url   = ge_get_integration_setting( 'octagono_verify_url' );
    $octagono_token = ge_get_integration_setting( 'octagono_verify_token' );
    $wms_url        = ge_get_integration_setting( 'wms_verify_url' );
    $wms_token      = ge_get_integration_setting( 'wms_verify_token' );

    // ── Octágono ──
    if ( empty( $octagono_url ) || empty( $octagono_token ) ) {
        $result['octagono'] = 'error';
        error_log( '[Gestionar Empresa] Verificación Octágono omitida por falta de configuración (' . $email . ').' );
    } else {
        $had_octagono = metadata_exists( 'user', $user_id, 'octagono' );
        $resp_oct = wp_remote_post( $octagono_url, [
            'timeout' => 20,
            'headers' => [
                'Authorization' => 'Bearer ' . $octagono_token,
                'Content-Type'  => 'application/json',
            ],
            'body' => wp_json_encode( [ 'email' => $email ] ),
        ] );

        if ( is_wp_error( $resp_oct ) ) {
            $result['octagono'] = 'error';
            error_log( '[Gestionar Empresa] Error Octágono verificar-usuario (' . $email . '): ' . $resp_oct->get_error_message() );
        } else {
            $body_oct = json_decode( wp_remote_retrieve_body( $resp_oct ), true );
            if ( is_array( $body_oct ) && ! empty( $body_oct['success'] ) ) {
                update_user_meta( $user_id, 'octagono', sanitize_text_field( (string) ( $body_oct['role'] ?? '' ) ) );
                $result['octagono'] = $had_octagono ? 'updated' : 'created';
            } elseif ( $had_octagono ) {
                delete_user_meta( $user_id, 'octagono' );
                $result['octagono'] = 'removed';
            }
        }
    }

    // ── WMS ──
    if ( empty( $wms_url ) || empty( $wms_token ) ) {
        $result['wms'] = 'error';
        error_log( '[Gestionar Empresa] Verificación WMS omitida por falta de configuración (' . $email . ').' );
    } else {
        $had_wms = metadata_exists( 'user', $user_id, 'wms' );
        $resp_wms = wp_remote_post( $wms_url, [
            'timeout' => 20,
            'headers' => [
                'Authorization' => 'Bearer ' . $wms_token,
                'Content-Type'  => 'application/json',
            ],
            'body' => wp_json_encode( [ 'email' => $email ] ),
        ] );

        if ( is_wp_error( $resp_wms ) ) {
            $result['wms'] = 'error';
            error_log( '[Gestionar Empresa] Error WMS verificar-usuario (' . $email . '): ' . $resp_wms->get_error_message() );
        } else {
            $body_wms = json_decode( wp_remote_retrieve_body( $resp_wms ), true );
            $success  = is_array( $body_wms ) && ! empty( $body_wms['success'] );
            $role     = $success ? (string) ( $body_wms['role'] ?? '' ) : '';

            if ( $success && $role !== 'external_user' ) {
                update_user_meta( $user_id, 'wms', sanitize_text_field( $role ) );
                $result['wms'] = $had_wms ? 'updated' : 'created';
            } elseif ( $had_wms ) {
                delete_user_meta( $user_id, 'wms' );
                $result['wms'] = 'removed';
            }
        }
    }

    return $result;
}

function ge_sync_external_user( $email, $password, $role = '' ) {
    $result = [
        'api_called'     => false,
        'created'        => null,
        'webhook_called' => false,
        'webhook_url'    => null,
        'message'        => '',
    ];

    $api_url   = ge_get_integration_setting( 'wms_api_url' );
    $api_token = ge_get_integration_setting( 'wms_api_token' );

    if ( empty( $api_url ) || empty( $api_token ) ) {
        $result['message'] = 'Integración WMS no configurada (falta URL o token en Gestionar Empresa → Configuración).';
        error_log( '[Gestionar Empresa] Sincronización externa omitida por falta de configuración (' . $email . ').' );
        return $result;
    }

    // 1) Crear usuario en WMS Latam
    $response = wp_remote_post( $api_url, [
        'timeout' => 20,
        'headers' => [
            'Authorization' => 'Bearer ' . $api_token,
            'Content-Type'  => 'application/json',
        ],
        'body' => wp_json_encode( [
            'correo'   => $email,
            'password' => $password,
            'inspira'  => $role,
        ] ),
    ] );

    if ( is_wp_error( $response ) ) {
        $result['message'] = 'Error de conexión con API WMS: ' . $response->get_error_message();
        error_log( '[Gestionar Empresa] Error API WMS create-user (' . $email . '): ' . $response->get_error_message() );
        return $result;
    }

    $result['api_called'] = true;
    $code = wp_remote_retrieve_response_code( $response );
    $body = json_decode( wp_remote_retrieve_body( $response ), true );

    if ( $code < 200 || $code >= 300 || ! is_array( $body ) || empty( $body['success'] ) ) {
        $result['message'] = 'Respuesta inesperada de la API WMS (HTTP ' . $code . ').';
        error_log( '[Gestionar Empresa] Respuesta inesperada API WMS (' . $email . '): ' . wp_remote_retrieve_body( $response ) );
        return $result;
    }

    $created           = ! empty( $body['data']['created'] );
    $result['created'] = $created;

    // 2) Elegir webhook según el resultado de "created"
    $webhook_url = $created
        ? ge_get_integration_setting( 'webhook_creado' )
        : ge_get_integration_setting( 'webhook_existente' );

    if ( empty( $webhook_url ) ) {
        $result['message'] = 'Webhook no configurado para este caso (revisa Gestionar Empresa → Configuración).';
        error_log( '[Gestionar Empresa] Webhook omitido por falta de configuración (' . $email . ', created=' . ( $created ? 'true' : 'false' ) . ').' );
        return $result;
    }

    $result['webhook_url']  = $webhook_url;

    $webhook_response = wp_remote_post( $webhook_url, [
        'timeout' => 20,
        'headers' => [ 'Content-Type' => 'application/json' ],
        'body'    => wp_json_encode( [
            'correo'   => $email,
            'password' => $password,
        ] ),
    ] );

    if ( is_wp_error( $webhook_response ) ) {
        $result['message'] = 'Error al llamar webhook (' . $webhook_url . '): ' . $webhook_response->get_error_message();
        error_log( '[Gestionar Empresa] Error webhook (' . $email . ' → ' . $webhook_url . '): ' . $webhook_response->get_error_message() );
        return $result;
    }

    $result['webhook_called'] = true;
    $result['message']        = $created
        ? 'Usuario creado en WMS y notificado correctamente.'
        : 'Usuario ya existía en WMS; notificado por canal alterno.';

    return $result;
}

/**
 * Variante de ge_sync_external_user() para importación masiva:
 * el webhook de Inspira se dispara "fire-and-forget" (no bloqueante,
 * sin esperar respuesta) para no ralentizar la creación de muchos usuarios.
 */
function ge_import_sync_external_user( $email, $password, $role = '' ) {
    $result = [
        'api_called'     => false,
        'created'        => null,
        'webhook_called' => false,
        'message'        => '',
    ];

    $api_url   = ge_get_integration_setting( 'wms_api_url' );
    $api_token = ge_get_integration_setting( 'wms_api_token' );

    if ( empty( $api_url ) || empty( $api_token ) ) {
        $result['message'] = 'Integración WMS no configurada.';
        error_log( '[Gestionar Empresa][Import] Sincronización omitida por falta de configuración (' . $email . ').' );
        return $result;
    }

    $response = wp_remote_post( $api_url, [
        'timeout' => 20,
        'headers' => [
            'Authorization' => 'Bearer ' . $api_token,
            'Content-Type'  => 'application/json',
        ],
        'body' => wp_json_encode( [
            'correo'   => $email,
            'password' => $password,
            'inspira'  => $role,
        ] ),
    ] );

    if ( is_wp_error( $response ) ) {
        $result['message'] = 'Error de conexión con API WMS: ' . $response->get_error_message();
        error_log( '[Gestionar Empresa][Import] Error API WMS create-user (' . $email . '): ' . $response->get_error_message() );
        return $result;
    }

    $result['api_called'] = true;
    $code = wp_remote_retrieve_response_code( $response );
    $body = json_decode( wp_remote_retrieve_body( $response ), true );

    if ( $code < 200 || $code >= 300 || ! is_array( $body ) || empty( $body['success'] ) ) {
        $result['message'] = 'Respuesta inesperada de la API WMS (HTTP ' . $code . ').';
        error_log( '[Gestionar Empresa][Import] Respuesta inesperada API WMS (' . $email . '): ' . wp_remote_retrieve_body( $response ) );
        return $result;
    }

    $created           = ! empty( $body['data']['created'] );
    $result['created'] = $created;

    $webhook_url = $created
        ? ge_get_integration_setting( 'webhook_creado' )
        : ge_get_integration_setting( 'webhook_existente' );

    if ( empty( $webhook_url ) ) {
        $result['message'] = 'Webhook no configurado para este caso.';
        error_log( '[Gestionar Empresa][Import] Webhook omitido por falta de configuración (' . $email . ').' );
        return $result;
    }

    // Fire-and-forget: se envía la petición y NO se espera respuesta,
    // para que el proceso de importación masiva continúe sin bloquearse.
    wp_remote_post( $webhook_url, [
        'timeout'  => 0.01,
        'blocking' => false,
        'headers'  => [ 'Content-Type' => 'application/json' ],
        'body'     => wp_json_encode( [ 'correo' => $email, 'password' => $password ] ),
    ] );

    $result['webhook_called'] = true;
    $result['message']        = $created
        ? 'Usuario creado en WMS; webhook disparado de forma asíncrona.'
        : 'Usuario ya existía en WMS; webhook disparado de forma asíncrona.';

    return $result;
}

