<?php
/**
 * AJAX: CRUD de áreas por empresa
 *
 * @package GestionarEmpresa
 */

if ( ! defined( 'ABSPATH' ) ) exit;

add_action( 'wp_ajax_ge_create_area', 'ge_ajax_create_area' );
function ge_ajax_create_area() {
    check_ajax_referer( 'ge_nonce', 'nonce' );

    if ( ! current_user_can( 'manage_options' ) ) {
        wp_send_json_error( [ 'message' => 'No tienes permisos.' ] );
        die();
    }

    $grupo_id         = intval( $_POST['grupo_id']         ?? 0 );
    $nombre           = sanitize_text_field( $_POST['nombre']           ?? '' );
    $cupo             = intval( $_POST['cupo']             ?? 0 );
    $fecha_expiracion = sanitize_text_field( $_POST['fecha_expiracion'] ?? '' );

    if ( ! $grupo_id ) {
        wp_send_json_error( [ 'message' => 'ID de empresa no v\u00e1lido.' ] );
        die();
    }
    if ( ! $nombre ) {
        wp_send_json_error( [ 'message' => 'El nombre del \u00e1rea es obligatorio.' ] );
        die();
    }
    if ( $cupo <= 0 ) {
        wp_send_json_error( [ 'message' => 'El n\u00famero de cupos debe ser mayor a 0.' ] );
        die();
    }
    if ( ! $fecha_expiracion ) {
        wp_send_json_error( [ 'message' => 'La fecha de expiraci\u00f3n es obligatoria.' ] );
        die();
    }

    $dt = DateTime::createFromFormat( 'Y-m-d', $fecha_expiracion );
    if ( ! $dt || $dt->format( 'Y-m-d' ) !== $fecha_expiracion ) {
        wp_send_json_error( [ 'message' => 'Formato de fecha inv\u00e1lido. Usa YYYY-MM-DD.' ] );
        die();
    }

    if ( ! get_userdata( $grupo_id ) ) {
        wp_send_json_error( [ 'message' => 'La empresa asociada no existe.' ] );
        die();
    }

    ge_create_areas_table();

    global $wpdb;
    $tabla = $wpdb->prefix . 'areas';

    $inserted = $wpdb->insert(
        $tabla,
        [
            'nombre'           => $nombre,
            'cupo'             => $cupo,
            'estado'           => 'Activo',
            'tipo'             => 'companies',
            'grupo_id'         => $grupo_id,
            'fecha_expiracion' => $fecha_expiracion,
        ],
        [ '%s', '%d', '%s', '%s', '%d', '%s' ]
    );

    if ( $inserted === false ) {
        wp_send_json_error( [ 'message' => 'Error al guardar el \u00e1rea en la base de datos.' ] );
        die();
    }

    wp_send_json_success( [
        'message' => '\u00c1rea creada exitosamente.',
        'area'    => [
            'id'               => $wpdb->insert_id,
            'nombre'           => $nombre,
            'cupo'             => $cupo,
            'estado'           => 'Activo',
            'tipo'             => 'companies',
            'grupo_id'         => $grupo_id,
            'fecha_expiracion' => $fecha_expiracion,
        ],
    ] );
    die();
}

add_action( 'wp_ajax_ge_list_areas', 'ge_ajax_list_areas' );
function ge_ajax_list_areas() {
    check_ajax_referer( 'ge_nonce', 'nonce' );

    if ( ! current_user_can( 'manage_options' ) ) {
        wp_send_json_error( [ 'message' => 'No tienes permisos.' ] );
        die();
    }

    $grupo_id = intval( $_POST['grupo_id'] ?? 0 );
    if ( ! $grupo_id ) {
        wp_send_json_error( [ 'message' => 'ID de empresa no válido.' ] );
        die();
    }

    global $wpdb;
    $tabla         = $wpdb->prefix . 'areas';
    $tabla_members = $wpdb->prefix . 'user_members';

    // Verificar si wp_user_members existe
    $members_exist = $wpdb->get_var( "SHOW TABLES LIKE '{$tabla_members}'" ) === $tabla_members;

    if ( $members_exist ) {
        $areas = $wpdb->get_results( $wpdb->prepare(
            "SELECT a.id, a.nombre, a.cupo, a.estado, a.fecha_expiracion,
                     COUNT(um.id) AS miembros
              FROM {$tabla} a
              LEFT JOIN {$tabla_members} um ON um.area_id = a.id
              WHERE a.grupo_id = %d
              GROUP BY a.id
              ORDER BY a.id DESC",
            $grupo_id
        ), ARRAY_A );
    } else {
        $areas = $wpdb->get_results( $wpdb->prepare(
            "SELECT id, nombre, cupo, estado, fecha_expiracion, 0 AS miembros
              FROM {$tabla}
              WHERE grupo_id = %d
              ORDER BY id DESC",
            $grupo_id
        ), ARRAY_A );
    }

    wp_send_json_success( [ 'areas' => $areas ?: [] ] );
    die();
}

add_action( 'wp_ajax_ge_edit_area', 'ge_ajax_edit_area' );
function ge_ajax_edit_area() {
    check_ajax_referer( 'ge_nonce', 'nonce' );

    if ( ! current_user_can( 'manage_options' ) ) {
        wp_send_json_error( [ 'message' => 'No tienes permisos.' ] );
        die();
    }

    $area_id  = intval( $_POST['area_id']  ?? 0 );
    $nombre   = sanitize_text_field( $_POST['nombre']   ?? '' );
    $cupo     = intval( $_POST['cupo']     ?? 0 );
    $fecha    = sanitize_text_field( $_POST['fecha_expiracion'] ?? '' );

    if ( ! $area_id )  { wp_send_json_error( [ 'message' => 'ID de área no válido.' ] );           die(); }
    if ( ! $nombre )   { wp_send_json_error( [ 'message' => 'El nombre es obligatorio.' ] );       die(); }
    if ( $cupo <= 0 )  { wp_send_json_error( [ 'message' => 'Los cupos deben ser mayor a 0.' ] ); die(); }
    if ( ! $fecha )    { wp_send_json_error( [ 'message' => 'La fecha es obligatoria.' ] );        die(); }

    // Validar formato YYYY-MM-DD
    $dt = DateTime::createFromFormat( 'Y-m-d', $fecha );
    if ( ! $dt || $dt->format( 'Y-m-d' ) !== $fecha ) {
        wp_send_json_error( [ 'message' => 'Formato de fecha inválido.' ] );
        die();
    }

    // Validar que sea mayor a hoy
    $hoy = new DateTime( 'today' );
    if ( $dt <= $hoy ) {
        wp_send_json_error( [ 'message' => 'La fecha debe ser mayor a la fecha actual.' ] );
        die();
    }

    global $wpdb;
    $tabla_areas   = $wpdb->prefix . 'areas';
    $tabla_members = $wpdb->prefix . 'user_members';

    // 1. Actualizar wp_areas
    $updated = $wpdb->update(
        $tabla_areas,
        [
            'nombre'           => $nombre,
            'cupo'             => $cupo,
            'estado'           => 'Activo',
            'fecha_expiracion' => $fecha,
        ],
        [ 'id' => $area_id ],
        [ '%s', '%d', '%s', '%s' ],
        [ '%d' ]
    );

    if ( $updated === false ) {
        wp_send_json_error( [ 'message' => 'Error al actualizar el área.' ] );
        die();
    }

    // 2. Convertir fecha a formato dd-mm-yyyy para wp_user_members
    $fecha_members = $dt->format( 'd-m-Y' );

    // 3. Actualizar wp_user_members relacionados
    $members_exist = $wpdb->get_var( "SHOW TABLES LIKE '{$tabla_members}'" ) === $tabla_members;
    if ( $members_exist ) {
        $wpdb->update(
            $tabla_members,
            [
                'status'               => 'ACTIVO',
                'fecha_final_membresia' => $fecha_members,
            ],
            [ 'area_id' => $area_id ],
            [ '%s', '%s' ],
            [ '%d' ]
        );
    }

    wp_send_json_success( [
        'message'          => 'Área actualizada correctamente.',
        'area_id'          => $area_id,
        'nombre'           => $nombre,
        'cupo'             => $cupo,
        'estado'           => 'Activo',
        'fecha_expiracion' => $fecha,
    ] );
    die();
}

