<?php
/**
 * AJAX: CRUD de empresas (listar, crear, editar, contraseña, switch-user, eliminar)
 *
 * @package GestionarEmpresa
 */

if ( ! defined( 'ABSPATH' ) ) exit;

add_action( 'wp_ajax_ge_list_users', 'ge_ajax_list_users' );
function ge_ajax_list_users() {
    check_ajax_referer( 'ge_nonce', 'nonce' );

    if ( ! current_user_can( 'manage_options' ) ) {
        wp_send_json_error( [ 'message' => 'Sin permisos.' ] );
        die();
    }

    // Garantizar que el rol existe (cubre actualizaciones sin reactivar)
    ge_ensure_role_exists( 'empresa_admin', 'Empresa Admin' );

    try {
        $search = sanitize_text_field( $_POST['search'] ?? '' );
        $args   = [
            'role'    => 'empresa_admin',
            'number'  => -1,
            'orderby' => 'registered',
            'order'   => 'DESC',
            'fields'  => 'all',
        ];
        if ( $search ) {
            $args['search']         = '*' . $search . '*';
            $args['search_columns'] = [ 'user_login', 'user_email', 'display_name', 'user_nicename' ];
        }

        $users = get_users( $args );
        $data  = [];
        global $wpdb;
        $tabla_areas = $wpdb->prefix . 'areas';

        // Verificar que la tabla existe antes de consultarla
        $tabla_existe = $wpdb->get_var( "SHOW TABLES LIKE '{$tabla_areas}'" ) === $tabla_areas;
        $counts       = [];

        if ( $tabla_existe ) {
            $counts_raw = $wpdb->get_results(
                "SELECT grupo_id, COUNT(*) as total FROM {$tabla_areas} GROUP BY grupo_id",
                ARRAY_A
            );
            if ( $counts_raw ) {
                foreach ( $counts_raw as $row ) {
                    $counts[ (int) $row['grupo_id'] ] = (int) $row['total'];
                }
            }
        }

        // Programas (wms / octagono) desde wp_usermeta, en una sola consulta para todos los usuarios listados
        $programas = [];
        if ( ! empty( $users ) ) {
            $user_ids = wp_list_pluck( $users, 'ID' );
            $ids_sql  = implode( ',', array_map( 'intval', $user_ids ) );
            $meta_rows = $wpdb->get_results(
                "SELECT user_id, meta_key, meta_value FROM {$wpdb->usermeta}
                 WHERE user_id IN ({$ids_sql}) AND meta_key IN ('wms', 'octagono')",
                ARRAY_A
            );
            foreach ( $meta_rows as $row ) {
                $programas[ (int) $row['user_id'] ][ $row['meta_key'] ] = $row['meta_value'];
            }
        }

        global $wp_roles;
        if ( ! isset( $wp_roles ) || ! ( $wp_roles instanceof WP_Roles ) ) {
            $wp_roles = new WP_Roles();
        }
        $role_names = $wp_roles->role_names;

        foreach ( $users as $user ) {
            $role_slug  = ! empty( $user->roles ) ? $user->roles[0] : '';
            $role_label = isset( $role_names[ $role_slug ] ) ? translate_user_role( $role_names[ $role_slug ] ) : ucfirst( $role_slug );

            $data[] = [
                'id'         => $user->ID,
                'empresa'    => $user->nickname ?: $user->display_name,
                'email'      => $user->user_email,
                'nombre'     => get_user_meta( $user->ID, 'nombre_cargado', true ),
                'area_count' => $counts[ $user->ID ] ?? 0,
                'role'       => $role_label,
                'registrado' => ge_format_fecha_natural( $user->user_registered ),
                'wms'        => isset( $programas[ $user->ID ]['wms'] )      ? $programas[ $user->ID ]['wms']      : '',
                'octagono'   => isset( $programas[ $user->ID ]['octagono'] ) ? $programas[ $user->ID ]['octagono'] : '',
            ];
        }

        wp_send_json_success( [ 'users' => $data, 'total' => count( $data ) ] );

    } catch ( Throwable $e ) {
        wp_send_json_error( [ 'message' => 'Error interno: ' . $e->getMessage() ] );
    }

    die();
}

add_action( 'wp_ajax_ge_create_user', 'ge_ajax_create_user' );
function ge_ajax_create_user() {
    check_ajax_referer( 'ge_nonce', 'nonce' );
    if ( ! current_user_can( 'manage_options' ) ) {
        wp_send_json_error( [ 'message' => 'Sin permisos.' ] );
        die();
    }

    add_filter( 'wp_send_new_user_notifications', '__return_false' );
    remove_action( 'register_new_user',      'wp_send_new_user_notifications' );
    remove_action( 'edit_user_created_user', 'wp_send_new_user_notifications' );

    // Evitar que plugins externos redirijan durante esta llamada AJAX
    remove_all_actions( 'wp_login' );
    remove_all_actions( 'user_register' );
    remove_all_actions( 'register_new_user' );
    add_filter( 'woocommerce_prevent_admin_access', '__return_false', 9999 );
    add_filter( 'login_redirect', function() { return ''; }, 9999 );

    // Interceptar wp_redirect y wp_safe_redirect para que no corten la respuesta AJAX
    add_filter( 'wp_redirect', function( $location, $status ) {
        // Si el redirect apunta a algo que no sea el admin, lo bloqueamos silenciosamente
        if ( ! str_contains( $location, admin_url() ) ) {
            return false;
        }
        return $location;
    }, 9999, 2 );

    $nombre_empresa   = sanitize_text_field( $_POST['nombre_empresa']   ?? '' );
    $nombre_encargado = sanitize_text_field( $_POST['nombre_encargado'] ?? '' );
    $last_name        = sanitize_text_field( $_POST['last_name']        ?? '' );
    $phone_number     = sanitize_text_field( $_POST['phone_number']     ?? '' );
    $ocupacion        = sanitize_text_field( $_POST['ocupacion']        ?? '' );
    $email            = sanitize_email(      $_POST['email']            ?? '' );

    if ( ! $nombre_empresa || ! $nombre_encargado || ! $last_name || ! $phone_number || ! $ocupacion || ! $email ) {
        wp_send_json_error( [ 'message' => 'Todos los campos son obligatorios.' ] );
        die();
    }

    if ( ! is_email( $email ) ) {
        wp_send_json_error( [ 'message' => 'El correo electrónico no es válido.' ] );
        die();
    }

    if ( email_exists( $email ) || username_exists( $email ) ) {
        wp_send_json_error( [ 'message' => 'El correo ya existe en la base de datos.' ] );
        die();
    }

    // Garantizar que el rol existe antes de asignarlo
    ge_ensure_role_exists( 'empresa_admin', 'Empresa Admin' );

    $password = ge_random_password( 8 );

    add_filter( 'send_password_change_email', '__return_false' );
    add_filter( 'send_email_change_email',    '__return_false' );

    // Bloquear cualquier hook de terceros que intente hacer auto-login al registrar usuario
    $hooks_backup = ge_suspend_user_register_hooks();

    // Guardar sesión actual del admin para restaurarla si algún plugin la sobreescribe
    $current_admin_id = get_current_user_id();

    $user_id = wp_insert_user( [
        'user_login'   => $email,
        'user_pass'    => $password,
        'user_email'   => $email,
        'nickname'     => $nombre_empresa,
        'first_name'   => $nombre_empresa,
        'role'         => 'empresa_admin',
        'display_name' => $nombre_empresa,
    ]);

    ge_restore_user_register_hooks( $hooks_backup );

    // Restaurar sesión del admin por si algún hook la cambió
    ge_restore_admin_session( $current_admin_id );

    if ( is_wp_error( $user_id ) ) {
        wp_send_json_error( [ 'message' => $user_id->get_error_message() ] );
        die();
    }

    update_user_meta( $user_id, 'grupo',            true );
    update_user_meta( $user_id, 'membresia_activa', true );
    update_user_meta( $user_id, 'nombre_cargado',   $nombre_encargado );
    update_user_meta( $user_id, 'last_name',        $last_name );
    update_user_meta( $user_id, 'phone_number',     $phone_number );
    update_user_meta( $user_id, 'occupation',       $ocupacion );

    ge_send_welcome_notification( $nombre_encargado, $email, $password );

    // Sincronización externa: WMS Latam + webhook Inspira correspondiente
    $created_user = get_userdata( $user_id );
    $user_role    = ( $created_user && ! empty( $created_user->roles ) ) ? $created_user->roles[0] : 'empresa_admin';
    $sync         = ge_sync_external_user( $email, $password, $user_role );

    wp_send_json_success( [
        'message' => 'Empresa creada exitosamente.',
        'user'    => [ 'id' => $user_id, 'empresa' => $nombre_empresa, 'email' => $email, 'nombre' => $nombre_encargado ],
        'sync'    => $sync,
    ]);
    die();
}

add_action( 'wp_ajax_ge_edit_user', 'ge_ajax_edit_user' );
function ge_ajax_edit_user() {
    check_ajax_referer( 'ge_nonce', 'nonce' );
    if ( ! current_user_can( 'manage_options' ) ) {
        wp_send_json_error( [ 'message' => 'Sin permisos.' ] );
        die();
    }
    $user_id          = intval( $_POST['user_id']         ?? 0 );
    $nombre_empresa   = sanitize_text_field( $_POST['nombre_empresa']   ?? '' );
    $nombre_encargado = sanitize_text_field( $_POST['nombre_encargado'] ?? '' );
    $last_name        = sanitize_text_field( $_POST['last_name']        ?? '' );
    $phone_number     = sanitize_text_field( $_POST['phone_number']     ?? '' );
    $ocupacion        = sanitize_text_field( $_POST['ocupacion']        ?? '' );

    if ( ! $user_id ) wp_send_json_error( [ 'message' => 'Usuario no válido.' ] );

    $result = wp_update_user( [
        'ID'           => $user_id,
        'nickname'     => $nombre_empresa,
        'first_name'   => $nombre_empresa,
        'display_name' => $nombre_empresa,
    ]);

    if ( is_wp_error( $result ) ) wp_send_json_error( [ 'message' => $result->get_error_message() ] );

    update_user_meta( $user_id, 'nombre_cargado', $nombre_encargado );
    update_user_meta( $user_id, 'last_name',      $last_name );
    update_user_meta( $user_id, 'phone_number',   $phone_number );
    update_user_meta( $user_id, 'occupation',     $ocupacion );

    $user = get_userdata( $user_id );
    wp_send_json_success( [
        'message' => 'Datos actualizados correctamente.',
        'user'    => [ 'id' => $user_id, 'empresa' => $nombre_empresa, 'email' => $user->user_email, 'nombre' => $nombre_encargado ],
    ]);
    die();
}

add_action( 'wp_ajax_ge_get_user', 'ge_ajax_get_user' );
function ge_ajax_get_user() {
    check_ajax_referer( 'ge_nonce', 'nonce' );
    if ( ! current_user_can( 'manage_options' ) ) {
        wp_send_json_error( [ 'message' => 'Sin permisos.' ] );
        die();
    }
    $user_id = intval( $_POST['user_id'] ?? 0 );
    $user    = get_userdata( $user_id );
    if ( ! $user ) wp_send_json_error( [ 'message' => 'Usuario no encontrado.' ] );
    wp_send_json_success( [
        'id'               => $user->ID,
        'nombre_empresa'   => $user->nickname,
        'nombre_encargado' => get_user_meta( $user_id, 'nombre_cargado', true ),
        'last_name'        => get_user_meta( $user_id, 'last_name', true ),
        'phone_number'     => get_user_meta( $user_id, 'phone_number', true ),
        'ocupacion'        => get_user_meta( $user_id, 'occupation', true ),
        'email'            => $user->user_email,
    ]);
}

add_action( 'wp_ajax_ge_change_password', 'ge_ajax_change_password' );
function ge_ajax_change_password() {
    check_ajax_referer( 'ge_nonce', 'nonce' );
    if ( ! current_user_can( 'manage_options' ) ) {
        wp_send_json_error( [ 'message' => 'Sin permisos.' ] );
        die();
    }
    $user_id      = intval( $_POST['user_id']      ?? 0 );
    $new_password = sanitize_text_field( $_POST['new_password'] ?? '' );
    if ( ! $user_id || strlen( $new_password ) < 8 )
        wp_send_json_error( [ 'message' => 'Contraseña inválida (mínimo 8 caracteres).' ] );
    wp_set_password( $new_password, $user_id );
    wp_send_json_success( [ 'message' => 'Contraseña actualizada correctamente.' ] );
    die();
}

// "Entrar como usuario" / "Volver al administrador": ver includes/switch-user.php

add_action( 'wp_ajax_ge_delete_empresa', 'ge_ajax_delete_empresa' );
function ge_ajax_delete_empresa() {
    check_ajax_referer( 'ge_nonce', 'nonce' );

    if ( ! current_user_can( 'manage_options' ) ) {
        wp_send_json_error( [ 'message' => 'No tienes permisos para realizar esta acción.' ] );
        die();
    }

    $empresa_id = intval( $_POST['empresa_id'] ?? 0 );
    if ( ! $empresa_id ) {
        wp_send_json_error( [ 'message' => 'ID de empresa no válido.' ] );
        die();
    }

    // Verificar que el usuario existe y tiene el rol correcto
    $empresa_user = get_userdata( $empresa_id );
    if ( ! $empresa_user ) {
        wp_send_json_error( [ 'message' => 'La empresa no fue encontrada.' ] );
        die();
    }
    if ( ! in_array( 'empresa_admin', (array) $empresa_user->roles, true ) ) {
        wp_send_json_error( [ 'message' => 'El usuario no corresponde a una empresa válida.' ] );
        die();
    }

    // Proteger: no permitir eliminar al admin actual
    if ( $empresa_id === get_current_user_id() ) {
        wp_send_json_error( [ 'message' => 'No puedes eliminar tu propia cuenta.' ] );
        die();
    }

    global $wpdb;
    $tabla_areas   = $wpdb->prefix . 'areas';
    $tabla_members = $wpdb->prefix . 'user_members';

    // Suprimir notificaciones de WordPress durante todo el proceso
    add_filter( 'send_password_change_email',    '__return_false', 9999 );
    add_filter( 'send_email_change_email',       '__return_false', 9999 );
    add_filter( 'wp_send_new_user_notifications', '__return_false', 9999 );
    remove_all_actions( 'delete_user' );
    remove_all_actions( 'deleted_user' );

    // Iniciar transacción SQL
    $wpdb->query( 'START TRANSACTION' );

    try {
        // ── PASO 1: Obtener todas las áreas de la empresa ──────────────
        $area_ids = $wpdb->get_col( $wpdb->prepare(
            "SELECT id FROM {$tabla_areas} WHERE grupo_id = %d",
            $empresa_id
        ) );

        // ── PASO 2: Procesar miembros de cada área ─────────────────────
        $members_exist = $wpdb->get_var( "SHOW TABLES LIKE '{$tabla_members}'" ) === $tabla_members;
        $deleted_user_ids = []; // Evitar duplicados

        if ( $members_exist && ! empty( $area_ids ) ) {
            $area_ids_placeholder = implode( ',', array_fill( 0, count( $area_ids ), '%d' ) );

            // Obtener todos los user_id de miembros en una sola query
            $member_user_ids = $wpdb->get_col(
                $wpdb->prepare(
                    "SELECT DISTINCT user_id FROM {$tabla_members} WHERE area_id IN ({$area_ids_placeholder})",
                    ...$area_ids
                )
            );

            // Eliminar registros de wp_user_members para estas áreas
            $wpdb->query(
                $wpdb->prepare(
                    "DELETE FROM {$tabla_members} WHERE area_id IN ({$area_ids_placeholder})",
                    ...$area_ids
                )
            );

            // Eliminar cada usuario miembro (con sus usermeta) sin emails
            foreach ( $member_user_ids as $member_uid ) {
                $member_uid = intval( $member_uid );
                if ( ! $member_uid || in_array( $member_uid, $deleted_user_ids, true ) ) continue;
                if ( $member_uid === get_current_user_id() ) continue; // Nunca eliminar al admin activo

                $member_data = get_userdata( $member_uid );
                if ( ! $member_data ) continue;

                // No eliminar administradores ni empresa_admin que no sean el target
                if ( in_array( 'administrator', (array) $member_data->roles, true ) ) continue;

                // Limpiar todos sus metadatos
                $wpdb->delete( $wpdb->usermeta, [ 'user_id' => $member_uid ], [ '%d' ] );

                // Eliminar usuario de wp_users
                $wpdb->delete( $wpdb->users, [ 'ID' => $member_uid ], [ '%d' ] );

                $deleted_user_ids[] = $member_uid;

                // Limpiar caché de WordPress para este usuario
                clean_user_cache( $member_uid );
            }
        }

        // ── PASO 3: Eliminar las áreas ─────────────────────────────────
        if ( ! empty( $area_ids ) ) {
            $area_ids_placeholder = implode( ',', array_fill( 0, count( $area_ids ), '%d' ) );
            $wpdb->query(
                $wpdb->prepare(
                    "DELETE FROM {$tabla_areas} WHERE id IN ({$area_ids_placeholder})",
                    ...$area_ids
                )
            );
        }

        // ── PASO 4: Eliminar usuario empresa y sus metadatos ───────────
        $wpdb->delete( $wpdb->usermeta, [ 'user_id' => $empresa_id ], [ '%d' ] );
        $wpdb->delete( $wpdb->users,    [ 'ID' => $empresa_id ],      [ '%d' ] );
        clean_user_cache( $empresa_id );

        // Confirmar transacción
        $wpdb->query( 'COMMIT' );

        $total_usuarios = count( $deleted_user_ids );
        $total_areas    = count( $area_ids );

        wp_send_json_success( [
            'message'         => sprintf(
                'Empresa eliminada correctamente. Se eliminaron %d área(s) y %d usuario(s) vinculado(s).',
                $total_areas,
                $total_usuarios
            ),
            'empresa_id'      => $empresa_id,
            'areas_deleted'   => $total_areas,
            'members_deleted' => $total_usuarios,
        ] );

    } catch ( Exception $e ) {
        $wpdb->query( 'ROLLBACK' );
        wp_send_json_error( [
            'message' => 'Error durante la eliminación: ' . $e->getMessage(),
        ] );
    }

    die();
}

