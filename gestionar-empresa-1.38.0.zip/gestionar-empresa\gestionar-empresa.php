<?php
/**
 * Plugin Name: Usuarios & Empresas (Inspira)
 * Description: Panel multiempresa para el ecosistema Inspira: CRUD de empresas (rol empresa_admin), áreas con control de cupos y usuarios (rol subscriber); importación masiva de usuarios por CSV/XLSX con validación previa y progreso en tiempo real; administración directa de wp_usermeta (buscar, crear, editar y eliminar meta por usuario); y sincronización automática de cuentas y estado de programas contra las APIs de WMS Latam, Octágono y los webhooks de notificación de Inspira.
 * Version: 1.38.0
 * Author: Aprobándome
 * Text Domain: gestionar-empresa
 */

if ( ! defined( 'ABSPATH' ) ) exit;

define( 'GE_VERSION', '1.38.0' );
define( 'GE_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'GE_PLUGIN_URL', plugin_dir_url( __FILE__ ) );

// ──────────────────────────────────────────────
// Integración externa: API WMS Latam + Webhooks Inspira
// Estos valores NO se distribuyen en el código del plugin. Se gestionan desde
// Usuarios & Empresas (Inspira) → Configuración (guardados en wp_options) o, si prefieres
// un fallback fuera de la base de datos, definiéndolos en wp-config.php
// (archivo que nunca se comparte ni se sube a control de versiones), ej.:
//   define( 'GE_WMS_API_TOKEN', 'tu-token-real' );
// Ver ge_get_integration_setting() en includes/settings-page.php.
// ──────────────────────────────────────────────
if ( ! defined( 'GE_WMS_API_URL' ) )           define( 'GE_WMS_API_URL', '' );
if ( ! defined( 'GE_WMS_API_TOKEN' ) )         define( 'GE_WMS_API_TOKEN', '' );
if ( ! defined( 'GE_WEBHOOK_CREADO' ) )        define( 'GE_WEBHOOK_CREADO', '' );
if ( ! defined( 'GE_WEBHOOK_EXISTENTE' ) )     define( 'GE_WEBHOOK_EXISTENTE', '' );
if ( ! defined( 'GE_OCTAGONO_VERIFY_URL' ) )   define( 'GE_OCTAGONO_VERIFY_URL', '' );
if ( ! defined( 'GE_OCTAGONO_VERIFY_TOKEN' ) ) define( 'GE_OCTAGONO_VERIFY_TOKEN', '' );
if ( ! defined( 'GE_WMS_VERIFY_URL' ) )        define( 'GE_WMS_VERIFY_URL', '' );
if ( ! defined( 'GE_WMS_VERIFY_TOKEN' ) )      define( 'GE_WMS_VERIFY_TOKEN', '' );

// ──────────────────────────────────────────────
// Carga de módulos (mismo comportamiento, código organizado por responsabilidad)
// ──────────────────────────────────────────────
require_once GE_PLUGIN_DIR . 'includes/helpers.php';           // Funciones auxiliares (usadas por el resto de módulos)
require_once GE_PLUGIN_DIR . 'includes/bootstrap.php';         // Activación, tabla wp_areas, menú, assets
require_once GE_PLUGIN_DIR . 'includes/admin-page.php';        // Página principal (tabs Empresas / Usuarios)
require_once GE_PLUGIN_DIR . 'includes/settings-page.php';     // Página de Configuración
require_once GE_PLUGIN_DIR . 'includes/switch-user.php';       // Entrar como usuario + Volver al administrador
require_once GE_PLUGIN_DIR . 'includes/ajax-empresas.php';     // AJAX: CRUD de empresas
require_once GE_PLUGIN_DIR . 'includes/ajax-areas.php';        // AJAX: CRUD de áreas
require_once GE_PLUGIN_DIR . 'includes/ajax-subscribers.php';  // AJAX: gestión de usuarios (tab Usuarios)
require_once GE_PLUGIN_DIR . 'includes/ajax-cursos.php';       // Cursos de LearnDash: conteo y detalle con avance
require_once GE_PLUGIN_DIR . 'includes/ajax-sync.php';         // Sincronización externa (WMS/Octágono/Inspira)
require_once GE_PLUGIN_DIR . 'includes/ajax-import.php';       // Importación masiva de usuarios
require_once GE_PLUGIN_DIR . 'includes/ajax-usermeta.php';     // Administración de wp_usermeta ("Ver WP_USERMETA")
require_once GE_PLUGIN_DIR . 'includes/ajax-update-emails.php'; // Actualización masiva de correos

register_activation_hook( __FILE__, 'ge_activate' );
