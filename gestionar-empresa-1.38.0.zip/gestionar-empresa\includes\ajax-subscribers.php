<?php
/**
 * AJAX: listado y gestión de usuarios (tab Usuarios)
 *
 * @package GestionarEmpresa
 */

if ( ! defined( 'ABSPATH' ) ) exit;

add_action( 'wp_ajax_ge_list_subscribers', 'ge_ajax_list_subscribers' );
function ge_ajax_list_subscribers() {
    check_ajax_referer( 'ge_nonce', 'nonce' );

    if ( ! current_user_can( 'manage_options' ) ) {
        wp_send_json_error( [ 'message' => 'Sin permisos.' ] );
        die();
    }

    try {
        $search = sanitize_text_field( $_POST['search'] ?? '' );

        $args = [
            'role'    => 'subscriber',
            'number'  => -1,
            'orderby' => 'registered',
            'order'   => 'DESC',
            'fields'  => 'all',
        ];

        if ( $search !== '' ) {
            $matching_ids = ge_search_subscriber_ids( $search );
            if ( empty( $matching_ids ) ) {
                wp_send_json_success( [ 'users' => [], 'total' => 0 ] );
                die();
            }
            $args['include'] = $matching_ids;
        }

        $users = get_users( $args );
        $data  = [];

        if ( empty( $users ) ) {
            wp_send_json_success( [ 'users' => [], 'total' => 0 ] );
            die();
        }

        global $wpdb;
        $user_ids = wp_list_pluck( $users, 'ID' );
        $ids_sql  = implode( ',', array_map( 'intval', $user_ids ) );

        // Nombre completo (first_name/last_name) en una sola consulta
        $nombres = [];
        $meta_nombres_rows = $wpdb->get_results(
            "SELECT user_id, meta_key, meta_value FROM {$wpdb->usermeta}
             WHERE user_id IN ({$ids_sql}) AND meta_key IN ('first_name', 'last_name')",
            ARRAY_A
        );
        foreach ( $meta_nombres_rows as $row ) {
            $nombres[ (int) $row['user_id'] ][ $row['meta_key'] ] = $row['meta_value'];
        }

        // Programas (wms / octagono), igual que en el listado de empresas
        $programas = [];
        $meta_prog_rows = $wpdb->get_results(
            "SELECT user_id, meta_key, meta_value FROM {$wpdb->usermeta}
             WHERE user_id IN ({$ids_sql}) AND meta_key IN ('wms', 'octagono')",
            ARRAY_A
        );
        foreach ( $meta_prog_rows as $row ) {
            $programas[ (int) $row['user_id'] ][ $row['meta_key'] ] = $row['meta_value'];
        }

        // Test (question_test_ids) — solo necesitamos saber si existe
        $tienen_test = [];
        $meta_test_rows = $wpdb->get_results(
            "SELECT DISTINCT user_id FROM {$wpdb->usermeta}
             WHERE user_id IN ({$ids_sql}) AND meta_key = 'question_test_ids'",
            ARRAY_A
        );
        foreach ( $meta_test_rows as $row ) {
            $tienen_test[ (int) $row['user_id'] ] = true;
        }

        // Cursos de LearnDash asignados (ver includes/ajax-cursos.php): una
        // sola consulta para todo el padrón, no una por usuario.
        $cursos_por_usuario = ge_contar_cursos_por_usuario( $user_ids );

        // Relación Usuario → wp_user_members → wp_areas → Empresa
        $tabla_areas   = $wpdb->prefix . 'areas';
        $tabla_members = $wpdb->prefix . 'user_members';
        $membership    = [];
        $empresa_ids   = [];

        $membership_rows = $wpdb->get_results(
            "SELECT m.user_id, a.id AS area_id, a.nombre AS area_nombre, a.grupo_id
             FROM {$tabla_members} m
             INNER JOIN {$tabla_areas} a ON a.id = m.area_id
             WHERE m.user_id IN ({$ids_sql})",
            ARRAY_A
        );
        foreach ( $membership_rows as $row ) {
            $uid = (int) $row['user_id'];
            if ( isset( $membership[ $uid ] ) ) continue; // si pertenece a varias áreas, tomamos la primera
            $membership[ $uid ] = [ 'area' => $row['area_nombre'], 'area_id' => (int) $row['area_id'], 'grupo_id' => (int) $row['grupo_id'] ];
            $empresa_ids[] = (int) $row['grupo_id'];
        }

        $empresa_nombres = [];
        $empresa_users_map = ge_get_users_map( array_unique( $empresa_ids ) ); // 1 sola consulta en vez de N
        foreach ( $empresa_users_map as $eid => $eu ) {
            $empresa_nombres[ $eid ] = $eu->nickname ?: $eu->display_name;
        }

        global $wp_roles;
        if ( ! isset( $wp_roles ) || ! ( $wp_roles instanceof WP_Roles ) ) {
            $wp_roles = new WP_Roles();
        }
        $role_names = $wp_roles->role_names;

        foreach ( $users as $user ) {
            $uid = $user->ID;

            $first = isset( $nombres[ $uid ]['first_name'] ) ? trim( $nombres[ $uid ]['first_name'] ) : '';
            $last  = isset( $nombres[ $uid ]['last_name'] )  ? trim( $nombres[ $uid ]['last_name'] )  : '';
            $nombre_completo = ( $first !== '' && $last !== '' ) ? ( $first . ' ' . $last ) : $user->user_login;

            $role_slug  = ! empty( $user->roles ) ? $user->roles[0] : '';
            $role_label = isset( $role_names[ $role_slug ] ) ? translate_user_role( $role_names[ $role_slug ] ) : ucfirst( $role_slug );

            $m = isset( $membership[ $uid ] ) ? $membership[ $uid ] : null;

            $data[] = [
                'id'         => $uid,
                'nombre'     => $nombre_completo,
                'username'   => $user->user_login,
                'email'      => $user->user_email,
                'empresa'    => $m && isset( $empresa_nombres[ $m['grupo_id'] ] ) ? $empresa_nombres[ $m['grupo_id'] ] : '',
                'empresa_id' => $m ? $m['grupo_id'] : 0,
                'area'       => $m ? $m['area'] : '',
                'area_id'    => $m ? $m['area_id'] : 0,
                'role'       => $role_label,
                'registrado' => ge_format_fecha_natural( $user->user_registered ),
                'test'       => ! empty( $tienen_test[ $uid ] ),
                'cursos'     => isset( $cursos_por_usuario[ $uid ] ) ? (int) $cursos_por_usuario[ $uid ] : 0,
                'wms'        => isset( $programas[ $uid ]['wms'] )      ? $programas[ $uid ]['wms']      : '',
                'octagono'   => isset( $programas[ $uid ]['octagono'] ) ? $programas[ $uid ]['octagono'] : '',
            ];
        }

        wp_send_json_success( [ 'users' => $data, 'total' => count( $data ) ] );

    } catch ( Throwable $e ) {
        wp_send_json_error( [ 'message' => 'Error interno: ' . $e->getMessage() ] );
    }

    die();
}

/**
 * Busca IDs de usuarios con rol subscriber cuyo nombre completo (first_name/last_name),
 * username o correo coincidan con el término de búsqueda.
 */
function ge_search_subscriber_ids( $search ) {
    global $wpdb;

    $ids_directos = get_users( [
        'role'           => 'subscriber',
        'search'         => '*' . $search . '*',
        'search_columns' => [ 'user_login', 'user_email', 'user_nicename', 'display_name' ],
        'fields'         => 'ID',
        'number'         => -1,
    ] );

    $like = '%' . $wpdb->esc_like( $search ) . '%';
    $ids_por_nombre = $wpdb->get_col( $wpdb->prepare(
        "SELECT DISTINCT user_id FROM {$wpdb->usermeta}
         WHERE meta_key IN ('first_name', 'last_name') AND meta_value LIKE %s",
        $like
    ) );

    $todos_ids = array_map( 'intval', array_merge( $ids_directos, $ids_por_nombre ) );
    return array_values( array_unique( $todos_ids ) );
}

/**
 * Devuelve el estado actual (post-refresco) de los programas de un usuario,
 * leído directamente de wp_usermeta, para decidir el mensaje de confirmación
 * antes de borrarlo.
 */
add_action( 'wp_ajax_ge_get_subscriber_programs', 'ge_ajax_get_subscriber_programs' );
function ge_ajax_get_subscriber_programs() {
    check_ajax_referer( 'ge_nonce', 'nonce' );

    if ( ! current_user_can( 'manage_options' ) ) {
        wp_send_json_error( [ 'message' => 'Sin permisos.' ] );
        die();
    }

    $user_id = isset( $_POST['user_id'] ) ? intval( $_POST['user_id'] ) : 0;
    if ( ! $user_id || ! get_userdata( $user_id ) ) {
        wp_send_json_error( [ 'message' => 'Usuario no válido.' ] );
        die();
    }

    wp_send_json_success( [
        'wms'      => get_user_meta( $user_id, 'wms', true ),
        'octagono' => get_user_meta( $user_id, 'octagono', true ),
    ] );
    die();
}

/**
 * Borra un usuario (tab "Usuarios") de forma permanente:
 * 1) Quita sus vínculos de área en wp_user_members.
 * 2) Elimina el usuario de WordPress (wp_delete_user, que ya limpia wp_usermeta).
 * 3) Limpieza defensiva de cualquier resto de usermeta huérfano.
 */
add_action( 'wp_ajax_ge_delete_subscriber', 'ge_ajax_delete_subscriber' );
function ge_ajax_delete_subscriber() {
    check_ajax_referer( 'ge_nonce', 'nonce' );

    if ( ! current_user_can( 'manage_options' ) ) {
        wp_send_json_error( [ 'message' => 'Sin permisos.' ] );
        die();
    }

    $user_id = isset( $_POST['user_id'] ) ? intval( $_POST['user_id'] ) : 0;
    $user    = $user_id ? get_userdata( $user_id ) : false;

    if ( ! $user ) {
        wp_send_json_error( [ 'message' => 'El usuario ya no existe.' ] );
        die();
    }

    global $wpdb;
    $tabla_members = $wpdb->prefix . 'user_members';

    // 1) Quitar vínculos de área
    $members_exist = $wpdb->get_var( "SHOW TABLES LIKE '{$tabla_members}'" ) === $tabla_members;
    if ( $members_exist ) {
        $wpdb->delete( $tabla_members, [ 'user_id' => $user_id ], [ '%d' ] );
    }

    // 2) Eliminar el usuario de WordPress
    if ( ! function_exists( 'wp_delete_user' ) ) {
        require_once ABSPATH . 'wp-admin/includes/user.php';
    }
    $deleted = wp_delete_user( $user_id );

    if ( ! $deleted ) {
        wp_send_json_error( [ 'message' => 'No se pudo eliminar el usuario.' ] );
        die();
    }

    // 3) Limpieza defensiva de cualquier resto de usermeta huérfano
    $wpdb->delete( $wpdb->usermeta, [ 'user_id' => $user_id ], [ '%d' ] );

    wp_send_json_success( [ 'message' => 'El usuario fue eliminado correctamente.' ] );
    die();
}

/**
 * Cambia el correo de UN usuario puntual desde el botón "Cambiar correo"
 * del menú de Acciones (tab Usuarios). A diferencia de la actualización
 * masiva (ge_update_email_one), aquí NO se exige que el perfil esté
 * incompleto: es una acción manual explícita del admin sobre un usuario
 * concreto, así que solo se valida formato y duplicidad.
 */
add_action( 'wp_ajax_ge_change_subscriber_email', 'ge_ajax_change_subscriber_email' );
function ge_ajax_change_subscriber_email() {
    check_ajax_referer( 'ge_nonce', 'nonce' );

    if ( ! current_user_can( 'manage_options' ) ) {
        wp_send_json_error( [ 'message' => 'Sin permisos.' ] );
        die();
    }

    $user_id      = isset( $_POST['user_id'] ) ? intval( $_POST['user_id'] ) : 0;
    $correo_nuevo = isset( $_POST['nuevo_correo'] ) ? sanitize_email( trim( strtolower( wp_unslash( $_POST['nuevo_correo'] ) ) ) ) : '';

    $user = $user_id ? get_userdata( $user_id ) : false;
    if ( ! $user ) {
        wp_send_json_error( [ 'message' => 'Usuario no válido.' ] );
        die();
    }

    if ( ! $correo_nuevo || ! is_email( $correo_nuevo ) ) {
        wp_send_json_error( [ 'message' => 'El correo electrónico no es válido.' ] );
        die();
    }

    if ( strtolower( $user->user_email ) === $correo_nuevo ) {
        wp_send_json_error( [ 'message' => 'El nuevo correo es igual al actual.' ] );
        die();
    }

    $existing = get_user_by( 'email', $correo_nuevo );
    if ( $existing ) {
        wp_send_json_error( [ 'message' => 'Ese correo ya está en uso por otro usuario.' ] );
        die();
    }

    $update_args = [
        'ID'         => $user_id,
        'user_email' => $correo_nuevo,
    ];
    // Igual que en la actualización masiva: solo se actualiza el user_login
    // si coincidía con el correo actual (patrón usado al crear el usuario).
    if ( strtolower( $user->user_login ) === strtolower( $user->user_email ) ) {
        $update_args['user_login'] = $correo_nuevo;
    }

    $updated = wp_update_user( $update_args );

    if ( is_wp_error( $updated ) ) {
        wp_send_json_error( [ 'message' => 'Error al actualizar el correo: ' . $updated->get_error_message() ] );
        die();
    }

    wp_send_json_success( [
        'message' => 'Correo actualizado correctamente.',
        'user_id' => $user_id,
        'correo'  => $correo_nuevo,
    ] );
    die();
}

