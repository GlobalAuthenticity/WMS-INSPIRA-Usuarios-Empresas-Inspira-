<?php
/**
 * Importación masiva de usuarios (wizard)
 *
 * @package GestionarEmpresa
 */

if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Paso 4 del wizard: valida en bloque los registros del archivo contra la
 * empresa/área seleccionadas, separando "nuevos" (se crearán) de "omitidos"
 * (con el motivo exacto por el que no se pueden crear).
 */
add_action( 'wp_ajax_ge_import_validate', 'ge_ajax_import_validate' );
function ge_ajax_import_validate() {
    check_ajax_referer( 'ge_nonce', 'nonce' );

    if ( ! current_user_can( 'manage_options' ) ) {
        wp_send_json_error( [ 'message' => 'No tienes permisos.' ] );
        die();
    }

    $empresa_id = intval( $_POST['empresa_id'] ?? 0 );
    $area_id    = intval( $_POST['area_id'] ?? 0 );
    $rows       = json_decode( wp_unslash( $_POST['rows'] ?? '' ), true );

    if ( ! $empresa_id || ! $area_id ) {
        wp_send_json_error( [ 'message' => 'Empresa o área no válida.' ] );
        die();
    }
    if ( ! is_array( $rows ) || empty( $rows ) ) {
        wp_send_json_error( [ 'message' => 'No hay registros para validar.' ] );
        die();
    }

    global $wpdb;
    $tabla_areas   = $wpdb->prefix . 'areas';
    $tabla_members = $wpdb->prefix . 'user_members';

    $area = $wpdb->get_row( $wpdb->prepare(
        "SELECT * FROM {$tabla_areas} WHERE id = %d AND grupo_id = %d", $area_id, $empresa_id
    ), ARRAY_A );

    if ( ! $area ) {
        wp_send_json_error( [ 'message' => 'El área seleccionada no pertenece a esta empresa.' ] );
        die();
    }

    $members_exist = $wpdb->get_var( "SHOW TABLES LIKE '{$tabla_members}'" ) === $tabla_members;

    $miembros_actuales = $members_exist
        ? (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$tabla_members} WHERE area_id = %d", $area_id ) )
        : 0;

    if ( $miembros_actuales >= (int) $area['cupo'] ) {
        wp_send_json_error( [ 'message' => 'El área "' . $area['nombre'] . '" ya no tiene cupos disponibles (' . $miembros_actuales . ' / ' . $area['cupo'] . ').' ] );
        die();
    }

    $nuevos   = [];
    $omitidos = [];
    $seen     = [];

    foreach ( $rows as $row ) {
        $correo = isset( $row['correo'] ) ? sanitize_email( trim( strtolower( (string) $row['correo'] ) ) ) : '';
        $nombre_completo = trim( sanitize_text_field( $row['first_name'] ?? '' ) . ' ' . sanitize_text_field( $row['last_name'] ?? '' ) );

        if ( ! $correo || ! is_email( $correo ) ) {
            $omitidos[] = [ 'correo' => sanitize_text_field( $row['correo'] ?? '(vacío)' ), 'motivo' => 'Correo inválido o vacío.' ];
            continue;
        }
        if ( isset( $seen[ $correo ] ) ) {
            $omitidos[] = [ 'correo' => $correo, 'motivo' => 'Correo duplicado en el archivo.' ];
            continue;
        }
        $seen[ $correo ] = true;

        $existing_user = get_user_by( 'email', $correo );

        if ( $existing_user ) {
            $motivo = 'El usuario ya existe.';

            if ( $members_exist ) {
                $member_area = $wpdb->get_row( $wpdb->prepare(
                    "SELECT a.grupo_id FROM {$tabla_members} um
                      INNER JOIN {$tabla_areas} a ON a.id = um.area_id
                      WHERE um.user_id = %d LIMIT 1",
                    $existing_user->ID
                ), ARRAY_A );

                if ( $member_area ) {
                    $motivo = ( (int) $member_area['grupo_id'] === $empresa_id )
                        ? 'El usuario ya pertenece a un área de esta empresa.'
                        : 'El usuario pertenece a otra empresa.';
                }
            }

            $omitidos[] = [ 'correo' => $correo, 'motivo' => $motivo ];
            continue;
        }

        $nuevos[] = [
            'correo' => $correo,
            'nombre' => $nombre_completo ?: '—',
            'area'   => $area['nombre'],
        ];
    }

    wp_send_json_success( [
        'nuevos'   => $nuevos,
        'omitidos' => $omitidos,
        'total'    => count( $rows ),
    ] );
    die();
}

/**
 * Crea UN usuario del lote de importación. El front-end llama a este
 * endpoint una vez por cada registro válido, en paralelo controlado por
 * lotes, para poder mostrar el progreso en tiempo real y para que un
 * fallo puntual no detenga el resto del procesamiento.
 */
add_action( 'wp_ajax_ge_import_create_one', 'ge_ajax_import_create_one' );
function ge_ajax_import_create_one() {
    check_ajax_referer( 'ge_nonce', 'nonce' );

    if ( ! current_user_can( 'manage_options' ) ) {
        wp_send_json_error( [ 'message' => 'No tienes permisos.' ] );
        die();
    }

    $area_id = intval( $_POST['area_id'] ?? 0 );
    $row     = json_decode( wp_unslash( $_POST['row'] ?? '' ), true );

    if ( ! $area_id || ! is_array( $row ) ) {
        wp_send_json_error( [ 'message' => 'Datos incompletos.' ] );
        die();
    }

    $correo = isset( $row['correo'] ) ? sanitize_email( trim( strtolower( (string) $row['correo'] ) ) ) : '';

    if ( ! $correo || ! is_email( $correo ) ) {
        wp_send_json_error( [ 'message' => 'Correo inválido.', 'correo' => sanitize_text_field( $row['correo'] ?? '' ) ] );
        die();
    }
    if ( email_exists( $correo ) ) {
        wp_send_json_error( [ 'message' => 'El correo ya existe (verificación final).', 'correo' => $correo ] );
        die();
    }

    global $wpdb;
    $tabla_areas   = $wpdb->prefix . 'areas';
    $tabla_members = $wpdb->prefix . 'user_members';

    $area = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$tabla_areas} WHERE id = %d", $area_id ), ARRAY_A );
    if ( ! $area ) {
        wp_send_json_error( [ 'message' => 'El área ya no existe.', 'correo' => $correo ] );
        die();
    }

    $password   = ge_random_password( 8 );
    $first_name = sanitize_text_field( $row['first_name'] ?? '' );
    $last_name  = sanitize_text_field( $row['last_name']  ?? '' );

    // Evitar auto-login/redirect de otros plugins (Ultimate Member, WooCommerce, etc.) durante la creación masiva
    $hooks_backup = ge_suspend_user_register_hooks();
    $current_admin_id = get_current_user_id();

    $user_id = wp_insert_user( [
        'user_login'   => $correo,
        'user_pass'    => $password,
        'user_email'   => $correo,
        'first_name'   => $first_name,
        'last_name'    => $last_name,
        'display_name' => trim( $first_name . ' ' . $last_name ) ?: $correo,
        'role'         => 'subscriber',
    ] );

    ge_restore_user_register_hooks( $hooks_backup );
    ge_restore_admin_session( $current_admin_id );

    if ( is_wp_error( $user_id ) ) {
        wp_send_json_error( [ 'message' => $user_id->get_error_message(), 'correo' => $correo ] );
        die();
    }

    if ( ! empty( $row['user_age'] ) )      update_user_meta( $user_id, 'user_age',      sanitize_text_field( $row['user_age'] ) );
    if ( ! empty( $row['user_gender'] ) )   update_user_meta( $user_id, 'user_gender',   sanitize_text_field( $row['user_gender'] ) );
    if ( ! empty( $row['country'] ) )       update_user_meta( $user_id, 'country',       sanitize_text_field( $row['country'] ) );
    if ( ! empty( $row['phone_number'] ) )  update_user_meta( $user_id, 'phone_number',  sanitize_text_field( $row['phone_number'] ) );
    if ( ! empty( $row['user_position'] ) ) update_user_meta( $user_id, 'user_position', sanitize_text_field( $row['user_position'] ) );

    // Vincular al área seleccionada (wp_user_members)
    $members_exist = $wpdb->get_var( "SHOW TABLES LIKE '{$tabla_members}'" ) === $tabla_members;
    if ( $members_exist ) {
        $fecha_members = '';
        if ( ! empty( $area['fecha_expiracion'] ) ) {
            $dt = DateTime::createFromFormat( 'Y-m-d', $area['fecha_expiracion'] );
            if ( $dt ) $fecha_members = $dt->format( 'd-m-Y' );
        }
        $inserted_member = $wpdb->insert(
            $tabla_members,
            [
                'area_id'               => $area_id,
                'user_id'               => $user_id,
                'status'                => 'ACTIVO',
                'days'                  => 0,
                'fecha_final_membresia' => $fecha_members,
            ],
            [ '%d', '%d', '%s', '%d', '%s' ]
        );
        if ( $inserted_member === false ) {
            error_log( '[Gestionar Empresa][Import] Error al vincular usuario ' . $user_id . ' al área ' . $area_id . ': ' . $wpdb->last_error );
        }
    } else {
        error_log( '[Gestionar Empresa][Import] La tabla ' . $tabla_members . ' no existe; usuario ' . $user_id . ' creado SIN vincular a ningún área.' );
    }

    ge_send_welcome_notification( $first_name ?: $correo, $correo, $password );

    // Sincronización externa (webhook fire-and-forget, según lo pactado para importación masiva)
    $sync = ge_import_sync_external_user( $correo, $password, 'subscriber' );

    wp_send_json_success( [
        'correo' => $correo,
        'nombre' => trim( $first_name . ' ' . $last_name ) ?: '—',
        'area'   => $area['nombre'],
        'sync'   => $sync,
    ] );
    die();
}

